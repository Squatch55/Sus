UI.AddDropdown( "Esp Mode", ["Death Esp", "Toggle Esp"] );
UI.AddDropdown( "Complexity", ["Basic Esp","Full Esp"] );
UI.AddHotkey( "ESP" );

function doneEsp()
{
	var localPlayerIndex = Entity.GetLocalPlayer();
	var isAlive = Entity.IsAlive(localPlayerIndex);
	var getEspMode = UI.GetValue("Misc", "JAVASCRIPT", "Script Items", "Esp Mode");
	var doEsp = 0;
	if (getEspMode == 0 && isAlive == 0)
	{
		doEsp = 1;
		var getComplexity = UI.GetValue("Misc", "JAVASCRIPT", "Script Items", "Complexity");
		if (getComplexity == 0)
		{
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Box", doEsp);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Name", doEsp);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Health", doEsp);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Skeleton", doEsp);
		}
		else if (getComplexity == 1)
		{
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Box", doEsp);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Glow", doEsp );
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Name", doEsp);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Health", doEsp);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Dormant", doEsp );
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Weapon", "Icon", doEsp );
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Ammo", doEsp );
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Skeleton", doEsp);
		}
	} else {
		doEsp = 0;
	}
	if (getEspMode == 1)
	{
		var getKeyState = UI.IsHotkeyActive( "Misc", "ESP" );
		var getComplexity = UI.GetValue("Misc", "JAVASCRIPT", "Script Items", "Complexity");
		if (getComplexity == 0)
		{
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Box", getKeyState);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Name", getKeyState);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Health", getKeyState);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Skeleton", getKeyState);
		}
		else if (getComplexity == 1)
		{
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Box", getKeyState);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Glow", getKeyState );
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Name", getKeyState);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Health", getKeyState);
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Dormant", getKeyState );
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Weapon", "Icon", getKeyState );
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Ammo", getKeyState );
			UI.SetValue( "Visual", "ENEMIES", "ESP", "Skeleton", getKeyState);
		}
	}
}

Global.RegisterCallback("CreateMove", "doneEsp");