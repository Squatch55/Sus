UI.AddCheckbox("Watermark");
UI.AddColorPicker("Watermark Color");
UI.SetColor('Misc', 'JAVASCRIPT', 'Script items', "Watermark Color", [163, 240, 41, 255]);
UI.AddMultiDropdown("Indicators", ["DT Indicator", "Hide Indicator", "FD Indicator", "Inverter Indicator", "Force Safe Point Indicator", "BAIM Indicator", "DMG Indicator"]);
UI.AddSliderInt("Boldness", 100, 1000);
UI.AddTextbox("Font");
UI.AddColorPicker("Color Enabled");
UI.SetColor('Misc', 'JAVASCRIPT', 'Script items', "Color Enabled", [163, 240, 41, 255]);
UI.AddColorPicker("Color Disabled");
UI.SetColor('Misc', 'JAVASCRIPT', 'Script items', "Color Disabled", [242, 29, 29, 255]);
UI.AddColorPicker("Color Left/Right");
UI.SetColor('Misc', 'JAVASCRIPT', 'Script items', "Color Left/Right", [255, 255, 255, 255]);

function render_arc(x, y, radius, radius_inner, start_angle, end_angle, segments, color)
    {
        while(360 % segments != 0)
        {
            segments++;
        }

        segments = 360 / segments;

        for (var i = start_angle; i < start_angle + end_angle; i = i + segments)
        {

            var rad = i * Math.PI / 180;
            var rad2 = (i + segments) * Math.PI / 180;

            var rad_cos = Math.cos(rad)
            var rad_sin = Math.sin(rad)

            var rad2_cos = Math.cos(rad2);
            var rad2_sin = Math.sin(rad2);

            var x1_outer = x + rad_cos * radius;
            var y1_outer = y + rad_sin * radius;

            var x2_outer = x + rad2_cos * radius;
            var y2_outer = y + rad2_sin * radius;

            var x1_inner = x + rad_cos * radius_inner;
            var y1_inner = y + rad_sin * radius_inner;

            var x2_inner = x + rad2_cos * radius_inner;
            var y2_inner = y + rad2_sin * radius_inner;

            Render.Polygon( [
                [ x1_outer, y1_outer ],
                [ x2_outer, y2_outer ],
                [ x1_inner, y1_inner ] ],
                color
            );

            Render.Polygon( [
                [ x1_inner, y1_inner ],
                [ x2_outer, y2_outer ],
                [ x2_inner, y2_inner ] ],
                color
            );
        }
    }

function render() {
        changefont = UI.GetString('Misc', 'JAVASCRIPT', 'Script items', "Font");
        boldness = UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "Boldness");
        watermarkcolor = UI.GetColor('Misc', 'JAVASCRIPT', 'Script items', "Watermark Color");
        colorenabled = UI.GetColor('Misc', 'JAVASCRIPT', 'Script items', "Color Enabled");
        colordisabled = UI.GetColor('Misc', 'JAVASCRIPT', 'Script items', "Color Disabled");
        invertercolor = UI.GetColor('Misc', 'JAVASCRIPT', 'Script items', "Color Left/Right");
        username = Cheat.GetUsername();
        font = Render.AddFont(changefont, 10, boldness);
        font1 = Render.AddFont("Verdana", 10, 1000);
        charge = Exploit.GetCharge();
        max_angle = 360*Exploit.GetCharge();
        selected = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicators").toString(2).split("").reverse().map(Number);
        var Center = Render.GetScreenSize();
        var CenterX = Center[0] / 2
        var CenterY = Center[1] / 2
        var ip = World.GetServerString();
        var tickrate = Global.Tickrate();
        var today = new Date();
        var hours1 = today.getHours();
        var minutes1 = today.getMinutes();
        var seconds1 = today.getSeconds();
        var hours = hours1 <= 9 ? "0" + today.getHours() + ":" : today.getHours() + ":";
        var minutes = minutes1 <= 9 ? "0" + today.getMinutes() + ":" : today.getMinutes() + ":";
        var seconds = seconds1 <= 9 ? "0" + today.getSeconds() : today.getSeconds();
        const ping = Math.floor(Global.Latency() * 1000 / 1.5);

        //Doubletap Indicator

        if (selected[0]) {

            if (UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap")) {
                Render.StringCustom(CenterX, CenterY + 74.5, 1, "DT", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 75, 1, "DT", colorenabled, font);
                if (charge < 1){
                    render_arc(CenterX + 14, CenterY + 81.5, 6, 3, -90, 360, 360, [120, 120, 120, 190]);
                    render_arc(CenterX + 14, CenterY + 81.5, 6, 3, -90, max_angle, 360, colorenabled);
                }
            } else {
                Render.StringCustom(CenterX, CenterY + 74.5, 1, "DT", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 75, 1, "DT", colordisabled, font);
            }
        }

        //Hide Indicator

        if (selected[1]) {
            if (UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Hide shots")) {
                Render.StringCustom(CenterX, CenterY + 89.5, 1, "HIDE", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 90, 1, "HIDE", colorenabled, font);
            } else {
                Render.StringCustom(CenterX, CenterY + 89.5, 1, "HIDE", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 90, 1, "HIDE", colordisabled, font);
            }
        }

        //Fakeduck Indicator

        if (selected[2]) {
            if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck")) {
                Render.StringCustom(CenterX, CenterY + 149.5, 1, "DUCK", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 150, 1, "DUCK", colorenabled, font);
            } else {
                Render.StringCustom(CenterX, CenterY + 149.5, 1, "DUCK", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 150, 1, "DUCK", colordisabled, font);
            }
        }

        //Bodyaim Indicator

        if (selected[5]) {
            if (UI.IsHotkeyActive("Rage", "General", "Force body aim")) {
                Render.StringCustom(CenterX, CenterY + 119.5, 1, "BODY", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 120, 1, "BODY", colorenabled, font);
            } else {
                Render.StringCustom(CenterX, CenterY + 119.5, 1, "BODY", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 120, 1, "BODY", colordisabled, font);
            }
        }

        //Force Safe Point Indicator

        if (selected[4]) {
            if (UI.IsHotkeyActive("Rage", "General", "Force safe point")) {
                Render.StringCustom(CenterX, CenterY + 134.5, 1, "SAFE POINT", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 135, 1, "SAFE POINT", colorenabled, font);
            } else {
                Render.StringCustom(CenterX, CenterY + 134.5, 1, "SAFE POINT", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 135, 1, "SAFE POINT", colordisabled, font);
            }
        }

        //Inverter Indicator

        if (selected[3]) {
            if (UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")) {
                Render.StringCustom(CenterX, CenterY + 104.5, 1, "RIGHT", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 105, 1, "RIGHT", invertercolor, font);
            } else {
                Render.StringCustom(CenterX, CenterY + 104.5, 1, "LEFT", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 105, 1, "LEFT", invertercolor, font);
            }
        }

        //DMG Indicator

        if (selected[6]) {
            if (UI.IsHotkeyActive('Misc', 'JAVASCRIPT', 'Script items',"Override Hotkey")) {
                Render.StringCustom(CenterX, CenterY + 59.5, 1, "DMG", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 60, 1, "DMG", colorenabled, font);
            } else {
                Render.StringCustom(CenterX, CenterY + 59.5, 1, "DMG", [0, 0, 0, 255], font);
                Render.StringCustom(CenterX, CenterY + 60, 1, "DMG", colordisabled, font);
            }
        }

        //Watermark Indicator

        if (UI.GetValue("Watermark")) {
            if (ping == 0) {
                Render.StringCustom(CenterX + 750, CenterY - 529, 0,"onetap | " + username + " | " + hours + minutes + seconds, [0, 0, 0, 255], font1);
                Render.StringCustom(CenterX + 750, CenterY - 530, 0,"onetap | " + username + " | " + hours + minutes + seconds, watermarkcolor, font1);
            } else {
                Render.StringCustom(CenterX + 750, CenterY - 529, 0,"onetap | " + username + " | " + hours + minutes + seconds, [0, 0, 0, 255], font1);
                Render.StringCustom(CenterX + 750, CenterY - 530, 0,"onetap | " + username + " | " + hours + minutes + seconds, watermarkcolor, font1);
            }
        }
    }

var binlib = {};
function dictLength(dict) {
        var count = 0;
        for (_ in dict) {
            count++;
        }
        return count;
    }

createDropdown = function (name, values, multi) {
        UI[multi ? "AddMultiDropdown" : "AddDropdown"](name, values);

        binlib[name] = { "multi": multi, "values": {} };

        multi && values.reverse();

        var i = 0; for (value in values) {
            var index = multi ? (1 << (values.length - (i + 1))) : i;
            binlib[name].values[index] = values[value];
            i++;
        }
}

fetchDropdown = function (name) {
        var selection = (name ? [] : {})
        var bin = UI.GetValue("Misc", name);

        !name && function () { for (dropdown in binlib) selection[dropdown] = fetchDropdown(dropdown) }();

        if (name) {
            !binlib[name].multi && bin == 0 && selection.push(binlib[name].values[0]) && function () { return selection; }();
            for (var i = dictLength(binlib[name].values) - 1; i >= 0; i--) {
                if (!binlib[name].multi && i == 0) continue;

                var index = binlib[name].multi ? (1 << i) : i;
                if (bin - index >= 0) {
                    bin -= (index);
                    selection.push(binlib[name].values[index]);
                }
            }
        }

        return selection;
    }

var pistolNames = ["usp s", "cz75 auto", "dual berettas", "dual berettas", "five seven", "glock 18", "p200", "p250", "tec 9"]
var heavypistolNames = ["desert eagle", "r8 revolver"]
var autosniperNames = ["scar 20", "g3sg1"]
var otherNames = ["knife", "flashbang", "decoy", "high explosive grenade", "incendiary grenade", "molotov", "smoke grenade", "c4 explosive", "zeus x27"]

function WeaponCFG(pMin, pOriginalmin) {
        this.min = pMin;
        this.omin = pOriginalmin;
    }

var setOnce = false;

function handleDamage() {
        if (UI.IsMenuOpen()) {
            if (UI.IsHotkeyActive('Misc', 'JAVASCRIPT', 'Script items', "Override Hotkey")) {
                UI.ToggleHotkey('Misc', 'JAVASCRIPT', 'Script items', "Override Hotkey")
            }
            if (!setOnce) {
                UI.SetValue("Rage", "PISTOL", "Targeting", "Minimum damage", pistol.omin)
                UI.SetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage", heavypistol.omin)
                UI.SetValue("Rage", "SCOUT", "Targeting", "Minimum damage", scout.omin)
                UI.SetValue("Rage", "AWP", "Targeting", "Minimum damage", awp.omin)
                UI.SetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage", autosniper.omin)
                UI.SetValue("Rage", "GENERAL", "Targeting", "Minimum damage", general.omin)
                setOnce = true;
            }
            general.omin = UI.GetValue("Rage", "GENERAL", "Targeting", "Minimum damage")
            pistol.omin = UI.GetValue("Rage", "PISTOL", "Targeting", "Minimum damage")
            heavypistol.omin = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage")
            scout.omin = UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage")
            awp.omin = UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage")
            autosniper.omin = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage")


            general.min = UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "General Override")
            pistol.min = UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "Pistol Override")
            heavypistol.min = UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "Heavy Pistol Override")
            scout.min = UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "Scout Override")
            awp.min = UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "AWP Override")
            autosniper.min = UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "Autosniper Override")
        }
        else {
            if (UI.IsHotkeyActive('Misc', 'JAVASCRIPT', 'Script items', "Override Hotkey")) {
                UI.SetValue("Rage", "PISTOL", "Targeting", "Minimum damage", pistol.min)
                UI.SetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage", heavypistol.min)
                UI.SetValue("Rage", "SCOUT", "Targeting", "Minimum damage", scout.min)
                UI.SetValue("Rage", "AWP", "Targeting", "Minimum damage", awp.min)
                UI.SetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage", autosniper.min)
                UI.SetValue("Rage", "GENERAL", "Targeting", "Minimum damage", general.min)

            }
            else {
                UI.SetValue("Rage", "PISTOL", "Targeting", "Minimum damage", pistol.omin)
                UI.SetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage", heavypistol.omin)
                UI.SetValue("Rage", "SCOUT", "Targeting", "Minimum damage", scout.omin)
                UI.SetValue("Rage", "AWP", "Targeting", "Minimum damage", awp.omin)
                UI.SetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage", autosniper.omin)
                UI.SetValue("Rage", "GENERAL", "Targeting", "Minimum damage", general.omin)
            }
            setOnce = false;
        }
}

function handleMenu() {
        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "General Override", false);
        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Pistol Override", false);
        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Heavy Pistol Override", false);
        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Scout Override", false);
        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "AWP Override", false);
        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Autosniper Override", false);
        var selected = fetchDropdown("Weapon type")
        if (selected.indexOf("General") != -1) {
            UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "General Override", true);
        }
        else if (selected.indexOf("Pistol") != -1) {
            UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Pistol Override", true);
        }
        else if (selected.indexOf("Heavy Pistol") != -1) {
            UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Heavy Pistol Override", true);
        }
        else if (selected.indexOf("Scout") != -1) {
            UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Scout Override", true);
        }
        else if (selected.indexOf("AWP") != -1) {
            UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "AWP Override", true);
        }
        else if (selected.indexOf("Autosniper") != -1) {
            UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Autosniper Override", true);
        }

    }

function main() {
        UI.AddHotkey("Override Hotkey")
        createDropdown("Weapon type", ["General", "Pistol", "Heavy Pistol", "Scout", "AWP", "Autosniper"], false);
        UI.AddSliderInt("General Override", 0, 130);
        UI.AddSliderInt("Pistol Override", 0, 130);
        UI.AddSliderInt("Heavy Pistol Override", 0, 130);
        UI.AddSliderInt("Scout Override", 0, 130);
        UI.AddSliderInt("AWP Override", 0, 130);
        UI.AddSliderInt("Autosniper Override", 0, 130);

        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "General Override", false);
        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Pistol Override", false);
        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Heavy Pistol Override", false);
        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Scout Override", false);
        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "AWP Override", false);
        UI.SetEnabled('Misc', 'JAVASCRIPT', 'Script items', "Autosniper Override", false);



        general = new WeaponCFG(UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "General Override"), UI.GetValue("Rage", "GENERAL", "Targeting", "Minimum damage"))
        pistol = new WeaponCFG(UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "Pistol Override"), UI.GetValue("Rage", "PISTOL", "Targeting", "Minimum damage"))
        heavypistol = new WeaponCFG(UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "Heavy Pistol Override"), UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage"))
        scout = new WeaponCFG(UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "Scout Override"), UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage"))
        awp = new WeaponCFG(UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "AWP Override"), UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage"))
        autosniper = new WeaponCFG(UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', "Autosniper Override"), UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage"))

    }
main();

    Cheat.RegisterCallback("Draw", "render")
    Cheat.RegisterCallback("Draw", "handleDamage")
    Cheat.RegisterCallback("Draw", "handleMenu")