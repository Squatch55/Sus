var screen_size = Global.GetScreenSize();

var isLeftActive = UI.IsHotkeyActive( "Misc", "JAVASCRIPT", "Script items", "Left Hotkey" );
var isRightActive = UI.IsHotkeyActive( "Misc", "JAVASCRIPT", "Script items", "Right Hotkey" );
var isBackwardsActive = UI.IsHotkeyActive( "Misc", "JAVASCRIPT", "Script items", "Backwards Hotkey" );
var isForwardActive = UI.IsHotkeyActive( "Misc", "JAVASCRIPT", "Script items", "Forward Hotkey" );
var isInverted; 
var drawLeft = 0; drawHideReal = 1;
var drawRight = 0, drawBack = 1;
var leftWasPressed = false; var rightWasPressed = false; var backWasPressed = false; var upWasPressed = false;
var time, delay, fillbar, shotsfired;

function isDoubleTapActive()
{
	var isCheckboxActive = UI.GetValue("Rage", "Exploits", "Doubletap");
	var isKeyActive = UI.IsHotkeyActive("Rage", "Exploits", "Doubletap");
	
	return isCheckboxActive && isKeyActive;
}

function correctLBYMode()
{
	if (isDoubleTapActive() == 1)
	{
			UI.SetValue("Anti-Aim", "Fake angles", "LBY mode", "0")
			UI.SetValue("Rage", "AUTOSNIPER", "Accuracy", "Auto stop mode", 2);
	}
	else
	{
			UI.SetValue("Anti-Aim", "Fake angles", "LBY mode", "1")
			UI.SetValue("Rage", "AUTOSNIPER", "Accuracy", "Auto stop mode", 66);
	}
}

correctLBYMode();

//Weapon fire event
function EVENT_WEAPON_FIRE()
{
    iShotsFired = Event.GetInt("userid"); iShotsFired_index = Entity.GetEntityFromUserID(iShotsFired);
 
    if(Entity.GetLocalPlayer() == iShotsFired_index)
    {
        if(UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap", "Enabled"))
        {
            //Released only once
            if(shotsfired == 0)
            {
                time = Globals.Curtime();
                delay = time+0.3;
                fillbar = 0;
            }            
        }    
    }    
}


var jump = false

function drawString()
{
	correctLBYMode();

	arrows_color = UI.GetColor( "Misc", "JAVASCRIPT", "Script items", "Arrows color" );
	s_arrow_color = UI.GetColor( "Misc", "JAVASCRIPT", "Script items", "Selected arrow color" );
	arrows_dist = UI.GetValue( "Misc", "JAVASCRIPT", "Script items", "Arrows dist" );

	rainbow = UI.GetValue( "Misc", "JAVASCRIPT", "Script items", "Rainbow mode" );
	pulse = UI.GetValue( "Misc", "JAVASCRIPT", "Script items", "Pulse mode" );

	x = UI.GetValue( "Misc", "JAVASCRIPT", "Script items", "X int for indicators" );
	y = UI.GetValue( "Misc", "JAVASCRIPT", "Script items", "Y int for indicators" );
	
	isDoubletap = UI.IsHotkeyActive("Rage", "Exploits", "Doubletap");
	isInverted = UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter");
	isHideReal = UI.GetValue("Anti-Aim", "Fake angles", "Hide real angle");
	isHIDESHOTS = UI.IsHotkeyActive("Rage", "Exploits", "Hide shots");
	isDMG = UI.IsHotkeyActive("Rage", "Damage", "Minimum damage (on key)");
	isSP = UI.IsHotkeyActive("Rage", "General", "Safe point override");
	isOVHBX = UI.IsHotkeyActive("Rage", "General config", "Hitbox override");
	isFD = UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck");
	arrows_type = UI.GetValue( "Misc", "JAVASCRIPT", "Script items", "Arrows" );
	isDesyncMode = UI.GetValue("Anti-Aim", "Fake angles", "Fake desync");
	isLbyMode = UI.GetValue("Anti-Aim", "Fake angles", "LBY mode");
	localplayer_index = Entity.GetLocalPlayer( );
	localplayer_alive = Entity.IsAlive( localplayer_index );

	var r = Math.floor( Math.sin( Globals.Realtime() * 2) * 127 + 128);
	var g = Math.floor( Math.sin( Globals.Realtime() * 2 + 2 ) * 127 + 128 );
	var b = Math.floor( Math.sin( Globals.Realtime() * 2 + 4 ) * 127 + 128 );

	const alpha = Math.sin(Math.abs(-Math.PI + (Globals.Curtime() * (1 / .75)) % (Math.PI * 2))) * 255;
	const _alpha = Math.sin(Math.abs(-Math.PI + (Globals.Curtime() * (1 / .75)) % (Math.PI * 2))) * s_arrow_color[3];

	if (rainbow) {
		UI.SetColor("Misc", "JAVASCRIPT", "Script items", "Selected arrow color", [r, g, b, s_arrow_color[3]]);
	}

	if (!localplayer_alive) { return }

	if (isLbyMode == 0) {
		value = "NO"
	}
    else if (isLbyMode == 1) {
		value = "OPPOSITE"
	}
	else if (isLbyMode == 2) {
		value = "SWAY"
	}

	isInverted = !isDesyncMode ? isInverted : !isInverted

	is_DT = false

	g_Local = Entity.GetLocalPlayer( );
	g_Local_weapon = Entity.GetWeapon(g_Local);
	weapon_name = Entity.GetName(g_Local_weapon);
	g_Local_classname = Entity.GetClassName( g_Local_weapon );

	DT = "DT ";
	add_y = 58+9;
	dt_color = [255,0,0,255]

	if(UI.GetValue( "Rage", "GENERAL", "Exploits", "Doubletap" ))
    {
        //Enabled
        if(isDoubletap)
        {
            curtime = Globals.Curtime();
         
            //>_<
            if (curtime <= delay)
            {
                fillbar+=2;
                shotsfired = 1;    
             
                //Not allowing fill more
				if (fillbar >= 30) fillbar = 30;
				dt_color = [255, 0, 0, 255] // ORANGE
			}
            else
            {
				dt_color = [0, 255, 0, 255] // GREEN
                shotsfired = 0;    //Released
            }    
        }
        else
        {
			//Disabled
			dt_color = [255, 0, 0, 255] // RED
        }    
    }     
	
	if ((g_Local_classname == "CKnife" || g_Local_classname == "CWeaponSSG08" || g_Local_classname == "CWeaponAWP" || weapon_name == "r8 revolver" || g_Local_classname == "CHEGrenade" || g_Local_classname == "CMolotovGrenade" || g_Local_classname == "CIncendiaryGrenade" || g_Local_classname == "CFlashbang" || g_Local_classname == "CSmokeGrenade" || g_Local_classname == "CDecoyGrenade" || g_Local_classname == "CWeaponTaser" || g_Local_classname == "CC4")) 
	{
		if (isFD) {
			DT = DT + "(fakeduck)";
			dt_color[3] = alpha
		} else {
			DT = DT + "(active weapon)";
			dt_color[3] = alpha
		} 
		is_DT = false;
	} else 
	{
		DT = isFD ? "DT (fakeduck)" : "DT ";
		is_DT = !isFD & isDoubletap;
		dt_color[3] = isFD ? alpha : 255
	}

	UI.SetValue( "Rage", "Exploits", "Doubletap", is_DT );
	if (arrows_type == 1) {

		//Polygon Points
		LPx = [(screen_size[0] /2) - arrows_dist, (screen_size[1] /2) + 10];
		LPy = [(screen_size[0] /2) - arrows_dist, (screen_size[1] /2) - 10];
		LPz = [(screen_size[0] /2) - (20+arrows_dist), (screen_size[1] /2)];
		RPx = [(screen_size[0] /2) + arrows_dist, (screen_size[1] /2) + 10];
		RPy = [(screen_size[0] /2) + arrows_dist, (screen_size[1] /2) - 10];
		RPz = [(screen_size[0] /2) + (20+arrows_dist), (screen_size[1] /2)];
		LPxx = [(screen_size[0] /2) - (arrows_dist - 1), (screen_size[1] /2) + 12];
		LPyy = [(screen_size[0] /2) - (arrows_dist - 1), (screen_size[1] /2) - 12];
		LPzz = [(screen_size[0] /2) - (23+arrows_dist), (screen_size[1] /2)];
		RPxx = [(screen_size[0] /2) + (arrows_dist - 1), (screen_size[1] /2) + 12];
		RPyy = [(screen_size[0] /2) + (arrows_dist - 1), (screen_size[1] /2) - 12];
		RPzz = [(screen_size[0] /2) + (23+arrows_dist), (screen_size[1] /2)];
		BPx = [(screen_size[0] /2) + 10, (screen_size[1] /2) + arrows_dist];
		BPy = [(screen_size[0] /2) - 10, (screen_size[1] /2) + arrows_dist];
		BPz = [(screen_size[0] /2), (screen_size[1] /2) + (20+arrows_dist)];
		BPxx = [(screen_size[0] /2) + 12, (screen_size[1] /2) + (arrows_dist - 1)];
		BPyy = [(screen_size[0] /2) - 12, (screen_size[1] /2) + (arrows_dist - 1)];
		BPzz = [(screen_size[0] /2), (screen_size[1] /2) + (23+arrows_dist)];
		
		/*	OLD ARROWS
		Render.Polygon( [ [ screen_size[0]/2 - (17+arrows_dist + 1), screen_size[1]/2 + 1], [ screen_size[0]/2 - (arrows_dist + 1), screen_size[1]/2 -9 ], [ screen_size[0]/2 - ( arrows_dist + 1 ), screen_size[1]/2 + 11] ], drawLeft ? [0, 0, 0, _alpha] : [0,0,0, arrows_color[3] ] ); // LEFT 00869
		Render.Polygon( [ [ screen_size[0]/2 - 11, screen_size[1]/2 + (arrows_dist + 1) ], [ screen_size[0]/2 + 9, screen_size[1]/2 +(arrows_dist + 1) ], [ screen_size[0]/2 - 1, screen_size[1]/2 + (17+arrows_dist + 1)] ], drawBack ? [0, 0, 0, _alpha] : [0,0,0, arrows_color[3] ] ); // BACK
		Render.Polygon( [ [ screen_size[0]/2 + (arrows_dist - 1), screen_size[1]/2 + 11], [ screen_size[0]/2 + (arrows_dist - 1), screen_size[1]/2 -9], [ screen_size[0]/2 + (17+arrows_dist - 1), screen_size[1]/2 + 1] ], drawRight ? [0, 0, 0, _alpha] : [0,0,0, arrows_color[3] ] ); // RIGHT

		Render.Polygon( [ [ screen_size[0]/2 - (17+arrows_dist), screen_size[1]/2 ], [ screen_size[0]/2 - arrows_dist, screen_size[1]/2 -10 ], [ screen_size[0]/2 - arrows_dist, screen_size[1]/2 + 10] ], drawLeft ? [s_arrow_color[0], s_arrow_color[1], s_arrow_color[2], _alpha] : arrows_color ); // LEFT
		Render.Polygon( [ [ screen_size[0]/2 - 10, screen_size[1]/2 + arrows_dist ], [ screen_size[0]/2 + 10, screen_size[1]/2 +arrows_dist ], [ screen_size[0]/2, screen_size[1]/2 + (17+arrows_dist)] ], drawBack ? [s_arrow_color[0], s_arrow_color[1], s_arrow_color[2], _alpha] : arrows_color ); // BACK
		Render.Polygon( [ [ screen_size[0]/2 + arrows_dist, screen_size[1]/2 + 10], [ screen_size[0]/2 + arrows_dist, screen_size[1]/2 -10], [ screen_size[0]/2 + (17+arrows_dist), screen_size[1]/2] ], drawRight ? [s_arrow_color[0], s_arrow_color[1], s_arrow_color[2], _alpha] : arrows_color ); // RIGHT
		*/

		Render.Polygon([LPxx, LPzz, LPyy], [0,0,0,60] );
		Render.Polygon([RPyy, RPzz, RPxx], [0,0,0,60] );
		Render.Polygon([BPyy, BPxx, BPzz], [0,0,0,60] );
		const s_color = [ s_arrow_color[0], s_arrow_color[1],s_arrow_color[2], pulse ? _alpha : s_arrow_color[3] ]

		Render.Polygon([LPx, LPz, LPy], drawLeft ? s_color : arrows_color );
		Render.Polygon([RPy, RPz, RPx], drawRight ? s_color : arrows_color );
		Render.Polygon([BPy, BPx, BPz], drawBack ? s_color : arrows_color );

	}
	if (arrows_type == 2) {
		Render.String(screen_size[0]/2 -50, screen_size[1]/2 -20, 1,  "<", drawLeft ? s_color : arrows_color, 4 );
		Render.String(screen_size[0]/2 +50, screen_size[1]/2 -20, 1,  ">", drawRight ? s_color : arrows_color, 4 );
		Render.String(screen_size[0]/2, screen_size[1]/2 +20, 1,  "v", drawBack ? s_color : arrows_color, 4 );		
	}

		Render.String(x +4+2, y + 49 + 1, 0, value, [0,0,0,255],3 );
	    Render.String(x +4+2, y + 49 + 9 + 1, 0, isHideReal ? "DYNAMIC" : (isInverted ? "LEFT" : "RIGHT"), [0,0,0,255],3 );
		Render.String(x +4+2, y + 58 + 9 + 1, 0, is_DT ? DT : DT, [0,0,0,255],3 );

		Render.String(x +5, y + 49, 0, value, [ 177, 151, 255, 255],3 );
		Render.String(x +5, y + 49 + 9, 0, isHideReal ? "DYNAMIC" : (isInverted ? "LEFT" : "RIGHT"), [ 209, 139, 230, 255 ],3 );
		Render.String(x +5, y + 58 + 9, 0, is_DT ? DT : DT, dt_color,3 );
		if (isHIDESHOTS) {
			add_y = add_y + 9;
			Render.String(x +4+2, y + add_y+1, 0, "ONSHOT", [0,0,0,255],3 );
			Render.String(x +5, y + add_y, 0, "ONSHOT", [ 124, 195, 13, 255 ],3 );
		}
		if (isDMG) {
			add_y = add_y + 9;
			Render.String(x +4+2, y + add_y+1, 0, "DMG", [0,0,0,255],3 );
		    Render.String(x +5, y + add_y, 0, "DMG", [ 255, 255, 255, 255 ],3 );
		}
		if (isFD) {
			add_y = add_y + 9;
			Render.String(x +4+2, y + add_y+1, 0, "DUCK", [0,0,0,255] ,3 );
			Render.String(x +5, y + add_y, 0, "DUCK", [ 255, 255, 255, alpha ] ,3 );
		}
		if (isSP) {
			add_y = add_y + 9;
			Render.String(x +4+2, y + add_y+1, 0, "SAFE", [0,0,0,255] ,3 );
			Render.String(x +5, y + add_y, 0, "SAFE", [ 124, 195, 13, 255 ] ,3 );
		}
		if (isOVHBX) {
			add_y = add_y + 9;
			Render.String(x +4+2, y + add_y+1, 0, "BAIM", [0,0,0,255] ,3 );
			Render.String(x +5, y + add_y, 0, "BAIM", [ 124, 195, 13, 255 ] ,3 );
		}
}
var oldTick = 0
var lastPressed = 0
var isHideRealActive = false
function onCreateMove()
{
	isLeftActive = UI.IsHotkeyActive( "Misc", "JAVASCRIPT", "Script items", "Left Hotkey" );
	isRightActive = UI.IsHotkeyActive( "Misc", "JAVASCRIPT", "Script items", "Right Hotkey" );
	isBackwardsActive = UI.IsHotkeyActive( "Misc", "JAVASCRIPT", "Script items", "Backwards Hotkey" );
	isForwardActive = UI.IsHotkeyActive( "Misc", "JAVASCRIPT", "Script items", "Forward Hotkey" );
	
	
	if(isLeftActive && leftWasPressed == false)
	{	
		lastPressed = Global.Tickcount();
		isHideRealActive = false;
		leftWasPressed = true;
		backWasPressed = false;
		rightWasPressed = false;
		upWasPressed = false;
		drawLeft = 1;
		drawBack = 0;
		drawRight = 0;
		UI.SetValue( "Anti-Aim", "Rage Anti-Aim", "Yaw offset", -90 );
		UI.SetValue( "Anti-Aim", "Fake Angles", "Hide real angle", false);
	} else if(isLeftActive && leftWasPressed == true && Global.Tickcount() > lastPressed + 16){
		isHideRealActive = true;
		oldTick = Global.Tickcount();
	}
	if(isRightActive && rightWasPressed == false)
	{	
		lastPressed = Global.Tickcount();
		isHideRealActive = false;
		backWasPressed = false;
		leftWasPressed = false;
		rightWasPressed = true;
		upWasPressed = false;
		drawLeft = 0;
		drawBack = 0;
		drawRight = 1;
		UI.SetValue( "Anti-Aim", "Rage Anti-Aim", "Yaw offset", 90 );
		UI.SetValue( "Anti-Aim", "Fake Angles", "Hide real angle", false);
		
	} else if(isRightActive && rightWasPressed == true && Global.Tickcount() > lastPressed + 16){
		isHideRealActive = true;
		oldTick = Global.Tickcount();
	}
	if(isBackwardsActive && backWasPressed == false && Global.Tickcount() > lastPressed + 16)
	{	
		lastPressed = Global.Tickcount();
		isHideRealActive = false;
		backWasPressed = true;
		rightWasPressed = false;
		leftWasPressed = false;
		upWasPressed = false;
		drawLeft = 0;
		drawBack = 1;
		drawRight = 0;
		UI.SetValue( "Anti-Aim", "Rage Anti-Aim", "Yaw offset", 3 );
		UI.SetValue( "Anti-Aim", "Fake Angles", "Hide real angle", false);
	} else if(isBackwardsActive && backWasPressed == true && Global.Tickcount() > lastPressed + 16) {
		isHideRealActive = true;
		oldTick = Global.Tickcount();
	}
	if(isForwardActive && upWasPressed == false && Global.Tickcount() > lastPressed + 16)
	{	
		lastPressed = Global.Tickcount();
		isHideRealActive = false;
		backWasPressed = false;
		rightWasPressed = false;
		leftWasPressed = false;
		upWasPressed = true;
		drawLeft = 0;
		drawBack = 0;
		drawRight = 0;
		UI.SetValue( "Anti-Aim", "Rage Anti-Aim", "Yaw offset", 180 );
		UI.SetValue( "Anti-Aim", "Fake Angles", "Hide real angle", false);
	}
	if(isHideRealActive)
	{
		
		if (Global.Tickcount() > oldTick + 16){
			backWasPressed = false;
			rightWasPressed = false;
			leftWasPressed = false;
			upWasPressed = false;
			oldTick = Global.Tickcount();
		}
		
		drawLeft = 0;
		drawBack = 0;
		drawRight = 0;
		UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 5 );
		UI.SetValue("Anti-Aim", "Fake Angles", "Hide real angle", true);
	}
	UI.SetValue( "Anti-Aim", "Rage Anti-Aim", "At targets", isHideRealActive ? true : false ); 
}

function player_connect(){
    lastPressed = Global.Tickcount();
    oldTick = Global.Tickcount();

    time = Globals.Curtime();
    delay = time+0.3;
}

function Main()
{
	UI.AddDropdown( "Arrows", [ "Off", "triangle", "arrows" ] );
	UI.AddColorPicker( "Arrows color" )
	UI.AddColorPicker( "Selected arrow color" )
	UI.AddSliderInt( "Arrows dist", 20, 100 );
	UI.AddCheckbox( "Rainbow mode");
	UI.AddCheckbox( "Pulse mode");

	UI.AddSliderInt( "X int for indicators", 1, 4000 );
	UI.AddSliderInt( "Y int for indicators", 1, 4000 );


	UI.AddHotkey( "Left Hotkey" );
	UI.AddHotkey( "Right Hotkey" );
	UI.AddHotkey( "Backwards Hotkey" );
	UI.AddHotkey( "Forward Hotkey" );
	
	//  callbacks
	Global.RegisterCallback("Draw", "drawString")
	Global.RegisterCallback("CreateMove", "onCreateMove")
	Global.RegisterCallback("player_connect_full", "player_connect")
	Global.RegisterCallback("weapon_fire", "EVENT_WEAPON_FIRE");
}
Main();


