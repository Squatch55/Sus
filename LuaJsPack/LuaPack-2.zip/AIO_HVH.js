Cheat.PrintChat("[DELP] " + "Thanks for using delp config!");
UI.AddSliderInt("                +Anti-Aim+", 0, 0);


//Freestanding
/**
 *
 * Title: Advanced body freestanding
 * Author: april#0001
 * Description: Gives more anti-aim customization for advanced users.
 *
 */

//region api

// Localizing all of the functions in snake_case because why not.
const global_print = Global.Print, global_print_chat = Global.PrintChat, global_print_color = Global.PrintColor, global_register_callback = Global.RegisterCallback, global_execute_command = Global.ExecuteCommand, global_frame_stage = Global.FrameStage, global_tickcount = Global.Tickcount, global_tickrate = Global.Tickrate, global_tick_interval = Global.TickInterval, global_curtime = Global.Curtime, global_realtime = Global.Realtime, global_frametime = Global.Frametime, global_latency = Global.Latency, global_get_view_angles = Global.GetViewAngles, global_set_view_angles = Global.SetViewAngles, global_get_map_name = Global.GetMapName, global_is_key_pressed = Global.IsKeyPressed, global_get_screen_size = Global.GetScreenSize, global_get_cursor_position = Global.GetCursorPosition, global_play_sound = Global.PlaySound, global_play_microphone = Global.PlayMicrophone, global_stop_microphone = Global.StopMicrophone, global_get_username = Global.GetUsername, global_set_clan_tag = Global.SetClanTag, globals_tickcount = Globals.Tickcount, globals_tickrate = Globals.Tickrate, globals_tick_interval = Globals.TickInterval, globals_curtime = Globals.Curtime, globals_realtime = Globals.Realtime, globals_frametime = Globals.Frametime, sound_play = Sound.Play, sound_play_microphone = Sound.PlayMicrophone, sound_stop_microphone = Sound.StopMicrophone, cheat_get_username = Cheat.GetUsername, cheat_register_callback = cheat_register_callback = new Proxy(Cheat.RegisterCallback, { apply: function(_, _, args) { switch(args[0]) { case 'paint': Cheat.RegisterCallback('Draw', args[1]); break; case 'create_move': Cheat.RegisterCallback('CreateMove', args[1]); break; case 'fsn': Cheat.RegisterCallback('FrameStageNotify', args[1]); break; default: Cheat.RegisterCallback(args[0], args[1]); break; } } }), cheat_execute_command = Cheat.ExecuteCommand, cheat_frame_stage = Cheat.FrameStage, cheat_print = Cheat.Print, cheat_print_chat = Cheat.PrintChat, cheat_print_color = Cheat.PrintColor, local_latency = Local.Latency, local_get_view_angles = Local.GetViewAngles, local_set_view_angles = Local.SetViewAngles, local_set_clan_tag = Local.SetClanTag, local_get_real_yaw = Local.GetRealYaw, local_get_fake_yaw = Local.GetFakeYaw, local_get_spread = Local.GetSpread, local_get_inaccuracy = Local.GetInaccuracy, world_get_map_name = World.GetMapName, world_get_server_string = World.GetServerString, input_get_cursor_position = Input.GetCursorPosition, input_is_key_pressed = Input.IsKeyPressed, render_string = Render.String, render_text_size = Render.TextSize, render_line = Render.Line, render_rect = Render.Rect, render_filled_rect = Render.FilledRect, render_gradient_rect = Render.GradientRect, render_circle = Render.Circle, render_filled_circle = Render.FilledCircle, render_polygon = Render.Polygon, render_world_to_screen = Render.WorldToScreen, render_add_font = Render.AddFont, render_find_font = Render.FindFont, render_string_custom = Render.StringCustom, render_textured_rect = Render.TexturedRect, render_add_texture = Render.AddTexture, render_text_size_custom = Render.TextSizeCustom, render_get_screen_size = Render.GetScreenSize, ui_get_value = UI.GetValue, ui_set_value = UI.SetValue, ui_add_checkbox = UI.AddCheckbox, ui_add_slider_int = UI.AddSliderInt, ui_add_slider_float = UI.AddSliderFloat, ui_add_hotkey = UI.AddHotkey, ui_add_label = UI.AddLabel, ui_add_dropdown = UI.AddDropdown, ui_add_multi_dropdown = UI.AddMultiDropdown, ui_add_color_picker = UI.AddColorPicker, ui_add_textbox = UI.AddTextbox, ui_set_enabled = UI.SetEnabled, ui_get_string = UI.GetString, ui_get_color = UI.GetColor, ui_set_color = UI.SetColor, ui_is_hotkey_active = UI.IsHotkeyActive, ui_toggle_hotkey = UI.ToggleHotkey, ui_is_menu_open = UI.IsMenuOpen, convar_get_int = Convar.GetInt, convar_set_int = Convar.SetInt, convar_get_float = Convar.GetFloat, convar_set_float = Convar.SetFloat, convar_get_string = Convar.GetString, convar_set_string = Convar.SetString, event_get_int = Event.GetInt, event_get_float = Event.GetFloat, event_get_string = Event.GetString, entity_get_entities = Entity.GetEntities, entity_get_entities_by_class_i_d = Entity.GetEntitiesByClassID, entity_get_players = Entity.GetPlayers, entity_get_enemies = Entity.GetEnemies, entity_get_teammates = Entity.GetTeammates, entity_get_local_player = Entity.GetLocalPlayer, entity_get_game_rules_proxy = Entity.GetGameRulesProxy, entity_get_entity_from_user_i_d = Entity.GetEntityFromUserID, entity_is_teammate = Entity.IsTeammate, entity_is_enemy = Entity.IsEnemy, entity_is_bot = Entity.IsBot, entity_is_local_player = Entity.IsLocalPlayer, entity_is_valid = Entity.IsValid, entity_is_alive = Entity.IsAlive, entity_is_dormant = Entity.IsDormant, entity_get_class_i_d = Entity.GetClassID, entity_get_class_name = Entity.GetClassName, entity_get_name = Entity.GetName, entity_get_weapon = Entity.GetWeapon, entity_get_weapons = Entity.GetWeapons, entity_get_render_origin = Entity.GetRenderOrigin, entity_get_prop = Entity.GetProp, entity_set_prop = Entity.SetProp, entity_get_hitbox_position = Entity.GetHitboxPosition, entity_get_eye_position = Entity.GetEyePosition, trace_line = Trace.Line, trace_bullet = Trace.Bullet, usercmd_set_movement = UserCMD.SetMovement, usercmd_get_movement = UserCMD.GetMovement, usercmd_set_angles = UserCMD.SetAngles, usercmd_force_jump = UserCMD.ForceJump, usercmd_force_crouch = UserCMD.ForceCrouch, antiaim_get_override = AntiAim.GetOverride, antiaim_set_override = AntiAim.SetOverride, antiaim_set_real_offset = AntiAim.SetRealOffset, antiaim_set_fake_offset = AntiAim.SetFakeOffset, antiaim_set_l_b_y_offset = AntiAim.SetLBYOffset, exploit_get_charge = Exploit.GetCharge, exploit_recharge = Exploit.Recharge, exploit_disable_recharge = Exploit.DisableRecharge, exploit_enable_recharge = Exploit.EnableRecharge, ragebot_override_minimum_damage = Ragebot.OverrideMinimumDamage, ragebot_override_hitchance = Ragebot.OverrideHitchance, ragebot_override_accuracy_boost = Ragebot.OverrideAccuracyBoost, ragebot_override_multipoint_scale = Ragebot.OverrideMultipointScale, ragebot_force_safety = Ragebot.ForceSafety;
//endregion

//region dependencies

/**
 * @title BetterUI
 * @version 2.0.1
 * @description A better UI system for Onetap
 */

var menu1 = {
    _class: 'BetterUI'
};
const menu1_spacer = "                                                                                  ";

/**
 * Concats two elements into an array without increasing the array length.
 * Prevents the memory leak in 2.0.0 from happening
 * 
 * @param a {array}
 * @param b {any}
 */
menu1.concat = function(a, b)
{
    // Creates a new array.
    var arr = [];

    // Push all items from the array 'a' into our array.
    for (var c in a)
    {
        arr.push(a[c]);
    }

    // Push the value 'b' into our array.
    arr.push(b);

    // Return the new array.
    return arr;
}

/**
 * Creates a new menu label
 *
 * @param label {string}
 */
menu1.label = function(label)
{
    // Creates the label
    UI.AddLabel(label);
};

/**
 * Creates a new menu element
 *
 * @param func {function}
 * @param name {string}
 * @param label {string},
 * @param properties {array}
 */
menu1.call = function(func, name, label, properties)
{
    // Get properties
    const final_name = name + menu1_spacer + label;
    var final_props = [final_name];
    const element_info_t = {
        path: ["Misc", "JAVASCRIPT", final_name]
    };

    // If our properties aren't null, then pack them together.
    if (properties != null)
    {
        for (var i = 0; i < properties.length; i++)
        {
            final_props.push(properties[i]);
        }
    }

    // Create our menu element and return properties
    func.apply(null, final_props);
    return element_info_t;
};

/**
 * Creates a new menu reference
 *
 * @param path {array}
 */
menu1.reference = function(path)
{
    const element_info_t = {
        path: path
    };

    return element_info_t;
};

/**
 * Gets the value of a menu element
 *
 * @param elem {array}
 * @return {*}
 */
menu1.get = function(elem)
{
    // If the element doesn't exist
    if (!(elem.path))
        throw new Error("[Menu] This element doesn't exist!");

    // Returns the element's value
    return UI.GetValue.apply(null, elem.path);
};

/**
 * Gets the value of a menu element
 *
 * @param elem {array}
 * @return {*}
 */
menu1.get_hotkey = function(elem)
{
    // If the label doesn't exist
    if (!(elem.path))
        throw new Error("[Menu] This element doesn't exist!");

    // Returns the element's value
    return UI.IsHotkeyActive.apply(null, elem.path);
};

/**
 * Gets the value of a menu element
 *
 * @param elem {array}
 * @return {*}
 */
menu1.get_color = function(elem)
{
    // If the label doesn't exist
    if (!(elem.path))
        throw new Error("[Menu] This element doesn't exist!");

    // Returns the element's value
    return UI.GetColor.apply(null, elem.path);
};

/**
 * Sets the value of a menu element
 *
 * @param elem {array}
 * @param value {*}
 */
menu1.set = function(elem, value)
{
    // If the label doesn't exist
    if (!(elem.path))
        throw new Error("[Menu] This element doesn't exist!");

    // Get properties
    const properties = elem;

    // Set the element's value
    UI.SetValue.apply(null, this.concat(properties.path, value));
};

/**
 * Sets the value of a color picker
 *
 * @param elem {array}
 * @param color {array|Color}
 */
menu1.set_color = function(elem, color)
{
    // If the label doesn't exist
    if (!(elem.path))
        throw new Error("[Menu] This element doesn't exist!");

    // Get properties
    const properties = elem;

    // Set the element's value
    UI.SetColor.apply(null, this.concat(properties.path, color));
};

/**
 * Toggles a hotkey
 *
 * @param elem {array}
 */
menu1.toggle = function(elem)
{
    // If the label doesn't exist
    if (!(elem.path))
        throw new Error("[Menu] This element doesn't exist!");

    // Set the element's value
    UI.ToggleHotkey.apply(null, elem.path);
};

/**
 * Changes the visibility of a menu elements
 *
 * @param elem {array}
 * @param visible {boolean}
 */
menu1.visibility = function(elem, visible)
{
    // If the label doesn't exist
    if (!(elem.path))
        throw new Error("[Menu] This element doesn't exist!");

    // Get properties
    const properties = elem;

    // Change the element's visibility
    UI.SetEnabled.apply(null, this.concat(properties.path, visible));
};
/**
 * @title Vector
 * @description Simple 3d vector system
 *
 * @typedef Vector {x: number, y: number, z: number}
 */
var vector = {
    _class: 'vector'
};

/**
 * @brief Creates a new 3d vector instance.
 * @param data {array}
 * @returns {Vector}
 */
vector.new = function(data)
{
    return {
        x: data[0],
        y: data[1],
        z: data[2]
    };
};

/**
 * @brief Realizes a mathematical operation between two vectors.
 * @param vec {Vector}
 * @param vec2 {Vector}
 * @param operation {string}
 * @returns {Vector}
 */
vector.operate = function(vec, vec2, operation)
{
  switch (operation)
  {
      case '+':
          return {
              x: vec.x + vec2.x,
              y: vec.y + vec2.y,
              z: vec.z + vec2.z
          };

      case '-':
          return {
              x: vec.x - vec2.x,
              y: vec.y - vec2.y,
              z: vec.z - vec2.z
          };

      case '*':
          return {
              x: vec.x * vec2.x,
              y: vec.y * vec2.y,
              z: vec.z * vec2.z
          };

      case '/':
          return {
              x: vec.x / vec2.x,
              y: vec.y / vec2.y,
              z: vec.z / vec2.z
          };

      default:
          throw new Error("[Vector] Invalid operation type.");
  }
};

/**
 * @brief Returns the 2d length of a vector.
 * @param vec {Vector}
 * @returns {number}
 */
vector.length2d = function(vec)
{
    return Math.sqrt(vec.x * vec.x + vec.y * vec.y);
};

/**
 * @brief Converts a vector to angles.
 * @param vec
 * @returns {Vector}
 */
vector.angles = function(vec)
{
    return {
        x: -Math.atan2(vec.z, this.length2d(vec)) * 180 / Math.PI,
        y: Math.atan2(vec.y, vec.x) * 180 / Math.PI,
        z: 0
    };
};

/**
 * @brief Calculates the fov delta between two points based on a specific view angles.
 * @param origin {Vector}
 * @param destination {Vector}
 * @param view {Vector}
 * @returns {number}
 */
vector.fov_to = function(origin, destination, view)
{
    const angles = this.angles(this.operate(destination, origin, '-'));

    const delta = this.new(
        [
            Math.abs(view.x - angles.x),
            Math.abs(view.y % 360 - angles.y % 360) % 360,
            0
        ]
    );

    if (delta.y > 180)
        delta.y = 360 - delta.y;

    return this.length2d(delta);
};

/**
 * @brief Unpacks a vector object into an array.
 * @param vec {Vector}
 * @returns {[number, number, number]}
 */
vector.to_array = function(vec)
{
    return [
        vec.x,
        vec.y,
        vec.z
    ];
};

/**
 * @brief Normalizes an yaw angle.
 * @param angle {number}
 * @returns {number}
 */
function normalize_yaw(angle)
{
    var adjusted_yaw = angle;

    if (adjusted_yaw < -180)
        adjusted_yaw += 360;

    if (adjusted_yaw > 180)
        adjusted_yaw -= 360;

    return adjusted_yaw;
}

//endregion

//region main

// Create our main instance
var plugin = {
    _info: {
        _title: "Advanced body freestanding",
        _version: "1.1.0",
        _author: "april#0001"
    },

    last_hit_lby: [],
    last_target_visibility: false,
    override_flip: false,
    last_override_time: globals_curtime( )
};

//endregion

//region menu

// Create our menu elements
const enable = menu1.call(ui_add_checkbox, "Advanced body freestanding", "lby_enable", []);
const body = menu1.call(ui_add_dropdown, "Body freestanding", "lby_body_mode", [["Hide real angle", "Hide fake angle"]]);
const smart = menu1.call(ui_add_checkbox, "Smart switch", "lby_smart", []);
const flip = menu1.call(ui_add_multi_dropdown, "Body inverter flip", "lby_body", [["Walk", "Run", "In air"]]);


// Declare our references
const ref_inverter = menu1.reference(["Anti-Aim", "Fake angles", "Inverter"]);
const ref_bodyflip = menu1.reference(["Anti-Aim", "Fake angles", "Inverter flip"]);
const ref_inverter_legit = menu1.reference(["Anti-Aim", "Legit Anti-Aim", "Direction key"]);
const ref_ragebot = menu1.reference(["Rage", "GENERAL", "General", "Enabled"]);

//endregion

//region functions

/**
 * @brief Inverts the lower body yaw to the specified value.
 * @param state {number} Whether or not to invert the lower body yaw.
 */
function update_anti_aim_state(state)
{
    // If our rage aimbot is enabled, than we should invert the
    // rage anti-aim.
    if (menu1.get(ref_ragebot))
    {
        // Check if our inverter's state is the same as our desired one.
        // If not, then toggle the hotkey to invert it.
        if (menu1.get_hotkey(ref_inverter) !== state)
            menu1.toggle(ref_inverter);

        // Return because we don't wanna do the same to the legit anti-aim's state.
        return;
    }

    // Invert the state because the legit anti-aim's inverter is different
    // from the rage one.
    state = (state + 1) % 2;

    // Check if our inverter's state is the same as our desired one.
    // If not, then toggle the hotkey to invert it.
    if (menu1.get_hotkey(ref_inverter_legit) !== state)
        menu1.toggle(ref_inverter_legit);
}

/**
 * @brief Gets the closest (FOV-based) enemy and returns its entity id.
 * @returns {number}
 */
function get_closest_target( ) {
    // Get our entities.
    const players = entity_get_enemies();
    const me = entity_get_local_player();

    // Initialize our data array.
    const data = {id: null, fov: 180};

    // Loop for each player in the server.
    for (var i = 0; i < players.length; i++) {
        // Get the current player.
        const e = players[i];

        // Get our eye's position, the player's head position and our view angles.
        const destination = vector.new(entity_get_hitbox_position(e, 0)),
            origin = vector.new(entity_get_eye_position(me));
        const angles = vector.new(local_get_view_angles());

        // Calculate the FOV distance.
        const fov = vector.fov_to(origin, destination, angles);

        // If our FOV distance is lower than the cached one, then it means that
        // there's another player which is even closer to our crosshair.
        if (fov < data.fov) {
            // Cache this entity and our current FOV distance for further
            // calculations.
            data.id = e;
            data.fov = fov;
        }
    }

    // Return the closest entity to our crosshair.
    return data.id;
}

/**
 * @brief Gets whether or not our target is visible.
 * @returns {boolean}
 */
function get_target_visibility( )
{
    // Get our target.
    const target = get_closest_target( );

    // If the target is not valid, then it is not visible.
    if (!target || !entity_is_valid(target))
        return false;

    // If it is dormant, than it isn't visible either.
    if (entity_is_dormant(target))
        return false;

    // Get our tracing properties.
    const me = entity_get_local_player( );
    var origin = vector.new(entity_get_eye_position(me)), velocity = vector.new(entity_get_prop(me, "CBasePlayer", "m_vecVelocity[0]")), destination = entity_get_hitbox_position(target, 0);

    // Adds our velocity vector to our origin vector as to make the trace
    // more accurate when moving.
    velocity = vector.operate(velocity, vector.new([0.25, 0.25, 0.25]), '*');
    origin = vector.operate(origin, velocity, '+');

    // Trace a line from our eye position to the target's head and see if we hit anything.
    const result = trace_line(me, vector.to_array(origin), destination)[0];

    // Return results.
    return result === target;
}

/**
 * @brief Gets which anti-aim side matches your settings the best. Or, in other words, does freestanding.
 */
function get_optimal_angle( )
{
    // Get current lower body yaw mode
    const _mode = menu1.get(body);

    // Get some properties.
    const me = entity_get_local_player( );

    // And more properties..
    const origin = vector.new(entity_get_render_origin(me));
    var yaw = local_get_view_angles( )[1];
    var data = {left: 0, right: 0};

    // Loops for every angle from the left of your yaw to the right of your yaw
    // in steps of 30, resulting in 3 steps per side.
    for (var r = yaw - 90; r <= yaw + 90; r += 30)
    {
        // If our current angle is the center one then there's no need
        // to do anything with it.
        if (r === yaw)
            continue;

        // Convert our angle to radians
        const rad = r * Math.PI / 180;

        // Create our destination point based on current angle.
        const point = vector.operate(
            origin,
            vector.new([
                256 * Math.cos(rad),
                256 * Math.sin(rad),
                0
            ]),
            "+"
        );

        // Trace a line from our player's origin to the current point.
        // Using this to check the trace's fraction (m_flFraction) until
        // it hits something and then add it to our data array.
        //
        // This is how my 'environmental freestanding' logic is made.
        // The side with lower fractions is the side which is logically
        // closer to the player's head.
        const line = trace_line(me, vector.to_array(origin), vector.to_array(point));

        // Get which side we're iterating on.
        const side = r < yaw ? "left" : "right";

        // Update our data array.
        data[side] += line[1];
    }

    // Calculates an average for both sides.
    data.left /= 3;
    data.right /= 3;

    // If our left avg. fractions are greater than the right ones, then return
    // the number 0 which corresponds to the right side, or, in the Hide fake angle mode,
    // return 1 which corresponds to the left side.
    if (data.left > data.right)
        return _mode === 0 ? 0 : 1;

    // Does the same thing as above, except the right avg. fractions are greater than
    // the left ones.
    return _mode === 0 ? 1 : 0;
}

/**
 * @brief Handles the inverter flip feature.
 */
function update_inverter_flip( )
{
    // Check if the inverter flip options are enabled.
    if (!menu1.get(flip))
        return;

    // Get some properties.
    const visible = get_target_visibility( );
    const now = globals_curtime( );

    // If it has been 300ms since the last override then
    // reset the override state.
    if (plugin.last_override_time + 0.3 < now)
        plugin.override_flip = false;

    // If our current target visibility isn't the same as
    // our cached one, then the target became visible/invisible.
    if (visible !== plugin.last_target_visibility)
    {
        // In this case, we should override, so, set override to
        // true and cache our current time.
        plugin.override_flip = true;
        plugin.last_override_time = now;
    }

    // Cache the target's visibility.
    plugin.last_target_visibility = visible;

    // Check if we're overriding
    if (plugin.override_flip)
    {
        // Set the inverter flip to nothing.
        menu1.set(ref_bodyflip, 0);
        return;
    }

    // If we're not overriding, then set the inverter flip options to
    // the selected options.
    menu1.set(ref_bodyflip, menu1.get(flip));
}

/**
 * @brief Updates our anti-aim based on the current freestanding mode and input.
 */
function update_anti_aim( )
{
    // Get our local player.
    const me = entity_get_local_player( );

    // Check if our player is valid and alive.
    if (!entity_is_valid(me) || !entity_is_alive(me))
        return;

    // Get if our anti-aim is on smart mode.
    const _smart = menu1.get(smart);

    // Handle the inverter flip.
    update_inverter_flip( );

    // If our anti-aim is set to 'Smart', then the entire logic is different.
    // The smart mode does not use freestanding as input, it uses data from
    // other users as input.
    if (_smart)
    {
        // Get our FOV-based target.
        const target = get_closest_target( );

        // Check if our target is valid.
        // Otherwise, just return our current freestanding angle.
        if (target == null)
        {
            update_anti_aim_state(get_optimal_angle( ));
            return;
        }

        // Check if our target has already hit us.
        // If not, then just return current freestanding angle.
        if (plugin.last_hit_lby[target] == null)
        {
            update_anti_aim_state(get_optimal_angle( ));
            return;
        }

        // Return the opposite angle to the last hit angle.
        // In this case if the inverter was off, now return on.
        if (plugin.last_hit_lby[target] === 0)
        {
            update_anti_aim_state(1);
            return;
        }

        // Or, if the inverter was on, return off.
        update_anti_aim_state(0);
        return;
    }

    // If our anti-aim is not on smart mode, then we're just using regular
    // freestanding. So, do freestanding.
    update_anti_aim_state(get_optimal_angle( ));
}

/**
 * @brief Renders our plugin's indicator.
 */
function do_indicators( )
{
    // Get our local player.
    const me = entity_get_local_player( );

    // Check if our player is valid and alive.
    if (!entity_is_valid(me) || !entity_is_alive(me))
        return;

    // Get our drawing properties.
    const y = render_get_screen_size( )[1];

    // Get our anti-aim info.
    const yaw = local_get_real_yaw( ), fake = local_get_fake_yaw( );
    var delta = Math.round(normalize_yaw(yaw - fake) / 2), abs = Math.abs(delta);

    // If we're using legit anti-aim, invert the delta.
    // Doing this to fix the indicators because legit
    // anti-aim inverter is different.
    if (menu1.get(ref_ragebot))
        delta *= -1;

    // Render the 'FAKE' indicator
    // Totally did not copy it from gamesense.
    render_string(10, y / 2 + 16, 0, "FAKE", [10, 10, 10, 125], 4);
    render_string(10, y / 2 + 15, 0, "FAKE", [192 - (abs * 71 / 60), 32 + (abs * 146 / 60), 28, 200], 4);

    // Render the bar's background
    render_filled_rect(12, y / 2 + 46, 64, 4, [10, 10, 10, 125]);

    // Draw this small tile to fix a small issue that was driving me crazy.
    render_filled_rect(43, y / 2 + 47, 1, 2, [232, 232, 232, 200]);

    // Render the desync's length under the bar.
    render_string(41, y / 2 + 52, 1, abs.toString( ), [232, 232, 232, 200], 3);
    render_circle(48, y / 2 + 52, 1, [232, 232, 232, 200]);

    // If our delta is positive, than our desync is headed to the right.
    if (delta > 0)
    {
        // So, fill the bar from the center to the right, accounting for the desync's length.
        render_filled_rect(44, y / 2 + 47, abs * 31 / 60, 2, [232, 232, 232, 200]);
        return;
    }

    // If our delta is not positive, than our desync is headed to the left.
    // So, fill the bar from the center to the left.
    render_filled_rect(44 - abs * 31 / 60, y / 2 + 47, abs * 31 / 60, 2, [232, 232, 232, 200]);
}

/**
 * @callback create_move
 * @brief Handles our plugin's logic.
 */
function on_tick( )
{
    // Checks whether or not our script is enabled.
    if (!(menu1.get(enable)))
        return;

    // Does the freestanding.
    update_anti_aim( );
}

function on_frame( )
{
    // Checks whether or not our script is enabled.
    if (!(menu1.get(enable)))
        return;

    // Draws our indicators
    do_indicators( );
}

/**
 * @callback player_hurt
 * @brief Handles the last hit LBY logic.
 */
function on_player_hurt( )
{
    // Get the event's entities.
    const me = entity_get_local_player( );
    const attacker = entity_get_entity_from_user_i_d(event_get_int("attacker"));
    const userid = entity_get_entity_from_user_i_d(event_get_int("userid"));

    // Checks if our local player was the one getting hurt and not the one attacking.
    // Or, in other words, check if we got hurt.
    if (me !== attacker && me === userid)
    {
        // Update the last hit lower body global.
        plugin.last_hit_lby[attacker] = menu1.get_hotkey(ref_inverter);
    }
}

/**
 * @callback round_start, player_connect_full
 * @brief Resets the last hit LBY list whenever the round ends or you switch servers.
 */
function reset( )
{
    // Reset the last lower body state.
    plugin.last_hit_lby = [];
}


//endregion

//region callbacks

// Register our 'create_move' callback.
cheat_register_callback(
    'create_move', 'on_tick'
);

// Register our 'paint' callback.
cheat_register_callback(
    'paint', 'on_frame'
);

// Register our 'player_hurt' callback.
cheat_register_callback(
    'player_hurt', 'on_player_hurt'
);

// Register our 'player_connect_full' callback.
cheat_register_callback(
    'player_connect_full', 'reset'
);

//endregion

//ANTIBRUTEFORCE


function vec_sub(A, B)
{
    var C = []
    var i;
    for (i = 0; i < 3; i++) {
        C[i] = A[i] - B[i]
    }
    return C
}

function vec_div(A, B)
{
    var C = []
    var i;
    for (i = 0; i < 3; i++) {
        C[i] = A[i] / B
    }
    return C
}

function vec_add(A, B)
{
    var C = []
    var i;
    for (i = 0; i < 3; i++) {
        C[i] = A[i] + B[i]
    }
    return C
}

function vec_mul(A, B)
{
    var C = []
    var i;
    for (i = 0; i < 3; i++) {
        C[i] = A[i] * B
    }
    return C
}

function dotProduct(A, B) 
{ 
    var product = 0.0
    var i;
    for (i = 0; i < 3; i++) {
        product += A[i] * B[i]
    }
    return product; 
} 

function getDistance(A, B)
{
    var delta = vec_sub(A, B)
    return Math.sqrt(delta[0]*delta[0]+delta[1]*delta[1]+delta[2]*delta[2])
}

function computeDistance(A, B, C) 
{
    var d = vec_div(vec_sub(C, B), getDistance(C, B)) // vec3
    var v = vec_sub(A, B) // vec3
    var t = dotProduct(v, d) // vec3
    var P = vec_add(B, vec_mul(d, t))
    return getDistance(P,A)
}
UI.AddCheckbox("Dodge bruteforce")
UI.AddSliderInt("Max Brute Distance", 0, 60)
UI.AddCheckbox("Anti-Onetap")
var shots = 0 
function onBulletImpact(){
    var ent = Entity.GetEntityFromUserID(Event.GetInt("userid"))
    var local = Entity.GetLocalPlayer()
    if(ent == local || Entity.IsTeammate(ent) && UI.GetValue("Dodge bruteforce"))
        return
    var pos = [Event.GetFloat("x"), Event.GetFloat("y"), Event.GetFloat("z")]
    var delta = computeDistance(Entity.GetHitboxPosition(Entity.GetLocalPlayer(), 0), Entity.GetEyePosition(ent), pos)
    if(delta < UI.GetValue("Max Brute Distance"))
        UI.ToggleHotkey("Anti-Aim", "Fake angles", "Inverter")
    if(UI.GetValue("Anti-Onetap")){
        shots++
        if(!(shots % 4)) UI.ToggleHotkey("Anti-Aim", "Fake angles", "Inverter")
    }
}
function playerhurt(){
    if(Entity.GetEntityFromUserID(Event.GetInt("userid")) == Entity.GetLocalPlayer())
        UI.ToggleHotkey("Anti-Aim", "Fake angles", "Inverter")
}
Cheat.RegisterCallback("player_hurt", "playerhurt")
Cheat.RegisterCallback("bullet_impact", "onBulletImpact")

//JITTER RANDOMIZER

//Made by Mellow
var master = {
    dir: "back",
    cycle: false,

    GetYawOffset: function() { return UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset") },
    SetYawOffset: function (yaw) { return UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", yaw) },
    GetJitterOffset: function () { return UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset") },
    SetJitterOffset: function (jitter) { return UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset", jitter) },

    RandomYaw: function () { return UI.GetValue("Misc", "JAVASCRIPT", "Yaw offset randomization") },
    RandomJitter: function () { return UI.GetValue("Misc", "JAVASCRIPT", "Jitter offset randomization") },

    JitterOffsetJitter: function () { return UI.GetValue("Misc", "JAVASCRIPT", "Jitter offset jitter") },
}

function ui() {
	UI.AddCheckbox("Jitter Randomizer")
    UI.AddSliderInt("Jitter offset randomization", 0, 90);
    UI.AddSliderInt("Jitter offset jitter", 0, 90);
}

function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
  }

function jitter() {
	if(UI.GetValue("Jitter Randomizer")){
		master.cycle = !master.cycle;
		master.SetJitterOffset((master.cycle ? (master.JitterOffsetJitter() / 2) * 2 : -(master.JitterOffsetJitter() / 2) * 2) + getRandomInt(-master.RandomJitter(), master.RandomJitter()));
	}
}


function main1() {
    ui();
    Global.RegisterCallback("CreateMove", "jitter");
} main1();


UI.AddSliderInt("         +Weapon Features+", 0, 0);

const menu =
{
    menu_types:
    {
        TYPE_VALUE: 0,
        TYPE_COLOR: 1,
        TYPE_KEYBIND: 2,
        TYPE_REFERENCE: 3
    },

    menu_array: [], //where the items lie lol

    //I understand that all of those can be generalized, but this way the code is more clear.
    create_checkbox: function(created_var_name)
    {
        return this.menu_array.push({type: this.menu_types.TYPE_VALUE, var_name: UI.AddCheckbox(created_var_name), is_item_visible: true}) - 1; //I guess the variable naming is a bit gay rofl
    },

    create_slider_int: function(created_var_name, created_var_min, created_var_max)
    {
        return this.menu_array.push({type: this.menu_types.TYPE_VALUE, var_name: UI.AddSliderInt(created_var_name, created_var_min, created_var_max), is_item_visible: true}) - 1;
    },

    create_slider_float: function(created_var_name, created_var_min, created_var_max)
    {
        return this.menu_array.push({type: this.menu_types.TYPE_VALUE, var_name: UI.AddSliderFloat(created_var_name, created_var_min, created_var_max), is_item_visible: true}) - 1;
    },

    create_dropdown: function(created_var_name, created_var_dropdown_array)
    {
        return this.menu_array.push({type: this.menu_types.TYPE_VALUE, var_name: UI.AddDropdown(created_var_name, created_var_dropdown_array), is_item_visible: true}) - 1;
    },

    create_multi_dropdown: function(created_var_name, created_var_dropdown_array)
    {
        return this.menu_array.push({type: this.menu_types.TYPE_VALUE, var_name: UI.AddMultiDropdown(created_var_name, created_var_dropdown_array), is_item_visible: true}) - 1;
    },

    create_colorpicker: function(created_var_name)
    {
        return this.menu_array.push({type: this.menu_types.TYPE_COLOR, var_name: UI.AddColorPicker(created_var_name), is_item_visible: true}) - 1;
    },

    create_keybind: function(created_var_name)
    {
        return this.menu_array.push({type: this.menu_types.TYPE_KEYBIND, var_name: UI.AddHotkey(created_var_name), is_item_visible: true}) - 1;
    },

    create_menu_reference: function(var_path, var_type)
    {
        return this.menu_array.push({type: this.menu_types.TYPE_REFERENCE, var_name: var_path, is_item_visible: true, reference_subtype: var_type}) - 1;
    },

    get_item_value: function(var_index)
    {
        if(typeof(this.menu_array[var_index]) != "undefined")
        {
            const var_type = this.menu_array[var_index].type == this.menu_types.TYPE_REFERENCE ? this.menu_array[var_index].reference_subtype : this.menu_array[var_index].type;
            switch(var_type)
            {
                case this.menu_types.TYPE_VALUE:
                    return UI.GetValue.apply(null, this.menu_array[var_index].var_name); //Why isn't UI.GetValue good for all menu items? llama pls fix
                case this.menu_types.TYPE_COLOR:
                    return UI.GetColor.apply(null, this.menu_array[var_index].var_name);
                case this.menu_types.TYPE_KEYBIND:
                    return UI.IsHotkeyActive.apply(null, this.menu_array[var_index].var_name);
                default:
                    throw new Error("[onetap] invalid type specified for get_script_item_value call (variable name " + menu_array[var_index].var_name + ", specified type: " + type + ")\n");
            }
        }
        throw new Error("[onetap] invalid menu item specified for get_script_item_value\n");
    },

    set_item_visibility: function(var_index, visibility_status)
    {
        if(typeof(this.menu_array[var_index]) != "undefined")
        {
            if(this.menu_array[var_index].is_item_visible != visibility_status && UI.IsMenuOpen())
            {
                UI.SetEnabled.apply(null, this.menu_array[var_index].var_name.concat(visibility_status));
                this.menu_array[var_index].is_item_visible = visibility_status;
            }
        }
        else
        {
            throw new Error("[onetap] invalid menu item specified for set_item_visibility\n");
        }
    },

    set_item_value: function(var_index, new_value)
    {
        if(typeof(this.menu_array[var_index]) != "undefined")
        {
            const var_type = this.menu_array[var_index].type == this.menu_types.TYPE_REFERENCE ? this.menu_array[var_index].reference_subtype : this.menu_array[var_index].type;
            switch(var_type)
            {
                case this.menu_types.TYPE_VALUE:
                    UI.SetValue.apply(null, this.menu_array[var_index].var_name.concat(new_value));
                    break;
                case this.menu_types.TYPE_COLOR:
                    UI.SetColor.apply(null, this.menu_array[var_index].var_name.concat(new_value));
                    break;
                case this.menu_types.TYPE_KEYBIND:
                    const keybind_state = this.get_item_value(var_index);
                    if(keybind_state != new_value)
                    {
                        UI.ToggleHotkey.apply(null, this.menu_array[var_index].var_name); //Requires hotkey to be in "Toggle" mode :(
                    }
                    break;
                default:
                    throw new Error("[onetap] invalid type specified for set_item_value (variable name " + menu_array[var_index].var_name + ", specified type: " + this.menu_array[var_index].type + ")\n");
            }
        }
        else
        {
            throw new Error("[onetap] invalid menu item specified for set_item_value\n");
        }
    }
};

const master_switch = menu.create_checkbox("Doubletap improvements");
const doubletap_speed = menu.create_slider_int("Speed", 0, 4);

const doubletap_enabled_hotkey_reference = menu.create_menu_reference(["Rage", "Doubletap"], menu.menu_types.TYPE_KEYBIND);
const doubletap_enabled_value_reference = menu.create_menu_reference(["Rage", "Doubletap"], menu.menu_types.TYPE_VALUE);

const utility = { log_prefix: "[doubletap_improvements] ", log_prefix_col: [0, 255, 0, 200], log: function(string) { Cheat.PrintColor(this.log_prefix_col, this.log_prefix); Cheat.Print(string + "\n"); } };

const able_to_shift_shot = function(local, ticks_to_shift) //From Salvatore :)
{
    const server_time = (Entity.GetProp(local, "CCSPlayer", "m_nTickBase") - ticks_to_shift) * Globals.TickInterval();
    return server_time > Entity.GetProp(local, "CCSPlayer", "m_flNextAttack") && server_time > Entity.GetProp(Entity.GetWeapon(local), "CBaseCombatWeapon", "m_flNextPrimaryAttack");
};

const on_move = function()
{
    if(menu.get_item_value(doubletap_enabled_value_reference) && menu.get_item_value(doubletap_enabled_hotkey_reference) && menu.get_item_value(master_switch))
    {
        const desired_doubletap_speed = menu.get_item_value(doubletap_speed);

        Exploit.OverrideShift(10 + desired_doubletap_speed); // suicide 16 ticks lmao shift
        Exploit.OverrideTolerance(4 - desired_doubletap_speed); //yes i know its clamped to 1 but its PRETTY this way!

        const local = Entity.GetLocalPlayer();

        const exploit_charge = Exploit.GetCharge();
        exploit_charge != 1 ? Exploit.EnableRecharge() : Exploit.DisableRecharge();

        const able_to_shift = able_to_shift_shot(local, 12 + desired_doubletap_speed);

        const can_doubletap = exploit_charge == 1 && able_to_shift;
        var should_recharge_doubletap = !can_doubletap && able_to_shift;

        const enemies = Entity.GetEnemies().filter(function(entity_index) { return Entity.IsValid(entity_index) && Entity.IsAlive(entity_index) && !Entity.IsDormant(entity_index); });

        const local_eyepos = Entity.GetEyePosition(local);

        if(can_doubletap || should_recharge_doubletap)
        {
            for(var i = 0; i < enemies.length; i++)
            {
                const entity_index = enemies[i];
                const entity_health = Entity.GetProp(entity_index, "CBasePlayer", "m_iHealth");
                for(var hitbox = 2; hitbox <= 4; hitbox++)
                {
                    const hitbox_position = Entity.GetHitboxPosition(entity_index, hitbox);
                    if(typeof(hitbox_position) != "undefined")
                    {
                        const trace = Trace.Bullet(local, entity_index, local_eyepos, hitbox_position);
                        if(can_doubletap && (trace[1] >= entity_health / 2))
                        {
                            Ragebot.ForceTargetMinimumDamage(entity_index, entity_health / 2);
                        }
                        else if(should_recharge_doubletap && trace[2])
                        {
                            should_recharge_doubletap = false; //DO NOT RECHARGE DOUBLETAP IF THERE'S SOMEONE VISIBLE
                            break;
                        }
                    }
                }
            }
        }
       

        if(should_recharge_doubletap)
        {
            Exploit.DisableRecharge();
            Exploit.Recharge();
        }
    }
};

const on_unload = function()
{
    Exploit.EnableRecharge();
};

Cheat.RegisterCallback("CreateMove", "on_move");
Cheat.RegisterCallback("Unload", "on_unload");

utility.log("DT loaded ");

function vectorangles(forward){
    var angles = []
    if(forward[1] == 0 && forward[0] == 0){
        angles[0] = forward[2] > 0 ? 270 : 90
        angles[1] = 0
    }
    else{
        angles[0] = Math.atan2(-forward[2], Math.sqrt(forward[0] * forward[0] + forward[1]*forward[1])) * -180 / Math.PI
        angles[1] = Math.atan2(forward[1],forward[0]) * 180 / Math.PI
        if(angles[1] > 90)
            angles[1] -= 180
        else if(angles[1] < 90)
            angles[1] += 180
        else if(angles[1] == 90)
            angles[1] = 0
    }
    return angles
}
function anglevectors(angles){
    var sy = Math.sin(angles[1] * 180 / Math.PI)
    var cy = Math.cos(angles[1] * 180 / Math.PI)
    var sp = Math.sin(angles[0] * 180 / Math.PI)
    var cp = Math.cos(angles[0] * 180 / Math.PI)
    return [cp * cy, cp * sy, -sp]
}
var currentAction = 2
var lastTickShot = 0
function reset(){
    lastTickShot = 0
}
var lasttarget = 0
function onRageShoot(){
    if(!UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && !UI.GetValue("Rage", "GENERAL", "Exploits", "Doubletap"))
        return
    var type = Event.GetInt("exploit")
    // 1 = 1st shot
    // 2 = 2nd shot
    if(type == 1){
        currentAction = 1
        lastTickShot = Globals.Tickcount()
    }
    if(type == 2){
        currentAction = 2
    }
    lasttarget = Event.GetInt("target_index")
}
function onCM(){
    var local = Entity.GetLocalPlayer()
    if(!local || !Entity.IsAlive(local) || currentAction == 2)
        return
    if(!UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && !UI.GetValue("Rage", "GENERAL", "Exploits", "Doubletap"))
        return
    if(!Entity.IsAlive(lasttarget) || lastTickShot + 12 < Globals.Tickcount()){
        lasttarget = 0
        return
    }
    var velo = Entity.GetProp(local, "DT_CSPlayer", "m_vecVelocity[0]")
    var speed = Math.sqrt((velo[0]*velo[0])+(velo[1]*velo[2])+(velo[2]*velo[2]))
    var direction = vectorangles(velo)
    direction[1] = Local.GetViewAngles()[1] - direction[1]
    var forward = anglevectors(direction)
    var negative = []
    negative[0] = forward[0] * speed
    negative[1] = forward[1] * speed
    negative[2] = forward[2] * speed
    UserCMD.SetMovement([negative[0], negative[1], 0])
}
Cheat.RegisterCallback("ragebot_fire", "onRageShoot")
Cheat.RegisterCallback("CreateMove", "onCM")
Cheat.RegisterCallback("round_start", "reset")



// dmg override
UI.AddCheckbox("Damage Override")
UI.AddHotkey("Override Hotkey")
UI.AddCheckbox("Display indicator")
UI.AddSliderInt("Heavy Pistol Mindmg", 0, 130)
UI.AddSliderInt("Scout Mindmg", 0, 130)
UI.AddSliderInt("AWP Mindmg", 0, 130)
UI.AddSliderInt("Auto Mindmg", 0, 130)

var heavy_cache = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage")
var scout_cache = UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage")
var awp_cache = UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage")
var auto_cache = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage")
function isActive(a)
{
    return UI.IsHotkeyActive("JAVASCRIPT", a)
}
function setValue(cat, value)
{
    UI.SetValue("Rage", cat.toUpperCase(), "Targeting", "Minimum damage", value)
}
function isHeavyPistol(name)
{
    if (name == "r8 revolver" || name == "desert eagle")
    {
        return true
    }
}
function isAutoSniper(name)
{
    if(name == "scar 20" || weapon_name == "g3sg1")
    {
        return true
    }
}
function onCM()
{
    heavy_value = UI.GetValue("Script items", "Heavy Pistol Mindmg")
    scout_value = UI.GetValue("Script items", "Scout Mindmg")
    awp_value = UI.GetValue("Script items", "AWP Mindmg")
    auto_value = UI.GetValue("Script items", "Auto Mindmg")
    weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))
    
    if (isActive("Override Hotkey") && isHeavyPistol(weapon_name) && UI.GetValue("Damage Override"))
    {
        setValue("HEAVY PISTOL", heavy_value)
    }
    else{
        setValue("HEAVY PISTOL", heavy_cache)
    }
    
    if (isActive("Override Hotkey") && weapon_name == "ssg 08" && UI.GetValue("Damage Override"))
    {
        setValue("SCOUT", scout_value)
    }
    else{
        setValue("SCOUT", scout_cache)
    }

    if (isActive("Override Hotkey") && weapon_name == "awp" && UI.GetValue("Damage Override"))
    {
        setValue("AWP", awp_value)
    }
    else{
        setValue("AWP", awp_cache)
    }

    if (isActive("Override Hotkey") && isAutoSniper(weapon_name) && UI.GetValue("Damage Override"))
    {
        
        setValue("AUTOSNIPER", auto_value)
    }
    else
    {
        setValue("AUTOSNIPER", auto_cache)
    }
    
}
function indicator()
{
    font = Render.AddFont("Tahoma", 17, 600 )
    screen = Render.GetScreenSize()
    wep = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))
    x = screen[0]-screen[0] + 20
    y = screen[1] - 100
    heavy ="" + UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage")
    scout ="" +UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage")
    awp ="" +UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage")
    auto ="" +UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage")
    var str = ""
    if (UI.GetValue("Script items", "Display indicator") && Entity.IsValid(Entity.GetLocalPlayer()) && Entity.IsAlive(Entity.GetLocalPlayer()))
    {
        if (isHeavyPistol(wep))
        {
            str = heavy
        }
        else if(wep == "ssg 08")
        {
            str = scout
        }
        else if(wep == "awp")
        {
            str = awp
        }
        else if (isAutoSniper(wep))
        {
            str = auto
        }
    }
    
    if (str == "" + 0)
    {
        str = "DYNAMIC"
    }
    Render.StringCustom(x+1, y+1, 0, str+"", [0,0,0,255], font)
    Render.StringCustom(x, y, 0, str+"", [255,255,255,255], font)
}
Cheat.RegisterCallback("Draw", "indicator")
Cheat.RegisterCallback("CreateMove", "onCM")

// Conditions
UI.AddCheckbox("Hitbox Conditions");
UI.AddMultiDropdown("Head conditions", ["If in air", "If crouching"]);
UI.AddMultiDropdown("Body conditions", ["If lethal", "If slow-walking", "If standing", "If in air", "If crouching"]);
UI.AddMultiDropdown("Safety conditions", ["If lethal", "If slow-walking", "If standing", "If in air", "If crouching"]);
UI.AddCheckbox("Safety Flags");

var info = [];
var safe = [];

function get_value(item)
{
    return UI.GetValue("Misc", "JAVASCRIPT", "Script items", item);
}

function get_proper_eye()
{
    var local_player = Entity.GetLocalPlayer();
    var origin = Entity.GetRenderOrigin(local_player);
    if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck"))
        return [origin[0], origin[1], origin[2] + 46 + 18];
    else
        return Entity.GetEyePosition(local_player);
}

function extrapolate_tick(entity, ticks, x, y, z)
{
    var velocity = Entity.GetProp(entity, "CBasePlayer", "m_vecVelocity[0]");

    var new_pos = [x,y,z];
    new_pos[0] = new_pos[0] + velocity[0] * Globals.TickInterval() * ticks;
    new_pos[1] = new_pos[1] + velocity[1] * Globals.TickInterval() * ticks;
    new_pos[2] = new_pos[2] + velocity[2] * Globals.TickInterval() * ticks;
        return new_pos;
}

function force_head(entity)
{
    disable_body();
    var local_player = Entity.GetLocalPlayer();
    var eye_pos = get_proper_eye();
    var head_pos = Entity.GetHitboxPosition(entity, 0);
    var head_damage = Trace.Bullet(local_player, entity, eye_pos, head_pos);
    Ragebot.ForceTargetMinimumDamage(entity, head_damage[1]);
}

function force_body()
{
    if (!UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force body aim"))
        UI.ToggleHotkey("Rage", "GENERAL", "General", "Force body aim");
}

function disable_body()
{
    if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force body aim"))
        UI.ToggleHotkey("Rage", "GENERAL", "General", "Force body aim");
}

function force_safe()
{
    if (!UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force safe point"))
        UI.ToggleHotkey("Rage", "GENERAL", "General", "Force safe point");
}

function disable_safe()
{
    if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force safe point"))
        UI.ToggleHotkey("Rage", "GENERAL", "General", "Force safe point");
}

function is_standing(entity)
{
    var entity_velocity = Entity.GetProp(entity, "CBasePlayer", "m_vecVelocity[0]");
    var entity_speed = Math.sqrt(entity_velocity[0] * entity_velocity[0] + entity_velocity[1] * entity_velocity[1]);
    if (entity_speed >= 0 && entity_speed < 10) return true;
    else return false;
}

function is_crouching(entity)
{
    var flags = Entity.GetProp(entity, "CBasePlayer", "m_fFlags");
    if (flags & 1 << 1) return true;
    else return false;
}

function is_slowwalking(entity)
{
    var entity_velocity = Entity.GetProp(entity, "CBasePlayer", "m_vecVelocity[0]");
    var entity_speed = Math.sqrt(entity_velocity[0] * entity_velocity[0] + entity_velocity[1] * entity_velocity[1]);
    if (entity_speed >= 10 && entity_speed <= 85) return true;
    else return false;
}

function is_inair(entity)
{
    var flags = Entity.GetProp(entity, "CBasePlayer", "m_fFlags");
    if (!(flags & 1 << 0) && !(flags & 1 << 0x12)) return true;
    else return false;
}

function is_lethal(entity)
{
    var local_player = Entity.GetLocalPlayer();
    var eye_pos = get_proper_eye();
    var local_pos = extrapolate_tick(local_player, 25, eye_pos[0], eye_pos[1], eye_pos[2]);
    var entity_hp = Entity.GetProp(entity, "CBasePlayer", "m_iHealth");
    var pelvis_pos = Entity.GetHitboxPosition(entity, 2);
    var body_pos = Entity.GetHitboxPosition(entity, 3);
    var thorax_pos = Entity.GetHitboxPosition(entity, 4);
    var pelvis_trace = Trace.Bullet(local_player, entity, local_pos, pelvis_pos);
    var body_trace = Trace.Bullet(local_player, entity, local_pos, body_pos);
    var thorax_trace = Trace.Bullet(local_player, entity, local_pos, thorax_pos);
    var pelvis_dmg = pelvis_trace[1];
    var body_dmg = body_trace[1];
    var thorax_dmg = thorax_trace[1];
    var lethal_damage = Math.max(pelvis_dmg, body_dmg, thorax_dmg);
    if (entity_hp <= lethal_damage) return true;
    else return false;
}

//region flags
function draw_flags()
{
    enemies = Entity.GetEnemies();
    
    for (i = 0; i < enemies.length; i++)
    {
        if (!Entity.IsValid(enemies[i])) continue;
        if (!Entity.IsAlive(enemies[i])) continue;
        if (Entity.IsDormant(enemies[i])) continue;
        
        var pos = Entity.GetRenderBox(enemies[i]);
        var font = Render.AddFont("Verdana", 7, 700);
        var a = pos[3] - pos[1];
        a /= 2;
        a += pos[1];

        switch (info[enemies[i]])
        {
            case 'HEAD':
                Render.StringCustom(a, pos[2] - 25, 1, "HEAD", [10, 10, 10, 125], font);
                Render.StringCustom(a - 1, pos[2] - 25, 1, "HEAD", [255, 95, 95, 255], font);
                break;
            case 'BODY':
                Render.StringCustom(a, pos[2] - 25, 1, "BODY", [10, 10, 10, 125], font);
                Render.StringCustom(a - 1, pos[2] - 25, 1, "BODY", [237, 144, 255, 255], font);
                break;
            case 'PREFER':
                Render.StringCustom(a, pos[2] - 25, 1, "PREFER", [10, 10, 10, 125], font);
                Render.StringCustom(a - 1, pos[2] - 25, 1, "PREFER", [95, 186, 255, 255], font);
                break;
        }

        switch (safe[enemies[i]])
        {
            case 'SAFE':
                Render.StringCustom(a, pos[2] - 35, 1, "SAFE", [10, 10, 10, 125], font);
                Render.StringCustom(a - 1, pos[2] - 35, 1, "SAFE", [211, 255, 144, 255], font);
                break;
        }
    }
}
//end region

//region conditions
function conditions()
{
    if (get_value("Hitbox Conditions"))
    {
        enemies = Entity.GetEnemies();
        local_player = Entity.GetLocalPlayer();
        
        for (i = 0; i < enemies.length; i++)
        {
            if (!Entity.IsValid(enemies[i])) continue;
            if (!Entity.IsAlive(enemies[i])) continue;
            if (Entity.IsDormant(enemies[i])) continue;

            if (get_value("Hitbox Conditions"))
            {
                head_condtions = get_value("Head conditions");
                body_condtions = get_value("Body conditions");
                safe_condtions = get_value("Safety conditions");

                if (safe_condtions & (1 << 0) && is_lethal(enemies[i]) || safe_condtions & (1 << 1) && is_slowwalking(enemies[i]) || safe_condtions & (1 << 2) && is_standing(enemies[i]) || safe_condtions & (1 << 3) && is_inair(enemies[i]) || safe_condtions & (1 << 4) && is_crouching(enemies[i]))
                {
                    if (get_value("Safety Flags"))
                    {
                        force_safe();
                        safe[enemies[i]] = 'SAFE';
                    }
                    else
                    {
                        force_safe();
                    }
                }
                else
                {
                    disable_safe();
                    safe[enemies[i]] = 'NONE';
                }
                if (head_condtions & (1 << 0) && is_inair(enemies[i]) || head_condtions & (1 << 1) && is_crouching(enemies[i]))
                {
                    if (get_value("Safety Flags"))
                    {
                        force_head(enemies[i]);
                        info[enemies[i]] = 'HEAD';
                    }
                    else
                    {
                        force_head(enemies[i]);
                    }
                }
                else if (body_condtions & (1 << 0) && is_lethal(enemies[i]) || body_condtions & (1 << 1) && is_slowwalking(enemies[i]) || body_condtions & (1 << 2) && is_standing(enemies[i]) || body_condtions & (1 << 3) && is_inair(enemies[i]) || body_condtions & (1 << 4) && is_crouching(enemies[i]))
                {
                    if (get_value("Safety Flags"))
                    {
                        force_body();
                        info[enemies[i]] = 'BODY';
                    }
                    else
                    {
                        force_body();
                    }
                }
                else
                {
                    if (get_value("Safety Flags"))
                    {
                        disable_body();
                        info[enemies[i]] = 'PREFER';
                    }
                    else
                    {
                        disable_body();
                    }
                }
            }
        }
    }
}

Cheat.RegisterCallback("Draw", "draw_flags");
Cheat.RegisterCallback("CreateMove", "conditions");

// INDICATORS

//Indicators

//Modified by Reptar
//Originals made by :
//Signal for the idea
//Ultranite for help
//AA Indicators by 57777
//Fake Indicator by dummy (Decommissioned)
//Base by Snipi https://onetap.su/threads/release-manual-aa-indicators.13542/#post-110857
//shoutout to edeen and ntrzr

//If I forgot you, Please let me know

UI.AddSliderInt("       +Miscellaneous/Visuals+", 0, 0);

//indicator vars
var screen_size = Global.GetScreenSize();
UI.AddCheckbox("Indicators")
var isInverted;
//ui
//Polygon Points
LPx = [(screen_size[0] /2) - 41, (screen_size[1] /2) + 10];
LPy = [(screen_size[0] /2) - 41, (screen_size[1] /2) - 10];
LPz = [(screen_size[0] /2) - 61, (screen_size[1] /2) + 0];
RPx = [(screen_size[0] /2) + 41, (screen_size[1] /2) + 10];
RPy = [(screen_size[0] /2) + 41, (screen_size[1] /2) - 10];
RPz = [(screen_size[0] /2) + 61, (screen_size[1] /2) + 0];
BPx = [(screen_size[0] /2) + 10, (screen_size[1] /2) + 41];
BPy = [(screen_size[0] /2) - 10, (screen_size[1] /2) + 41];
BPz = [(screen_size[0] /2) - 0, (screen_size[1] /2) + 61];
LPxx = [(screen_size[0] /2) - 42, (screen_size[1] /2) + 10];
LPyy = [(screen_size[0] /2) - 42, (screen_size[1] /2) - 10];
LPzz = [(screen_size[0] /2) - 62, (screen_size[1] /2) + 0];
RPxx = [(screen_size[0] /2) + 42, (screen_size[1] /2) + 10];
RPyy = [(screen_size[0] /2) + 42, (screen_size[1] /2) - 10];
RPzz = [(screen_size[0] /2) + 62, (screen_size[1] /2) + 0];
BPxx = [(screen_size[0] /2) + 10, (screen_size[1] /2) + 42];
BPyy = [(screen_size[0] /2) - 10, (screen_size[1] /2) + 42];
BPzz = [(screen_size[0] /2) - 0, (screen_size[1] /2) + 62];



function render_arc(x, y, radius, radius_inner, start_angle, end_angle, segments, color)
    {
        while(360 % segments != 0)
        {
            segments++;
        }

        segments = 360 / segments;

        for (var i = start_angle; i < start_angle + end_angle; i = i + segments)
        {	

            var rad = i * Math.PI / 180;
            var rad2 = (i + segments) * Math.PI / 180;

            var rad_cos = Math.cos(rad)
            var rad_sin = Math.sin(rad)

            var rad2_cos = Math.cos(rad2);
            var rad2_sin = Math.sin(rad2);

            var x1_outer = x + rad_cos * radius;
            var y1_outer = y + rad_sin * radius;

            var x2_outer = x + rad2_cos * radius;
            var y2_outer = y + rad2_sin * radius;

            var x1_inner = x + rad_cos * radius_inner;
            var y1_inner = y + rad_sin * radius_inner;

            var x2_inner = x + rad2_cos * radius_inner;
            var y2_inner = y + rad2_sin * radius_inner;

            Render.Polygon( [
                [ x1_outer, y1_outer ],
                [ x2_outer, y2_outer ],
                [ x1_inner, y1_inner ] ],
                color
            );

            Render.Polygon( [
                [ x1_inner, y1_inner ],
                [ x2_outer, y2_outer ],
                [ x2_inner, y2_inner ] ],
                color
            );
        }
    }

function drawString1()
{
	
    const alpha = Math.sin(Math.abs(-Math.PI + (Globals.Curtime() * (1 / 1)) % (Math.PI * 2))) * 255;
    const alphax = Math.sin(Math.abs(-Math.PI + (Globals.Curtime() * (1 / .5)) % (Math.PI * 2))) * 255;
    isHideshots = UI.IsHotkeyActive("Rage", "Exploits", "Hide shots");
    isFakeduck = UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck");
    isDoubletap = UI.IsHotkeyActive("Rage", "Exploits", "Doubletap");
    isInverted = UI.IsHotkeyActive("Anti-Aim", "Inverter" );
    isLbyMode = UI.GetValue("Anti-Aim", "LBY mode");
	isBAIM = UI.IsHotkeyActive("Rage", "Force body aim");
    isDesyncMode = UI.GetValue("Anti-Aim", "Fake desync");
    localplayer_index = Entity.GetLocalPlayer( );
    localplayer_alive = Entity.IsAlive( localplayer_index );
	charge = Exploit.GetCharge();
	max_angle = 360*Exploit.GetCharge();
	center = Render.GetScreenSize();
	X = center[0] / 2
	Y = center[1] / 2
    //Fake Indicator Plus
    //Render.String(screen_size[0] /2 + 1, screen_size[1] /2 +101, 1, "FAKE", [ 0, 0, 0, 255 ], 3 );
    //Render.String(screen_size[0] /2, screen_size[1] /2 +100, 1, "FAKE", [ difference * 255 / 58, 255 - ( difference * 255 / 58 ), 0 , 255], 3 );
    
    if (localplayer_alive == true && UI.GetValue("Indicators")){
    //Shadows

	Render.String(screen_size[0] /2, screen_size[1] /2 +76, 1, isBAIM ? "BODY" : "NORM", [ 0, 0, 0, 255 ], 3 );
    Render.String(screen_size[0] /2, screen_size[1] /2 +116, 1, isFakeduck ? "DUCK" : "", isFakeduck ? [ 0, 0, 0, 255 ] : [ 0, 0, 0, 0 ], 3 );

    //indicators
    Render.String(screen_size[0] /2, screen_size[1] /2 +75, 1, isBAIM ? "BODY" : "NORM", isBAIM ? [ 65, 180, 80, 255 ] : [ 45, 135, 185, 255 ], 3 );
    Render.String(screen_size[0] /2, screen_size[1] /2 +115, 1, isFakeduck ? "DUCK" : "", isFakeduck ? [ 255, 255, 255, 255 ] : [ 0, 0, 0, 0 ], 3 );
	
	if (isDoubletap){
		if (charge >= 1){
	Render.String(screen_size[0] /2, screen_size[1] /2 +96, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [ 0, 0, 0, 255 ] : [ 0, 0, 0, 255 ], 3 );
	Render.String(screen_size[0] /2, screen_size[1] /2 +95, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [ 65, 180, 80, 255 ] : [ 255, 0, 0, 255 ], 3 );
	Render.String(screen_size[0] /2, screen_size[1] /2 +106, 1, isHideshots ? "HIDE" : "ANIM", isHideshots ? [ 0, 0, 0, 255 ] : [ 0, 0, 0, 255 ], 3 );
	Render.String(screen_size[0] /2, screen_size[1] /2 +105, 1, isHideshots ? "HIDE" : "ANIM", isHideshots ? [ 145, 120, 229, 255 ] : [ 255, 153, 0, alpha ], 3 );}
	if (charge < 1){
		Render.String(screen_size[0] /2 -5, screen_size[1] /2 +96, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [ 0, 0, 0, 255 ] : [ 0, 0, 0, 255 ], 3 );
		Render.String(screen_size[0] /2 -5, screen_size[1] /2 +95, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [ 255-(charge*190), charge*180, charge*80,  255 ] : [ 255, 0, 0, 255 ], 3 );
		Render.String(screen_size[0] /2, screen_size[1] /2 +106, 1, "ANIM", [ 0, 0, 0, 255 ], 3 );
		Render.String(screen_size[0] /2, screen_size[1] /2 +105, 1, "ANIM", [ 255, 153, 0, alpha ], 3 );
		render_arc(X + 8, Y + 99, 5, 2.5, -90, 360, 36, [120, 120, 120, 190]);
		render_arc(X + 8, Y + 99, 5, 2.5, -90, max_angle, 36, [ 255-(charge*190), charge*180, charge*80, 255]);
	}
	}if (!isDoubletap){
	Render.String(screen_size[0] /2, screen_size[1] /2 +96, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [ 0, 0, 0, 255 ] : [ 0, 0, 0, 255 ], 3 );
	Render.String(screen_size[0] /2, screen_size[1] /2 +95, 1, isDoubletap ? "DT" : "DT", isDoubletap ? [ 65, 180, 80, 255 ] : [ 255, 0, 0, 255 ], 3 );
	Render.String(screen_size[0] /2, screen_size[1] /2 +106, 1, isHideshots ? "HIDE" : "ANIM", [ 0, 0, 0, 255 ], 3 );
	Render.String(screen_size[0] /2, screen_size[1] /2 +105, 1, isHideshots ? "HIDE" : "ANIM", isHideshots ? [ 145, 120, 229, 255 ] : [ 255, 153, 0, alpha ], 3 );  
	}
    
	//inverter indicators
	if(isDesyncMode == 0)
    {
        Render.String(screen_size[0] /2, screen_size[1] /2 +86, 1, isInverted ? "LEFT" : "RIGHT", [ 0, 0, 0, 255 ], 3 );
        Render.String(screen_size[0] /2, screen_size[1] /2 +85, 1, isInverted ? "LEFT" : "RIGHT", [ 255, 255, 255, 255 ], 3 );
    }
    else if(isDesyncMode == 1)
    {
        Render.String(screen_size[0] /2, screen_size[1] /2 +86, 1, isInverted ? "RIGHT" : "LEFT", [ 0, 0, 0, 255 ], 3 );
        Render.String(screen_size[0] /2, screen_size[1] /2 +85, 1, isInverted ? "RIGHT" : "LEFT", [ 255, 255, 255, 255 ], 3 );
    }

    
}}

function Main()
{
    Global.RegisterCallback("Draw", "drawString1")
}

Main();
UI.AddCheckbox("Pulse Bar")
function pulserect() {
	if (UI.GetValue("Pulse Bar")){
		const alpha = Math.sin(Math.abs(-Math.PI + (Globals.Curtime() * (1 / .75)) % (Math.PI * 2))) * 255;

		var screensize = Global.GetScreenSize();

		Render.FilledRect(0, 0, screensize[0], 5, [251, 204, 209, alpha])
	}
}
Global.RegisterCallback("Draw", "pulserect");



UI.AddSliderInt("", 0, 0);

UI.AddLabel("* Pasted for Delp Config")
UI.AddLabel("* Credits: OneTap Forum")
UI.AddLabel("* depresso, Blu and a lot more!")
