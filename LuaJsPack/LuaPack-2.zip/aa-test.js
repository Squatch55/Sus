/*
 *    Literally making this aa on mobile...
 *    Future me is sad.
 */ 

var tick = 0; //will count ticks.

function antiaim() {

    AntiAim.SetOverride(1);
    tick++;
    if (tick > 3) {
        AntiAim.SetFakeOffset(40 + Math.ceil((Math.random()) * 20));
        AntiAim.SetRealOffset(0);
        AntiAim.SetLBYOffset(40 + Math.ceil((Math.random()) * 30));
    } else {
        AntiAim.SetFakeOffset(-40 - Math.ceil((Math.random()) * 30));
        AntiAim.SetRealOffset(0);
        AntiAim.SetLBYOffset(-40 - Math.ceil((Math.random()) * 30));
    }
    //reset the tick count to 0 every 6 ticks.
    if (tick == 6) {
        UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", 0);
        UI.SetValue("Anti-Aim", "Fake-Lag", "Jitter", 0);
        tick = 0;
    } else {
        UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", Math.floor(Math.random()*7));
        UI.SetValue("Anti-Aim", "Fake-Lag", "Jitter", Math.floor(Math.random()*100));
    }
} Cheat.RegisterCallback("CreateMove", "antiaim");
