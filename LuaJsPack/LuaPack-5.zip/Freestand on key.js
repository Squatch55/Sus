UI.AddHotkey("freestand key");

function onCreateMove()
{
    if(UI.IsHotkeyActive("Script items", "freestand key"))
    {
        UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Auto direction", true);
    }
    else
    {
        UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Auto direction", false);
    }
}
Global.RegisterCallback("CreateMove", "onCreateMove");

function onDraw()
{
    if(UI.IsHotkeyActive("Script items", "freestand key"))
    {
        Render.String( 15, 500, 0, "free", [0, 255, 255, 125], 4);
    }
}
Cheat.RegisterCallback("Draw", "onDraw");