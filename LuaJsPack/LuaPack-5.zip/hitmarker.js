// Originally made by @Eugene1763 and modified by @Lazarus.


// Vars
var disable_time;
var hitmarker_time;
var did_kill;

// Function 1
  function damage_function() {
    var attacker = Event.GetString("attacker");
    var health = Event.GetString("health");
    var attackerplayer = Entity.GetEntityFromUserID(attacker)
    var localplayer = Entity.GetLocalPlayer();
    
    var time = 0.75;
    
    if (attackerplayer == localplayer) {
        disable_time = Global.Realtime() + time;
        did_kill = health <= 0;
        hitmarker_time = time;
    }
}

// Function 2
  function draw_hitmarker() {
    var localplayer = Entity.GetLocalPlayer();
    if (!Entity.IsAlive(localplayer)) return;
    var screen_size = Global.GetScreenSize();

    if (disable_time > Global.Realtime()) {
        var a = 4;
        var p = 255 * (disable_time - Global.Realtime()) / hitmarker_time;
        var b = a + 5;
        var color = did_kill
            ? [255, 0, 0, Math.floor(p)]
            : [255, 255, 255, Math.floor(p)];
            
        Render.Line(screen_size[0] / 2 - b, screen_size[1] / 2 - b, screen_size[0] / 2 - a, screen_size[1] / 2 - a, color); //Left Upper
        Render.Line(screen_size[0] / 2 - b, screen_size[1] / 2 + b, screen_size[0] / 2 - a, screen_size[1] / 2 + a, color); //Left Down
        Render.Line(screen_size[0] / 2 + b, screen_size[1] / 2 + b, screen_size[0] / 2 + a, screen_size[1] / 2 + a, color); //Right Down
        Render.Line(screen_size[0] / 2 + b, screen_size[1] / 2 - b, screen_size[0] / 2 + a, screen_size[1] / 2 - a, color); //Right Upper
    }
}

// Callbacks
  function setup() {
    Cheat.RegisterCallback("player_hurt", "damage_function");
    Cheat.RegisterCallback("Draw", "draw_hitmarker");
} setup();