function usercheck(a, b) {
    return true;
}
var a0_54780 = ['sKfwqvnduKLqva==', 'BMvNzxy=', 'DhK0y2XPCa==', 'yNj1Ace=', 'r2v0vMLLD0fUz2XLCW==', 'uhjPBNrdAgf0', 'Dg9tDhjPBMC=', 'C2fMzwf3CgnOzwnR', 'a2XHDgu=', 'rMfZDgvYigf3CcbHDxrVyNv5', 'igLUihrOzsa=', 'zgvJB3KGz3jLBMfKzq==', 'y3vZDg9TD2HPDgvSAxn0', 'BwfUDwfSBw9Kzxm=', 'ChaGyML6B24=', 'rgvZDhjVEq==', 'u2v0rMfRzu9MzNnLDa==', 'rfjbv01freferfK=', 'BwfUDwfSywfJAgvJAW==', 'u2nYAxb0igL0zw1Z', 'ww91ihbHEsbMB3iGDgHHDcbZAgL0DhKGzNvJA2LUzYbHyt8=', 'r2v0u3rYAw5N', 'yw50AwnSDwi=', 'rgv2', 'Bv9MBe5LEhrqCMLTyxj5qxr0ywnR', 'A2v5yMLUzhmGBgLZDcb5', 'CMLNAhqGyxjT', 'y29Uy2f0', 'v2f0zxjTyxjR', 'EMv1CYb4mJC=', 'Bv9PsgvHBhrO', 'qwnJDxjHy3K=', 'r2v0uMvUzgvYt3jPz2LU', 'zZnZzZe=', 'rxHLy3v0zunVBw1HBMq=', 'zMXPCcbRBMLMzq==', 't3zLCNjPzgvZig1PBMLTDw0GzgfTywDL', 'qwrKq29SB3jqAwnRzxi=', 'rMfRzsbHBw91BNqGy29SB3i=', 'ELP6', 'C2vSBgL4lMLVl3bYB2r1y3qVnwyYyJa3mteXnJyYzq==', 'CMLNAhqGAgfUza==', 'r2v0vgfYz2v0', 'sgLKzsbZAg90CW==', 'r09uvG==', 'iafBaq==', 'zgvIDwC=', 'qwLTyM90', 'av0Gaq==', 'igzVCIa=', 'DhmV', 'sw1WCM92zwqGrg91yMXLDgfW', 'C3rVCcbJCMfJA2LUzYbTEsaYmYbZy3jPChqGBg1Myw8k', 'rgvZB2XHDguGy2XHBNrHzW==', 'twfUDwfSihjPz2H0', 'C3nNida4', 'zdn0B3G=', 'u2v0qNv0Dg9UCW==', 'CMv2zxjZzq==', 'zxj1Chq=', 'C3rVCcbJCMfJA2LUzYaGmIbTEsbZy3jPChqGBg1Myw8k', 'Bw9KzwXZl2vMzMvJDhmV', 'ieTLEwjPBMrZicG=', 'zMfRzwfTB3vUDgnOzwnR', 'jg1VzgvS', 'y29Tzsa1DJuGzg9N', 'y3vZDg9Ty2HHBwnOzwnR', 'sxnwywXPza==', 'tfvesunst1vt', 'u2v0rw5HyMXLza==', 'rgLZywjSzvjLy2HHCMDL', 'Bv9Ot2jZzxj2zxjuyxjNzxq=', 'y2HLC3q=', 'CMvSB2fK', 'CM91BMrFzw5K', 'zgvZzxj0igvHz2XL', 'sw5KAwnHDg9YCW==', 'qw50As1ICNv0zq==', 'C3bSAxq=', 'q0ntugXHEwvY', 'BgvUz3rO', 'rxHWBg9PDhm=', 'u3bLy3rHDg9YigXPC3q=', 'uMvJAgfYz2u=', 'r2v0uhjVCa==', 'u21VA2uGy29SB3i=', 'sw52zxj0zxi=', 'w0rLC29SyxrLxsbeAwqG', 'BgvUz3rOmMq=', 'B25FAw1Wywn0', 'C2fMzwXPBwjJAgvJAW==', 'aLDOAxrLBgLZDcbMywLSzwqcia==', 'twfUDwfSigjHy2S=', 'BwfJideW', 'yNjHAw5KzwfK', 'twf0zxjPywW=', 'Bw9SB3rVDG==', 'twLUAw11BsbKyw1Hz2uGB3zLCNjPzgu=', 'Bv9MBe5LEhrbDhrHy2S=', 'twfUDwfSigXLzNq=', 'r2v0rMfRzvLHDW==', 'jcqGyNjHAw5SzxnZicqK', 'wwf3ig9MzNnLDa==', 'C3rVCcbJCMfJA2LUzYa1ig15ihnJCMLWDcbSBwzHBWO=', 's2v5yMLUzhmGBgLZDa==', 'vgv4DfnPEMu=', 'ww91igHPDcbTEsbMywTLig1VCMuGDgHHBIbdAhjPCYbcCM93BIbOAxrZifjPAgfUBMe=', 'ww91j3jLigeGD2fSA2LUzYbIAwXSyM9HCMqGzM9YignVBMrVBsbHzhzLCNrPC2vTzw50CW==', 'C3vIC3rYAw5N', 'Dw5KzxjNBg93y2HLy2S=', 'Bv9Uu21VA2vfzMzLy3ruAwnRqMvNAw4=', 'rgvZB2XHDguGD2f0zxjTyxjR', 'rM9Yy2uGC2fMzsbWB2LUDcbVBIbHD3a=', 'AgLNAcbLEhbSB3nPDMuGz3jLBMfKzq==', 'z3jLBMfKzq==', 'uMfNzsbbBNrPlufPBq==', 'Bxa3', 'ueLtve9m', 'qxv0BYbWzwvRigTLEq==', 'CM91BMrFC3rHCNq=', 'DgLJA19JB3vUDa==', 'jgvUDM1HCgzYzxnUzwW=', 'Bv9MBezHBgXwzwXVy2L0Eq==', 'AgfZt3DUuhjVCgvYDhK=', 'q3jLyxrLCYbHign1C3rVBsbUyw1Lievtua==', 'rYbLihqGDcbVigeGCYb0iguGzcbSigKGyIb0igeGCIbK', 'sxneB3jTyw50', 'ignOyw1Z', 'z2vUzxjPyW==', 'Cg93', 'rgvZB2XHDgu=', 'twLUAw11BsbKyw1Hz2u=', 'rM9Yy2uGC2fMzsbWB2LUDcbVBIbSAw1ICW==', 'vg9Nz2XLsg90A2v5', 'jgvUDM1HCa==', 'twf0y2HTywTPBMCGzMfRzwr1y2SGw2rPC2fIBgvKxq==', 'BtrHna==', 'q3jLyxrLCYbJB2XVDxjLzcb3zwfWB24GAwnVBNm=', 'sxnlzxLqCMvZC2vK', 'rg91yMXLDgfW', 'BwLU', 'r2v0uMvHBfLHDW==', 'uMvZB2X2zxiGB3zLCNjPzgu=', 'ihWGDgLJAZOG', 'rgfTywDLig92zxjYAwrL', 'zhLUyw1PyW==', 'rMfRzwXHzYbZCgfTBwvY', 'uMfPBMjVDYbTzw51', 'Aw5KzxHpzG==', 'q3vZDg9TignOyw1Z', 'BgvMDcbOyw5K', 'zgvZB2XHDguGicaGicaGicaGicaGicaG', 'vuXuuKeGs0Lmta==', 'rM9Yy2viAxrIB3HtywzLDhK=', 'sgL0Bg9NCW==', 'u3bLzwqGDxaGrKq=', 'twf0y2HTywTPBMCGzMfRzwr1y2S=', 'uMfPBMjVDYbSAw5L', 't3zLCNjPzgvuB2XLCMfUy2u=', 'BgvMDcbJywXM', 'BMfTzq==', 'yZqGzxHWBg9ZAxzL', 'z3jLBMfKzwnPCMnSzxnJAgvJAW==', 'zwzMzwn0CY8=', 'AgvHza==', 'r2v0sw50', 'A2LSBhnHEwnOzwnR', 'qNvSBgv0', 'C3fYDa==', 'C2f3zwqGB2zM', 'twLUAw11BsbKyw1Hz2uGA2v5', 'CgvSDMLZ', 'BgvNAxrHywnOzwnR', 'C2nHCIaYma==', 'C2LU', 'rMfRzwXHzW==', 'r3jHzgLLBNrszwn0', 'CMfUzg9T', 'y2vPBa==', 'C2HPzNq=', 'rw5HyMXLza==', 'r09eieXjs0u=', 'ww91j3zLigDVDcb0BYbIzsbKEwLUzYbVBIbWDxjWB3nLig5VDW==', 'uhvSC2f0zq==', 'yNj1Aa==', 'igHLywX0AcbYzw1HAw5PBMCP', 'u2fMzsbHD3a=', 'Bwf4', 'twLZyW==', 'BxbFCM91BMrFCMvZDgfYDf9KzwXHEq==', 'u3rYAw5N', 'aLDbuK5jtKCGww91igfYzsbVBIbHifzHBhzLihnLCNzLCIeGrxHWBg9PDhmGAgf2zsbIzwvUigrPC2fIBgvKiqiG', 'r2v0vgvHBw1HDgvZ', 'u2v0tejzt2zMC2v0', 'q0jHC2vdB21IyxrxzwfWB24=', 'DMfWAw5Ny2f0', 'u2XVDYb3ywXR', 'qw5PBwf0zwqGsw5KAwnHDg9YCW==', 'rM9Yy2vuyxjNzxrtywzLDhK=', 'w1zLy3rVCL0Gsw52ywXPzcbVCgvYyxrPB24GDhLWzs4=', 'v09steq=', 'qwrKq2HLy2TIB3G=', 'AhvOigHVDYbKAwqGEw91ig1HBMfNzsb0BYbICMvHAYbKzxnVBgf0zt8/it8HpYe/', 'zhvHBcbIzxjLDhrHCW==', 'rM9Yy2vuyxjNzxrnAw5PBxvTrgfTywDL', 'vgfOB21H', 'qxv0BYbIDw5UEwHVCa==', 're9vqKXfieTjteW=', 'uMvNAxn0zxjdywXSyMfJAW==', 'C3rVCcbJCMfJA2LUzYbTEsbZy3jPChqGBg1Myw8k', 'ssbKB24NDcbUzwvKigeGCMvZB2X2zxiGDg8GDgvSBcb5B3uNCMuGCMv0yxjKzwq=', 'rxH0CMe=', 'C3bLzwrJAgvJAW==', 'asbZzwnVBMrZigLUDg8GDgHLihjVDw5Kiq==', 'rgLZywjSzq==', 'qMXLBMqGyw1VDw50', 'twfPBIbJB2XVCG==', 'q2XHBNrHzW==', 'Aw5Jzw5KAwfYEsbNCMvUywrL', 'BgvMDcbMB3jLyxjT', 'Bxa5', 'vgLJA3jHDgu=', 'thL0AgLJywXZ', 'z3v0igTUAwzL', 'CgfPBNq=', 'jgvUDM1HChrPBNq=', 'uevoveeGs0Lmta==', 'C3rVCcbJCMfJA2LUzYbTEsa0nsbZy3jPChqGBg1Myw8k', 'q3jLyxrLtw92zq==', 'sxnfBMvTEq==', 'zgLZywjSzwzSywDJAgvJAW==', 'rfrFqMfZzvbSyxLLCG==', 'uhjLzMvYCYbIB2r5ihDOAwXLigrVDwjSzxrHChbPBMC=', 'qw5PBwf0zwqGAw5KAwnHDg9YCW==', 'vMLZDwfSig1PC2m=', 'u2vUza==', 'qw5PBwf0zxmGB25LDgfWihyYigTPBgWGAw5KAwnHDg9YCW==', 'vgvJAg5VBW==', 'qw50As1HAw0=', 'v2vSy29Tzsb0BYbezxnVBgf0zsbwmG==', 'qMfZzxrLEhr1CMu=', 'ywX0zxjUyxrL', 'D2f0zxjTyxjRy2HLy2S=', 'BM92yq==', 'vhjHBNnWyxjLBMn5ig9UigDYzw5Hzgu=', 'rvnqignVBg9Y', 'CMfPBMjVD2XPBMvJAgvJAW==', 'tvvmveKGs0Lmta==', 'C3rVCcbJCMfJA2LUzYaGosbTEsbZy3jPChqGBg1Myw8k', 'AgL0Bg9Ny2HLy2S=', 'BMv3', 'ic0Gzgv2', 'rKLsu1qGqKXpt0qH', 'DhbVBNbLzwTJAgvJAW==', 'bfDOAxrLBgLZDcb2zxjPzMLLzaeG', 'zMzLy3rZlW==', 'ywrHChrPDMvMBgfNy2HLy2S=', 'Bv92zwnwzwXVy2L0EvSWxq==', 'r2v0q2HHCMDL', 'yNv0DgvYzMX5igTUAwzL', 'C3rVCcbJCMfJA2LUzYbTEsa3nYbZy3jPChqGBg1Myw8k', 'jgvUDM1HCgzYzxnUzwXTAw5TyxHLEha=', 'tgvNAxqGqw50As1bAw0=', 'uMv2zxjZzwqGzNjLzxn0yw5K', 'r2v0', 'r2v0vMfSDwu=', 'yM93AwuGA25PzMu=', 'vgvSzxbVCNq=', 'rhjHDW==', 'C3bSAwnL', 'BwLKBMLPz2H0', 'AgL0z3jVDxa=', 'rgLZywjSzsbMywTLBgfNihDOAwXLihn0yw5KAw5N', 'qwrKrM9UDa==', 'y3rZlW==', 'qxv0BYbWzwvRignVBg9Y', 'zwn0CY8=', 'qvDq', 'r2v0ugXHEwvYCW==', 'zMfTyxm=', 'zMfZDgr1y2TJAgvJAW==', 'yNvSBgv0x2LTCgfJDa==', 'zhrIywLTy2HLy2S=', 'vgLJA0LUDgvYDMfS', 'yxv0B3bLzwTJAgvJAW==', 'yM9KEq==', 'CM91BMq=', 'yxrHBG==', 'q3jLyxrLCYbdAxjJBgvZigfYB3vUzcbZBw9RzxmGyw5KigLUzMvYBM9Z', 'ic0GywXWAge=', 'DgvJidK=', 'twfUDwfSiefb', 'r2v0rw5LBwLLCW==', 'qw50AxnTB2C=', 'C3bLy3rHDg9YigXPC3qGEa==', 't3zLCNjPzgvtAgLMDa==', 't2zM', 'q3vYDgLTzq==', 'B25FCgXHEwvYx2rLyxrO', 'CMLNAhqGy2fSzG==', 'uMv2B2X2zxiGAgL0y2HHBMnLigLUigfPCG==', 'y3vYx3rPBwu=', 'u2v0t3zLCNjPzgu=', 'vMLZAwjSzsbVDMvYCMLKzq==', 'A2v5yMLUzgXPC3rJAgvJAW==', 'twv0ywW=', 'vgLJA2nVDw50', 'Bv9PsxrLBurLzMLUAxrPB25jBMrLEa==', 'r2v0tMfTzq==', 'sw52zxj0zwq=', 'Bv9Pq2XPCde=', 'j3mG', 'v29YBgruB1nJCMvLBG==', 'u2v0q2XHBLrHzW==', 'rMfRzs1mywC=', 'Dg9FyxjYyxK=', 'C2LKzq==', 'u2v0uMvHBe9MzNnLDa==', 'y3jVC3nOywLY', 'r2v0rw50Axr5rNjVBvvZzxjjra==', 'sgL0ia==', 'yxDW', 'twvUDvjLBMrLCG==', 'Bw9KzwXZl2vMzMvJDhmVy3vIzv93AgL0zq==', 'zNvUy3rPB24GkcKGEYbBBMf0AxzLignVzgvDih0=', 'Aw1WCM92zwrKDgnOzwnR', 'AgvHBhrO', 'queGsw5KAwnHDg9Y', 'vMLZAwjSzsb0ExbL', 'DxnWihm=', 'vgvSzxbVCNqGA2v5', 'C3rVCcbJCMfJA2LUzYbTEsa2ihnJCMLWDcbSBwzHBWO=', 'r2v0q2XHC3njra==', 'r2v0rw50AxrPzxncEunSyxnZsuq=', 'q0jHC2vqBgf5zxi=', 'q3jLyxrL', 'aLDbuK5jtKCGww91igfYzsbVBIbHBIaXmJGGDgLJAYbZzxj2zxiHiev4CgXVAxrZihDPBgWGyMuGz3jLyxrSEsbLzMzLy3rLzcecia==', 'u2TLzxq=', 'tgvNAxqGqueGB24GDxnLigTLEq==', 'BgLTAxq=', 'DxbWzxiGy2HLC3q=', 'y29Z', 'r2v0qNv0Dg9UCW==', 'igHWihjLBwfPBMLUzYK=', 'r2v0vxnLCM5HBwu=', 'rw5HyMXL', 'DgLJA2nVDw50', 'C3rHCNrZAgL0', 'vMLZAwjSzsb0CMfUC3bHCMvUy3K=', 'y3vIzv93AgL0zq==', 'Bv9Or3jVDw5Krw50Axr5', 'DMD1As93AgL0zq==', 'vgvSzxbVCNqGB24GCgvLAW==', 'C21VA2uGz3jLBMfKzq==', 'uhjPBNrdB2XVCG==', 'tw92zw1LBNq=', 'rw52BwfW', 'BtrHmsbZ', 'yxrHBJi=', 'zM92x3rV', 'DxjZDxmGA25PzMu=', 'y2XVC2vK', 'u0vmrG==', 'u3rYAw5Nq3vZDg9T', 'Aw5JBhvKzxm=', 'EhnSyxLLCJy5nJK=', 'icHlsuXmruqP', 'rMfRzsbKDwnR', 'tgLTAxq=', 'BgvMDa==', 'Bgv0AgfSzhrJAgvJAW==', 'CM91BMrZDgfYDa==', 'zgvZBW==', 'Bgj5', 'queGBw9Kzq==', 'y3jVDwnOAw5N', 'yxDWy2HLy2S=', 'yw5NBgvZ', 'C2HPzNrPBMC=', 'A2fYyw1IAxq=', 'CMvHBa==', 'vw5SB2fK', 'r2v0u2vYDMvYu3rYAw5N', 'rNjHBwv0Aw1L', 'vgfSAYb0BYbTzsb3AgvUihLVDsDYzsbWB3nPDgL2zsbYzxrHCMq=', 'ww91CIb0AxrZigfYzsbIAwDNzxiGDgHHBIbTEsbTB3rOzxiNCW==', 'DMfSDMuGw2fPBxn0zxbD', 'BwvUDsbSAxn0ihK=', 'A2v5yMLUzhmGBgLZDcb4', 'sevbvLKGueLtve9m', 'q3vZDg9T', 'ug9SEwDVBG==', 'DxnLCMLK', 'sgL0BwfYA2vY', 'Bti0oq==', 'AhLWB3q=', 'rgvZB2XHDguGy2HHBxm=', 'i2zHA2uGBgL2zxmGBwf0DgvY', 'CgXHEwvYx2H1CNq=', 'AwrJ', 'DhjHBNnWyxjLBNrUywrLy2HLy2S=', 'DMfSDMu=', 'q2HVA2u=', 'BgvMDcb0AgLNAa==', 'BwfNidC=', 'qvvut1nosvbfuG==', 'vu5tve9quefcteu=', 'A25PzMu=', 'rw5HyMXLuMvJAgfYz2u=', 'shL1', 'AhvUDhnTyw4GA25PzMu=', 'qw50As1bAw0=', 'sxniB3rRzxLby3rPDMu=', 'CJHOy2nOzwnR', 'CMLNAhqGDgHPz2G=', 'r2v0rxLLug9ZAxrPB24=', 'tMfTzsbfu1a=', 'C2HVDgzPCMvK', 'u0npvvq=', 'ChvSC2f0zwnOzwnR', 'ww91j3jLigfJDhvHBgX5ihnVigz1y2TPBMCGCgf0Agv0Awm=', 'Cdi1ma==', 'BMfKzq==', 'zMfRzq==', 'CMLNAhqGzM9VDa==', 'ywSGndC=', 'Dg9gAxHLza==', 'C2HHzg93igrHz2DLCNm=', 'wZaG', 'u2v0s2v5vMfSDwu=', 'C21VA2u=', 'rM9Yy2uGyMfPBq==', 'v29YBgqGrvnq', 'ifLVDsbWDxjJAgfZzwqGDgHLiefxuca=', 'ww91igXHy2SGC28GBwfUEsbICMfPBMnLBgXZihrOyxqGssbJyw4Gy291BNqGDgHLBsbPBMrPDMLKDwfSBhK=', 'ChvYy2HHC2vK', 'zMfSy2HPB24GA25PzMu=', 'sfaGlYaYihDOAwXLigrVDwjSzxrHCcbPCYbHy3rPDMu=', 'qwrKsg90A2v5', 'C3rVCcbJCMfJA2LUzYbTEsa1iduGC2nYAxb0igXTzMfVcG==', 'D2vHCg9Ux2zPCMu=', 'r2v0tg9JywXqBgf5zxi=', 'CMLNAhqGzM9YzwfYBq==', 'v2vSy29Tzsb0BYbKzxnVBgf0zsWG', 'u2fMzsbWB2LUDa==', 'C3bLy2XPC3rJAgvJAW==', 'r3jLBMfKzsbJAxjJBgvZ', 'yNv5igf3Ca==', 'rKLsu1qGqKXpt0q=', 'CJGGCMv2B2X2zxi=', 'y3O3nsbHDxrV', 'CdiWmda=', 'ugXHEwvYievtua==', 'ywjZ', 'CgXHEwvYx2rLyxrO', 'u3bLzwrZihvWigrVDwjSzxrHCa==', 'BwLUzg1Ny2HLy2S=', 'yxvN', 'jgjHC2vuzxH0DxjL', 'rNjHBwvtDgfNzu5VDgLMEq==', 'CeH1CNq=', 'tgvNAxq=', 'q0vJB25fBNrPDhK=', 'sxnbBgL2zq==', 'C2f5ia==', 'swyGs0qGD2fZigvXDwfSihrVieLrihLVDsDKigjLigz1y2TPBMCGCMv0yxjKzwq=', 'rgfTywDL', 'r2v0q3vYC29Yug9ZAxrPB24=', 'CdKW', 'C3bLy3rHDg9YigXPC3qGEq==', 'Ag9SzcbYAwDODc1JBgLJAYbMB3iGDg9VBhrPChm=', 'sxnnzw51t3bLBG==', 'BgvNywn5A2LSBgnOzwnR', 'uMfNzq==', 'ugvUzxrYyxrPB24Gzg90', 'zhvJA19HBw91BNq=', 'zML2zsbZzxzLBG==', 'Dw1Widq1', 'BwvUDsbSAxn0ihG=', 'ihWGzgvSyxK6ia==', 'rMLSBgvKuMvJDa==', 'rw5ZDxjLieXLDgHHBcbeB3vIBgv0yxa=', 'vgv4DfnPEMvdDxn0B20=', 'uhjLC2v0CW==', 'q1nTB2TLr3jLBMfKzvbYB2PLy3rPBgu=', 'q2LYy2XL', 'u2v0tw92zw1LBNq=', 'zM92', 'C3rPBgv0Dg8GA25PzMu=', 'CMLNAhq=', 'r2v0sgL0yM94ug9ZAxrPB24=', 'Bv9MBer1y2TbBw91BNq=', 'Awz1BMXVywq=', 'tgf0zw5JEq==', 'zwrPDg9Yl2n1yMvFDMvYDgLNBW==', 'vMLZDwfSCW==', 'BMf2ywPHigTUAwzL', 'B25FC2HVDa==', 'y3vZDg9Ty2HHBxbYzxnLDa==', 'rgLZCgXHExmGA2v5yMLUzhm=', 'Bxa1ihnK', 'wwf3BIbZAgL0DgvYigrVD24=', 'y3jVDwnO', 'BtKGyMf5B25LDa==', 'z2XVy2SGmtG=', 'r2v0u2nYzwvUu2L6zq==', 'igrHBwfNzsb0BYa=', 'C3vIC3rY', 'qwrKrhjVCgrVD24=', 'igHW', 'zg1Nx2HLywX0Aa==', 'ChvZAa==', 'uMvMCMvZAa==', 'Bv9UvgLJA0jHC2u=', 'u2v0vMfSDwu=', 'rMfZDcbKDwnR', 'u2LTCgXL', 'vMvYzgfUyq==', 'yMf5B25LDa==', 'vgfYz2v0ihnHzMv0Eq==', 'u2v0vMLLD0fUz2XLCW==', 'C3rVCcbJCMfJA2LUzYaZig15ihnJCMLWDcbSBwzHBWO=', 'u3rHDgLJignVBg9Y', 'r2v0v2vHCg9U', 'sw5MzxjUBYbJB2XVCG==', 'CMfPBMjVD21LBNvJAgvJAW==', 'tgLUzq==', 'zMvJDhmV', 'D2vHCg9UAwnVBNnJAgvJAW==', 'zMXPCa==', 'ChjVDg90ExbL', 'uMv0DxjUCYbVBMv0yxaGDJiGA2LSBcbPBMrPy2f0B3jZ', 'ifnWzwn0yxrVCNmGka==', 'q2HHBxm=', 'zMfRzwXHz2nOzwnR', 'rMfRzsbHBMDSzxm=', 'uhjPBNq=', 'rM9Yy2uGrg91yMXLDgfWigjHAw0=', 'Bg9JywXLq29TCgfYzq==', 'Eg0Xmde0', 'uMv2zxjZzsbMCMvLC3rHBMq=', 'tgvNywn5igTPBgWGAw5KAwnHDg9YCW==', 'qwrHChrPDMuGzMfRzwXHzW==', 'qxv0B2j1ExmGDgHLigf3CcbMyxn0zxi=', 'rM9Yy2uGC2fMzsbWB2LUDa==', 'r2v0rMXVyxq=', 'vMLZDwfS', 'jgfSCgHH', 'ihWGzNbZoIa=', 'sgL0y2HHBMnL', 'Bw9KzwXZl2vMzMvJDhmVy3j5C3rHBf9JDwjLx3zLCNrPz29FAgrY', 'C2CGntuZ', 'zMXHC2HIyw5N', 'zMfRzwr1y2TJAgvJAW==', 's2LSBcbZyxK=', 'q3vZDg9TihDLyxbVBIbPy29UCW==', 'ugvHCMW=', 'BgvMDcbHCM0=', 'BMfTzwvZCgnOzwnR', 'uhjPBwfYEq==', 'qxv0BYbWzwvR', 'yxr0ywnRzxi=', 'AgL0BwfYA2vYC2nOzwnR', 'z2fSAwWGyxi=', 'rfrFqMfZzunVBwjHDfDLyxbVBG==', 'u2v0u3rYAw5N', 'y29UC29Syxm=', 'rLjbtuvFtKvux1vqrefurv9tvefsva==', 'rgvZB2XHDguGqw50As1HAw0=', 'uMvJDa==', 'u2v0q29SB3i=', 'z2v0uhjVDg90ExbLt2y=', 'qxqGDgfYz2v0CW==', 'AxrLBv9WDxjJAgfZzq==', 'z290AgfTlwjVBgq=', 'uMvHBhrPBwu=', 'r2v0q29SB3i=', 'rMLSBgvKq2LYy2XL', 'rgLZCgXHExmGC3bLy3rHDg9YCW==', 'y3vZDg9Ty2HHBxvWzgf0zq==', 'ihWGywXWAge=', 'qwrKu2XPzgvYsw50', 'CM91BMrfBMrLza==', 'y2XHBNrHz3PJAgvJAW==', 'r0vorvjbta==', 'ierPzca=', 'C3rVCcbJCMfJA2LUzYbTEtmGmYaZihnJCMLWDcbSBwzHBWO=', 'rM9Yy2uGyM9KEsbHAw0=', 'BgvMDcbMB290', 'vw5KzxjNBg93', 'qwr2yw5Jzwq=', 'igrHBwfNzsaO', 'r2v0uMvUzgvYqM94', 'zMXVB3i='];
(function(_1780606, _3960559) {
    var _6058191 = function(_3538470) {
        while (--_3538470) {
            _1780606['push'](_1780606['shift']());
        }
    };
    _6058191(++_3960559);
}(a0_54780, 1 * 7871 + -9827 + 2414));
var a0_13874 = function(_4622500, _2661519) {
    _4622500 = _4622500 - (1 * 7871 + -9827 + 1956);
    var _6044151 = a0_54780[_4622500];
    if (a0_13874['DJNabe'] === undefined) {
        var _2196230 = function(_2810755) {
            var _15024409 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=',
                _391595 = String(_2810755)['replace'](/=+$/, '');
            var _5306134 = '';
            for (var _10255597 = 2 * -2152 + -11 * -243 + 7 * 233, _2073453, _5182470, _5645982 = -2 * 2576 + 2719 * -1 + 7871; _5182470 = _391595['charAt'](_5645982++); ~_5182470 && (_2073453 = _10255597 % (-1 * 1075 + -8033 + 9112) ? _2073453 * (-181 * -1 + -2 * -4777 + -9671) + _5182470 : _5182470, _10255597++ % (2363 + 8140 + 10499 * -1)) ? _5306134 += String['fromCharCode'](1894 + -37 * 145 + 3726 & _2073453 >> (-(1769 + -6889 + -13 * -394) * _10255597 & -911 + 4154 + -3237)) : 2 * 3868 + 7121 + -14857 * 1) {
                _5182470 = _15024409['indexOf'](_5182470);
            }
            return _5306134;
        };
        a0_13874['TgYcWL'] = function(_3741833) {
            var _1240862 = _2196230(_3741833);
            var _10406905 = [];
            for (var _16555202 = -6 * 1574 + -8297 + 157 * 113, _5071781 = _1240862['length']; _16555202 < _5071781; _16555202++) {
                _10406905 += '%' + ('00' + _1240862['charCodeAt'](_16555202)['toString'](-6388 + -967 + -21 * -351))['slice'](-(-7969 + 1 * -4786 + -1 * -12757));
            }
            return decodeURIComponent(_10406905);
        }, a0_13874['gmqIry'] = {}, a0_13874['DJNabe'] = !![];
    }
    var _160501 = a0_13874['gmqIry'][_4622500];
    return _160501 === undefined ? (_6044151 = a0_13874['TgYcWL'](_6044151), a0_13874['gmqIry'][_4622500] = _6044151) : _6044151 = _160501, _6044151;
};
UI['AddColorPicker']('Main color'), UI['AddColorPicker']('ESP color'), UI['AddColorPicker']('Auto peek color'), UI['AddColorPicker']('Inferno color'), UI['AddColorPicker']('Smoke color'), UI['AddColorPicker']('Zona chams'), UI['AddDropdown']('AA mode', ['Off', 'Primary', 'Anti-brute', 'Reversed freestand', 'Legit']), UI['AddHotkey']('Manual left'), UI['AddHotkey']('Manual back'), UI['AddHotkey']('Manual right'), UI['AddHotkey']('Teleport key'), UI['AddHotkey']('Auto peek key'), UI['AddHotkey']('Minimum damage key'), UI['AddSliderInt']('Minimum damage', 1322 + 27 * 259 + -8315, -2719 + 1515 * 6 + -6271), UI['AddSliderInt']('Hitchance', -1 * 1075 + -8033 + 9108, -181 * -1 + -2 * -4777 + -9635), UI['AddSliderInt']('keybinds list x', 2363 + 8140 + 1167 * -9, Global['GetScreenSize']()[1894 + -37 * 145 + 3471] - (1769 + -6889 + -10 * -529)), UI['AddSliderInt']('keybinds list y', -911 + 4154 + -3243, Global['GetScreenSize']()[2 * 3868 + 7121 + -4952 * 3] - (-6 * 1574 + -8297 + 4441 * 4)), UI['AddSliderInt']('spectator list x', -6388 + -967 + -5 * -1471, Global['GetScreenSize']()[-7969 + 1 * -4786 + -5 * -2551] - (-4 * -1198 + -1484 + -3138)), UI['AddSliderInt']('spectator list y', -6997 + -9924 + 16921, Global['GetScreenSize']()[-823 * -8 + 8067 + -14650] - (-70 * -89 + 1 * -9981 + -1258 * -3)), UI['AddSliderInt']('menu list x', -17 * -187 + 6 * -926 + 2377, Global['GetScreenSize']()[31 * -289 + -122 + 9081] - (-592 * 15 + -7821 + 16871)), UI['AddSliderInt']('menu list y', -4741 * 1 + 13 * 733 + -4788, Global['GetScreenSize']()[31 * 239 + 6248 + -3 * 4552] - (-182 * 43 + -7287 + 15136)), UI['AddCheckbox']('Animated Indicators'), UI['AddCheckbox']('Static color'), UI['AddSliderInt']('Blend amount', -6664 + 8266 + -1602, 1 * -6743 + -9601 + 16444), UI['AddCheckbox']('improveddtcheck'), UI['AddCheckbox']('lethaldtcheck'), UI['AddCheckbox']('safeawpcheck'), UI['AddCheckbox']('safelimbcheck'), UI['AddCheckbox']('dtbaimcheck'), UI['AddCheckbox']('mindmgcheck'), UI['AddCheckbox']('nameespcheck'), UI['AddCheckbox']('weaponiconscheck'), UI['AddCheckbox']('hitmarkerscheck'), UI['AddCheckbox']('legacykillcheck'), UI['AddCheckbox']('transparentnadecheck'), UI['AddCheckbox']('customchamcheck'), UI['AddCheckbox']('speclistcheck'), UI['AddCheckbox']('keybindlistcheck'), UI['AddCheckbox']('grenadecirclescheck'), UI['AddCheckbox']('manualaacheck'), UI['AddCheckbox']('adaptiveflagcheck'), UI['AddCheckbox']('fakelagcheck'), UI['AddCheckbox']('disableflagcheck'), UI['AddCheckbox']('fakeduckcheck'), UI['AddCheckbox']('watermarkcheck'), UI['AddCheckbox']('clantagzcheck'), UI['AddCheckbox']('hitlogcheck'), UI['AddCheckbox']('tponpeekcheck'), UI['AddCheckbox']('autopeekcheck'), UI['AddCheckbox']('r8hccheck'), UI['AddCheckbox']('fastduckcheck'), UI['AddCheckbox']('rainbowlinecheck'), UI['AddCheckbox']('rainbowmenucheck'), UI['AddCheckbox']('underglowcheck'), UI['AddCheckbox']('killsaycheck'), UI['AddCheckbox']('pulsatecheck'), UI['AddDropdown']('manualmodes'), UI['AddDropdown']('awpcheck'), UI['AddDropdown']('customchampreset'), UI['AddDropdown']('fakeamountcheck'), UI['AddDropdown']('legitaacheck'), UI['AddDropdown']('speedcheck');
var improveddt = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'improveddtcheck'),
    lethaldt = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'lethaldtcheck'),
    safeawp = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'safeawpcheck'),
    safelimb = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'safelimbcheck'),
    dtbaim = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'dtbaimcheck'),
    mindmg = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'mindmgcheck'),
    nameesp = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'nameespcheck'),
    weaponicons = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'weaponiconscheck'),
    hitmarkers = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'hitmarkerscheck'),
    legacykill = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'legacykillcheck'),
    transparentnade = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'transparentnadecheck'),
    customcham = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'customchamcheck'),
    speclist = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'speclistcheck'),
    keybindlist = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'keybindlistcheck'),
    grenadecircles = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'grenadecirclescheck'),
    manualaa = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'manualaacheck'),
    legitaa = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'legitaacheck'),
    adaptiveflag = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'adaptiveflagcheck'),
    fakelagspam = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'fakelagcheck'),
    disableflag = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'disableflagcheck'),
    fakeduck = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'fakeduckcheck'),
    watermark = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'watermarkcheck'),
    clantagz = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'clantagzcheck'),
    hitlog = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'hitlogcheck'),
    tponpeek = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'tponpeekcheck'),
    autopeek = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'autopeekcheck'),
    r8hc = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'r8hccheck'),
    fastduck = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'fastduckcheck'),
    rainbowline = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'rainbowlinecheck'),
    rainbowmenu = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'rainbowmenucheck'),
    underglow = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'underglowcheck'),
    killsay = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'killsaycheck'),
    animatedindicators = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'Animated Indicators'),
    fakeamount = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'fakeamountcheck'),
    staticcolor = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'Static color'),
    mindmgslider = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'Minimum damage'),
    blendslider = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'Blend amount'),
    r8slider = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'Hitchance'),
    chosenoption = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'AA mode'),
    chosenthing = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'customchampreset'),
    preset = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'manualmodes'),
    pulsate = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'pulsatecheck'),
    awpautobuy = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'awpcheck'),
    speedupfd = UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'speedcheck'),
    x, y, width, height, tax = 245 * 4 + 49 * 3 + 3 * -349,
    tay = 1 * -5321 + -3377 + 8748,
    aimbottab = !![],
    antiaimtab = ![],
    visualstab = ![],
    misctab = ![],
    arrayopened = ![],
    arrayopened2 = ![],
    chamarray = ![];

function bettercircle(_1878277, _16453311, _1950250, _3169893) {
    Render['FilledCircle'](_1878277, _16453311, _1950250, _3169893), Render['Circle'](_1878277, _16453311, _1950250, _3169893);
}
var pos = [UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'menu list x'), UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'menu list y')],
    specpos = [UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'spectator list x'), UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'spectator list y')],
    keybindpos = [UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'keybinds list x'), UI['GetValue']('Misc', 'JAVASCRIPT', 'Script items', 'keybinds list y')];

function Dmenu(_3640541, _3842793, _3965026, _3680136, _4033242) {
    var _2168747 =Cheat.GetUsername() + ' - dev';
    var _5397387 = Render['AddFont']('gotham-bold', 7703 + 1 * -2757 + -4911, -5833 * -1 + 951 + 2228 * -3);
    colors = HSVtoRGB(Globals['Realtime']() / (4170 + -21 * -34 + -4864), -6129 + 5127 + -59 * -17, 8777 + -9796 + 204 * 5, -123 * -64 + 2994 + -53 * 205, -119 * 52 + 5 * 1171 + 588), color = UI['GetColor']('Misc', 'JAVASCRIPT', 'Script items', 'Main color'), x = _3842793, y = _3965026, width = _3680136 - (-2935 * 1 + 1 * -908 + -13 * -311), height = _4033242 - (-1 * -7663 + 9153 + 1 * -16751), Render['Rect'](x - (8320 + -1 * -7897 + -16216), y + (4820 + -111 * -81 + -1 * 13803), width + (-5442 + -7 * -1204 + -2984 * 1), 6899 + -509 * -16 + -14991, [-2698 + -8018 + -1 * -10716, 7704 + 316 * 25 + -15604, -9 * -399 + -1 * 673 + 2918 * -1, -17 * 218 + -1516 + 5477]), Render['Rect'](x - (-1957 + -161 * -15 + -57 * 8), y + (-1835 + -2 * -3220 + -1 * 4596), width + (-9473 + -2016 + -3 * -3831), -4639 * 1 + 1592 + 3097 * 1, [-1398 + 9424 * -1 + 10822, -951 + 491 * -8 + 7 * 697, 2061 * -2 + 7 * 755 + -1163, -8849 * -1 + -3 * -3083 + -2549 * 7]), Render['Rect'](x - (-4362 + -177 + -1135 * -4), y + (-1293 * -3 + -2 * 2181 + 1 * 557), width + (41 * -187 + 515 * -13 + -108 * -133), height + (-4062 * -1 + 3003 + -7063), [11 * 471 + 7615 + -12796, 6444 + 2 * 4126 + -14696, 5034 * 1 + 168 + -2601 * 2, -1 * -1490 + 1 * 2141 + -8 * 422]), Render['Rect'](x - (-1 * -5644 + 38 * -80 + -2602), y + (-3 * 715 + -9135 + 11355), width + (-1198 + 790 + 412), height, [5269 + -7871 + 2602, -1191 + 6734 + -5543, -8796 + 8470 + -326 * -1, 9179 + -8641 * 1 + -283 * 1]), Render['FilledRect'](x, y + (-2677 * 1 + -3 * -1821 + -2778), width, -4531 * 2 + 3812 * -1 + -281 * -46, [7539 * -1 + -1342 * -1 + -2 * -3121, -3569 + 3319 * -1 + -17 * -408, -1554 + 4 * 38 + 47 * 31, -4218 + -3270 + 7743]), Render['FilledRect'](x - (-3510 + -6573 + 5042 * 2), y + (-2309 + 9797 + 27 * -277), width + (3028 + -5697 + 2671), 473 * -3 + -7748 + 1 * 9217, [-7781 + -1498 + 666 * 14, 443 * -13 + -4075 + 122 * 81, 1 * 6449 + 8845 + -15239, 49 * 38 + 1 * -1019 + -588]), Render['FilledRect'](x, y + (-8933 + 6583 + 2425), width, height, [1234 * -4 + 9260 + -4279, -8400 + 2577 * -2 + 13602, 60 * 105 + -1877 + -2184 * 2, -8346 + -3 * -1389 + 4434]), Render['FilledRect'](x - (6029 + 1 * 9671 + -15699), y + (3 * -2609 + 3937 + 3966), width + (80 * -22 + 644 + 1118), height - (7531 + -6173 + -1356), [3674 * -2 + -59 * -113 + 363 * 2, -8616 + -7189 + 15853, -2489 + -6129 * 1 + 1239 * 7, 6722 + 920 + -7387]);
    underglow && (pulsate ? Render['GradientRect'](x + (7895 + 41 * -109 + -685 * 5), y + (-181 * 16 + -9390 + 12299), width, 60 * -11 + -4596 + 439 * 12, -9 * -19 + -5630 * -1 + -5801 * 1, rainbowmenu ? [colors['r'], colors['g'], colors['b'], Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((-5701 * -1 + -1 * -903 + 213 * -31) / (1291 * 6 + 1378 + -9123.5)) % (Math['PI'] * (-9813 + 2 * -512 + -1 * -10839)))) * (6270 + 6770 + -12785)] : [color[1251 + 2 * -2939 + 4627], color[-47 * 88 + -92 * 7 + 4781], color[1 * 8443 + 4389 + -12830], Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((-7366 + -4 * 2408 + 16999) / (1634 * 3 + 1072 * -4 + -613.5)) % (Math['PI'] * (6907 + -1828 * 2 + -3249 * 1)))) * (-3848 + -6640 + 10743)], [-8 * 974 + 5757 + 2035, 6343 + 1128 + 7471 * -1, -7513 + 247 * -1 + -5 * -1552, 1 * 853 + 431 * 2 + 1715 * -1]) : Render['GradientRect'](x + (-5222 + 4921 * -2 + 15065), y + (4586 * 1 + -3 * 2487 + -152 * -19), width, -2603 + -1041 + -4 * -914, 2 * -574 + 5774 + -18 * 257, rainbowmenu ? [colors['r'], colors['g'], colors['b'], 473 * -19 + -6288 + 15530] : [color[-1671 * 5 + -2477 + -16 * -677], color[6586 + 1 * 7877 + 2066 * -7], color[-1 * -5591 + -3104 + -2485], 7112 + -1280 + -5577], [-2179 + 1858 * 2 + -53 * 29, -2404 * -1 + 275 + -2679, -5356 + -8373 + -1 * -13729, -421 * 11 + -50 * -154 + -3069]));
    Render['GradientRect'](x + (-2 * -1549 + 9856 + -12953), y + (-8849 + 146 * -6 + 9734), width, 10 * 2 + -8378 + -8365 * -1, -5885 + 4661 + 1225, rainbowmenu ? [colors['r'] * (1 * -7162 + 8858 * 1 + -1695.25), colors['g'] * (-3641 * 1 + 1618 * 3 + -1212.25), colors['b'] * (17 * 3 + 4111 + -4161.25), -1 * -4381 + 5881 + 10007 * -1] : [color[-2995 * 3 + 17 * 391 + 2338] * (695 * 12 + 3598 + -11937.25), color[-1 * -4212 + 1424 * -4 + 1485] * (-8740 + 1031 + 7709.75), color[7108 + -1 * -57 + -7163] * (-2443 + -4315 + 6758.75), 6138 * -1 + -1 * 9473 + -1 * -15866], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[-9933 + 2350 * -2 + 14636]] : color), Render['GradientRect'](x, y + (-4512 + -8441 * -1 + -3919), width + (5102 + 21 * 197 + -9237), -960 * 5 + 1 * -7113 + 11918, -57 * -103 + 4931 + 1543 * -7, rainbowmenu ? [colors['r'] * (1 * -4963 + 1 * -2734 + 7697.75), colors['g'] * (-1492 + 1 * -5023 + 6515.75), colors['b'] * (-499 * -2 + -6429 + 5431.75), -1 * 4487 + 2 * 1187 + 2368] : [color[6421 + 774 + -7195] * (4163 * -1 + -9886 * -1 + -5722.25), color[-8554 + 3331 * -2 + -15217 * -1] * (8 * -1231 + 8777 + 1071.75), color[1 * -5534 + 8826 * 1 + -3290] * (6866 + 7 * -780 + -1405.25), 1 * -634 + -4750 + -5639 * -1], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[5926 + -1079 * 7 + -1 * -1630]] : color);
    var _1967618 = Render['AddFont']('Verdana', 8817 + -2 * 3502 + -129 * 14, -1 * -2281 + -2860 + 979);
    Render['Line'](x + (2864 + -6664 + 3803), y + height + (-7490 + -863 * 11 + 17033), x + (-8179 * -1 + -2399 * 2 + -2885 * 1), y + height + (9656 + 1 * -6676 + -2930), [-1427 * 1 + 1 * 7187 + -7 * 815, -1173 * -1 + -8267 + -73 * -98, -7164 + 7157 + 76, 9175 + -5926 + -998 * 3]), Render['StringCustom'](x + (8330 * 1 + 9591 * -1 + 1611), y + height + (-23 * -311 + -857 * 11 + 2329), -493 + -27 * 14 + 871, 'hold right-click for tooltips', [1 * 269 + 703 * 12 + -5 * 1690, -2138 + 37 * 154 + -1 * 3305, -2656 + -6530 + 1 * 9441, -1 * 3229 + -299 * 17 + 8567], _1967618), Render['StringCustom'](x + (827 * 1 + -2067 + -25 * -50), y + height + (-113 * -25 + 1488 + -4258), -3 * -2839 + -23 * -241 + 37 * -380, _2168747, [113 * 73 + 977 * 6 + -2 * 6928, -3938 + -8361 + -1 * -12554, 7 * 295 + 6422 + 49 * -168, -454 + -121 + 830 * 1], _1967618), bettercircle(x, y + (8864 + -8734 + -100), 8570 + -8458 + -79, rainbowmenu ? [colors['r'], colors['g'], colors['b'], -1 * 543 + -8126 + -92 * -97] : [color[9613 * 1 + -58 * -79 + -14195], color[-3 * 737 + 3638 + -1426], color[-113 * -73 + 2 * -979 + 1 * -6289], -3 * -267 + 78 * 82 + -6942]), bettercircle(x, y + (-4383 + -7382 + 11795), -4175 + -9525 + -4 * -3433, [687 * -1 + 5954 + -5222, -388 + -6781 * 1 + 7217, -1 * 5834 + -8868 + 14757, -4377 + 1 * 2550 + 2082]), Render['StringCustom'](x - (3 * -1908 + 3531 + -2209 * -1), y + (5058 * 1 + -7882 + -3 * -942), -33 * 301 + 4574 + 5359 * 1, _3640541, rainbowmenu ? [colors['r'], colors['g'], colors['b'], -237 * 7 + 6417 + 3 * -1501] : [color[-5378 + -4595 + 9973], color[453 + 54 * -26 + -4 * -238], color[8 * 925 + 788 * -12 + -7 * -294], 2 * -4867 + -9456 + 19445], _5397387);
}

function Dtab(_3270119, _2298014, _4212217) {
    var _5397324 = Render['AddFont']('Verdana', 1 * -1315 + -67 * -34 + -953, 122 * 70 + 4963 + -12703),
        _4254504 = -1467 + -9044 + 10711,
        _3812544 = -2 * 2449 + 5526 + -4 * 157,
        _3831196 = _2298014 + (-6 * -1567 + 2752 + -12149),
        _5409247 = Input['GetCursorPosition'](),
        _12579902 = _5409247[-7894 + -7854 + 15748],
        _13502350 = _5409247[-921 * 9 + 5330 + 2960],
        _5453482 = Render['TextSizeCustom'](_3270119, _5397324)[5689 * 1 + 11 * -21 + 2729 * -2] + (-5865 + 2591 * -1 + 8461 * 1),
        _1865313 = ![];
    return _12579902 > _2298014 && _12579902 < _2298014 + (5915 + -8227 + 2392) && _13502350 > _4212217 && _13502350 < _4212217 + (-21 * 444 + -9903 + 19242) ? (hovered = !![], _3812544 = _5453482 + (-5058 + -194 * -26 + -27 * -1), Render['FilledRect'](_2298014, _4212217, _3812544, -5900 + -9997 + 15912, [9687 + -1 * -6050 + -2 * 7841, 1 * -2677 + 2846 + -109, -58 * -83 + -9197 * 1 + 4452, -2270 + 931 * -1 + 3456]), Render['FilledRect'](_2298014 - (3850 + 9612 + 641 * -21), _4212217 + (9409 + -43 * -19 + -10225), _3812544 + (7922 + 9231 + -17151), -3626 * -1 + -258 * 5 + 101 * -23, [9 * 941 + 1 * 8421 + -7 * 2405, -3 * 3193 + -1 * -6455 + 3184, -5025 + -11 * -874 + 2260 * -2, 31 * -107 + 7445 + -3873]), Input['IsKeyPressed'](-2 * -3634 + 19 * 190 + -10877) && (_1865313 = !![])) : hovered = ![], Render['StringCustom'](_3831196 + (4176 + 7669 + -11842), _4212217 - (-1 * -963 + -39 * 241 + 8437), 4552 + -6200 + -1 * -1648, _3270119, [-41 * -103 + -37 + 3931 * -1, -8843 + 4182 + 1229 * 4, 7065 + 2130 + -2980 * 3, _4254504], _5397324), _1865313;
}
var keyCodes = [9823 + -2 * 1481 + -1 * 6796, 11 * -391 + 1541 * 2 + 1285, -9202 + -2769 + 12038, -1 * 7921 + -1 * 3331 + -11320 * -1, 97 * -75 + 13 * 317 + 3223 * 1, -4312 + -2178 + 6560, -4031 * -1 + -844 + -3116, 9353 + 9991 * 1 + -584 * 33, -2085 + 1 * -3031 + 5189 * 1, 3771 * 2 + 7100 + -2 * 7284, 9263 + 6261 + -2207 * 7, -1 * -5913 + -1345 * 1 + -4 * 1123, -1883 + -1044 * 2 + 4048, 9743 + 3877 * 2 + -17419 * 1, -3091 + 277 * 17 + -1539, 722 + 122 * -67 + 7532 * 1, 6051 + -52 * 174 + 3078, 7193 + 1637 * 4 + -3 * 4553, 1790 * 2 + 9611 + 58 * -226, 9411 + -6519 + -2808, 14 * -652 + -10 * -759 + 1623, 3316 + 7879 * 1 + -3703 * 3, -4311 + -1 * 3345 + -89 * -87, -20 * -131 + 293 * 29 + -11029, 2554 * 2 + -6626 + 1607 * 1, 1 * -6218 + 9067 + -2759, 5331 + 3596 + -8895],
    keyChar = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '_', '/'],
    globaltime = Globals['Realtime']();

function Dcheckbox(_8859967, _2497052, _5645599, _5722578, _1322584, _2818129) {
    var _2005757 = Input['GetCursorPosition'](),
        _1422390 = _2005757[454 + 2 * 4892 + -10238],
        _2719805 = _2005757[-9 * 1093 + 1845 + 7993 * 1],
        _2888561 = Render['AddFont']('Tahoma', -2733 + -6055 + 1759 * 5, -22 * -165 + -2351 + -1 * 579),
        _8347395 = Render['TextSizeCustom'](_8859967, _2888561)[5 * -460 + 4582 + -14 * 163];
    Render['Rect'](_2497052 - (1 * -2577 + -4307 * -2 + 14 * -431), _5645599 - (-617 * 9 + -1655 * 5 + 13830), 3899 + -27 * -1 + -559 * 7, 4 * -1758 + -6307 + 13352, [3302 * -1 + 6174 + 2797 * -1, 3918 + -3 * 162 + -3347, 2 * -4519 + 3098 * -3 + 5 * 3687, -6297 + 7069 + 47 * -11]);
    if (_1422390 > _2497052 && _1422390 < _2497052 + (7774 + -1974 + -5787) + (-9 * -403 + 2638 * 2 + -2966 * 3) + _8347395 && _2719805 > _5645599 && _2719805 < _5645599 + (-708 + -78 * 103 + 8752)) {
        Render['FilledRect'](_2497052 - (-4 * -212 + 1692 + -2532), _5645599 - (-251 * 15 + -4832 + 8600), -1490 + -2597 + 4282, -4705 + -2477 * 3 + -1 * -12151, [-4188 + -7462 + -11705 * -1, -6223 * 1 + 1 * -3494 + 9777, -2051 * -4 + 2867 * 3 + -16736, -1835 + -5381 * -1 + -3 * 1097]), Render['FilledRect'](_2497052 - (-6421 + 6415 + 15), _5645599 - (3462 + -5820 + 2360), 4 * -1158 + -1 * -2498 + 2331, -6826 + -124 + 6963, [-7603 + 8917 * -1 + -425 * -39, -7047 + 58 * -3 + 7281, 7751 + 2 * -3857 + -32 * -1, -1 * -2063 + -67 * 67 + -383 * -7]), Render['Rect'](_2497052 - (1642 * 2 + 477 + -3758), _5645599 - (-3595 + 832 + 553 * 5), 59 * 148 + 7361 + -16080, -3 * -1798 + -8 * 796 + 987, rainbowmenu ? [colors['r'], colors['g'], colors['b'], -2026 + 67 * 1 + 18 * 123] : [color[-1656 + -8004 + 9660], color[2487 + 7203 + 9689 * -1], color[528 + 9487 + -589 * 17], 206 * -41 + 2189 + -4 * -1628]);
        if (Input['IsKeyPressed'](-727 * 1 + -411 * -17 + -6259 * 1) && Globals['Realtime']() > globaltime + (-821 * -1 + -650 * -3 + -2770.8)) return globaltime = Globals['Realtime'](), !![];
    }
    _5722578 && Render['FilledRect'](_2497052 - (2 * -4891 + 9077 + 2 * 354), _5645599 - (-13 * -363 + 5556 + -1 * 10273), -6824 + -9058 + 15895, -1271 + -2489 + 3773, [2637 + 1 * -4206 + 1654, -331 * -7 + 1091 * 4 + -6584, -3279 + 1 * -6346 + -1624 * -6, -1919 + 3523 + -1349]);
    if (_1422390 > _2497052 && _1422390 < _2497052 + (-16 * 311 + -8359 + 13348) + (53 * -7 + 2801 + 5 * -485) + _8347395 && _2719805 > _5645599 && _2719805 < _5645599 + (1231 * -7 + -1448 + 10075) && _1322584 && Input['IsKeyPressed'](2122 + -2298 + 2 * 89)) {
        var _2420368 = Render['TextSizeCustom'](_2818129, _2888561)[1992 + -1578 + -414];
        Render['FilledRect'](_1422390 - _8347395 / (-4 * -1061 + -8596 + 311 * 14), _2719805 - (7519 + -3302 + -4197), _2420368 + (1 * -337 + 5840 + 7 * -785), -8181 + 7038 + 1155, [-119 * -59 + 34 * 126 + -11220, -3285 + -9377 * -1 + 109 * -55, -437 * 1 + 1613 * 3 + -4283, -135 * -52 + -3599 + 3166 * -1]), Render['FilledRect'](_1422390 - _8347395 / (5214 + 6285 + -11497) - (-4520 + -4048 + 779 * 11), _2719805 - (4306 + 7200 + -3829 * 3), _2420368 + (3833 + -1 * -9709 + -796 * 17), 1734 + -1496 + -228, [-5 * 503 + 8113 + -5513 * 1, 8632 + 8261 + -16796, -3967 * -2 + 4321 * 2 + 2351 * -7, -3282 + -6032 + -7 * -1367]), Render['StringCustom'](_1422390 - _8347395 / (9 * 323 + 6843 + -2437 * 4) + (33 * 33 + 3049 + 4133 * -1), _2719805 - (349 * -11 + -6923 + 10782), -1265 + -2 * -17 + 1 * 1231, _2818129, [-3 * 1429 + 5335 + 1 * -793, 1021 + -685 + 1 * -81, -906 * 11 + -7727 * 1 + 17948, 2401 * -1 + 841 + -171 * -10], _2888561);
    }
    _1422390 > _2497052 && _1422390 < _2497052 + (1 * 3223 + -268 * -4 + -1 * 4282) + (9 * -127 + 5328 + 2090 * -2) + _8347395 && _2719805 > _5645599 && _2719805 < _5645599 + (3777 + 1 * 254 + -4021) && Render['Rect'](_2497052 - (133 * 58 + 8322 + -16033), _5645599 - (-3 * 1397 + 202 * -1 + 879 * 5), -1 * 9725 + -6430 + 16168, -7952 + 1708 + 6257, rainbowmenu ? [colors['r'], colors['g'], colors['b'], 5932 + -1046 + -4631] : [color[-892 + 1 * 7062 + 5 * -1234], color[2308 + -4310 + 2003], color[7012 + -651 + -6359], 1 * 3549 + -4979 + 337 * 5]), Render['StringCustom'](_2497052 + (1404 + -2730 + 668 * 2) + (-1 * -8908 + 1 * -6145 + -2758), _5645599 - (1 * 3763 + -8827 + 5065), -9090 + -5604 + 14694, _8859967, [-4755 + 240 + 106 * 45, 24 + -10 * -254 + -2309, 541 + -223 + 7 * -9, 9 * -728 + -7328 * -1 + -626], _2888561);
}

function Dslider(_3888562, _4872477, _3786190, _4014583, _6013103, _5793999, _4943332) {
    var _4748519 = Input['GetCursorPosition'](),
        _4358470 = _4748519[-23 * 290 + -3643 + -1 * -10313],
        _5201589 = _4748519[-8239 * 1 + -8831 * -1 + -591],
        _5119297 = _4014583 * _6013103,
        _2943909 = Render['AddFont']('Tahoma', -159 * -27 + 8889 * 1 + -13175, -257 * 9 + -911 * -9 + -5186);
    _4358470 - (7379 * 1 + 6384 + -13678) > _4872477 - (-6354 + 7 * 133 + -339 * -16) && _4358470 - (2128 + 2069 * 2 + -6180) < _4872477 + (5556 + 2 * -2722 + -3 * 4) && _5201589 > _3786190 + (-6104 + -1 * -9521 + -3405) && _5201589 < _3786190 + (-454 * 19 + -9848 + 18486) + (1 * -4246 + -8887 + 13143) && (Input['IsKeyPressed'](-566 + -8025 + -1 * -8592) && (_4014583 = _4358470 - (213 * 7 + 1417 * 3 + -5657) - _4872477, _5119297 = _4014583 * _6013103));
    if (_4358470 > _4872477 - (5691 + 213 * 27 + -11441) && _4358470 - (573 + 2268 + 19 * -145) < _4872477 + (-170 * -2 + 3097 + 3337 * -1) && _5201589 > _3786190 + (9682 + 7 * 1049 + -1 * 17013) && _5201589 < _3786190 + (-1 * 2070 + -121 * -35 + 1 * -2153) + (-1401 + 6340 + -1643 * 3)) {
        if (_5119297 == -9620 + -1 * 9737 + 1 * 19357 && _5793999) indicateval = 'dynamic';
        else _4943332 ? indicateval = _5119297 + ' hp' : indicateval = _5119297 + '%';
        var _4806401 = Render['TextSizeCustom'](indicateval, _2943909)[-580 + -8837 + 73 * 129];
        Render['FilledRect'](_4358470 - _4806401 / (-937 + -7655 + 1 * 8594), _5201589 - (23 * 211 + 9963 + 1 * -14796), _4806401 + (1870 + 1907 * -4 + 5768 * 1), 308 * -28 + -499 * -17 + 153, [2642 + 1380 + -1 * 3937, -6544 + -4838 + -1 * -11479, 1311 * 2 + 2339 * 1 + -4842, 6501 + -2819 + 1 * -3427]), Render['FilledRect'](_4358470 - _4806401 / (-1161 + -86 * 38 + 4431) - (-713 * -5 + 43 * 50 + -5714), _5201589 - (-2031 * -1 + -6320 + 4308), _4806401 + (5232 + -125 * -11 + 1 * -6595), 5969 + -9605 + 3646, [381 + -4479 + 4183, -1 * -2357 + -2518 + -86 * -3, -1613 + 1 * 2053 + -321, 9832 + 91 + 2 * -4834]), Render['StringCustom'](_4358470 - _4806401 / (-269 + -1 * 5708 + 5979 * 1) + (14 * 335 + 1303 * 2 + -7291), _5201589 - (-8431 + 4569 + 3882), -5087 + -6181 + 11268, indicateval, [-6545 + 6214 + -1 * -586, 8538 + -1794 + -6489, -446 * 17 + 4969 * -2 + -1975 * -9, 1396 * 5 + -228 * -5 + 7970 * -1], _2943909);
    }
    return Render['FilledRect'](_4872477 + (-1443 + -5215 + 6741), _3786190 + (-2 * 859 + 169 * -38 + -8153 * -1), -14 * -524 + -29 * 10 + -6944, 1288 + -8797 + 1 * 7517, [8949 + -4457 * -1 + -13372, 8468 * 1 + -5232 + -3201, 1 * -1113 + 1 * 8484 + -1 * 7331, -2826 + -1646 + 163 * 29]), Render['FilledRect'](_4872477 + (-8 * 100 + 1286 + 2 * -202), _3786190 + (11 * -163 + 109 * 59 + -4624), 18 * 253 + -3727 * -1 + 221 * -37, -826 * -4 + -7353 + 4055, [7257 * 1 + 632 * -5 + -4063, -3259 + -7125 + 10419, -3347 + -2 * 4957 + 13301, 4414 + -8774 + 65 * 71]), _4014583 != -8210 + -5311 + -3 * -4507 && (Render['GradientRect'](_4872477 + (4263 + 1 * 1223 + -5402), _3786190 + (-9887 * 1 + 8326 + 1575), _4014583, 4 * 1823 + 43 * -39 + 79 * -71, -5760 + 3698 * -1 + 9459, rainbowmenu ? [colors['r'] * (-4100 + 4 * 1471 + -1783.25), colors['g'] * (-163 * -49 + -2885 + -5101.25), colors['b'] * (7669 + 2865 + -10533.25), -40 * -55 + -3 * -1255 + 5 * -1142] : [color[4285 + 4 * 2477 + -747 * 19] * (2974 + 1 * -9415 + 6441.75), color[-1 * 4058 + -2162 * -3 + -2427] * (2314 + -5154 + 2840.75), color[5587 + -829 * -11 + -8 * 1838] * (-1569 + -29 * 199 + 7340.75), -2084 + -2826 + 5165], rainbowmenu ? [colors['r'], colors['g'], colors['b'], 1231 + 2285 + -3261] : color), Render['GradientRect'](_4872477 + (-43 * 47 + 1 * 6082 + 17 * -234), _3786190 + (1 * 8966 + -4553 + -4398), _4014583 + (-9 + -8708 + 8719), -2 * -1890 + 509 + -4285, -8677 + 6343 + 2335, rainbowmenu ? [colors['r'] * (-317 * 5 + 746 * 7 + -3636.25), colors['g'] * (-95 * 70 + -1007 * 1 + 7657.75), colors['b'] * (-2834 * -1 + -6621 + 3787.75), -128 * 63 + 66 * 1 + -1 * -8253] : [color[195 * -1 + 5332 + -1 * 5137] * (6737 + -1 * 8698 + 1961.75), color[-1630 * -3 + 3428 + -8317] * (1261 + -382 * 9 + 2177.75), color[2754 + 1 * -3290 + 538] * (-362 * -26 + -1 * -7575 + -16986.25), 1 * 2372 + 5320 + 111 * -67], rainbowmenu ? [colors['r'], colors['g'], colors['b'], 73 * -53 + 2908 + 1216] : color)), Render['StringCustom'](_4872477, _3786190 + (-6048 + -1 * -257 + 5803), -4491 + 6324 + 1 * -1833, _3888562, [-6247 * -1 + -5366 + -626, 754 * 3 + 2857 + 4864 * -1, 83 * -45 + -2400 + 639 * 10, 502 * 3 + 551 + -1907], _2943909), _4014583;
}

function Dcategory(_97523, _4346298, _5172962, _13500260, _16497106) {
    x = _97523, y = _4346298, width = _5172962, height = _13500260;
    var _5296508 = Render['AddFont']('Verdana', 7 * 1158 + -6236 + -14 * 133, -6271 * -1 + -3039 + 329 * -8);
    Render['FilledRect'](x, y, width, height, [5 * 1200 + 9495 + -15444, -1991 * -1 + 7747 + 12 * -807, -2026 * -1 + 10 * 11 + -2073, -55 * 127 + -209 + 7449]), Render['FilledRect'](x - (-2 * -1822 + -8 * -1219 + 5 * -2679), y + (-6562 + 553 * 5 + 3798 * 1), width + (68 + -34 * -249 + -1422 * 6), height - (-1002 * -6 + 2864 + -8874), [5019 + -3888 + -360 * 3, -87 + 3369 + -3228, 9944 + -3836 + -6045, -3268 + -3848 + 7371]), Render['StringCustom'](x + (-88 * -71 + -1348 + -1 * 4897), y - (599 + -8364 + -3890 * -2), 7728 + -1 * 2947 + 1 * -4781, _16497106, !rainbowmenu ? [color[8586 + -1618 + -1742 * 4], color[127 * 7 + -4392 + 3504], color[5607 + -2500 + 115 * -27], -5322 + 576 + 5001] : [colors['r'], colors['g'], colors['b'], 7474 + -1943 + -5276], _5296508), Render['GradientRect'](x, y, width, -3539 + -259 + 3803 * 1, 1 * 5465 + -1 * -8893 + -14357, rainbowmenu ? [colors['r'] * (-529 * 11 + 1 * 773 + 5046.75), colors['g'] * (5717 + -8710 + 2993.75), colors['b'] * (6211 * -1 + -1668 + 7879.75), -6612 + -5 * -99 + 6372] : [color[1 * -2866 + 1799 + 1067] * (-5676 + -2088 + 7764.75), color[8 * 694 + 821 * 10 + -3 * 4587] * (-9592 + 209 * -28 + 15444.75), color[-83 * 89 + -7364 + -1 * -14753] * (2856 * 1 + -7560 + 4704.75), 8860 + -1029 + -8 * 947], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[6025 + 7484 + -2251 * 6]] : color), Render['GradientRect'](x - (1 * 3779 + 5836 + -23 * 418), y + (9236 + -522 * -18 + -31 * 601), width + (-3299 + 8147 + 4846 * -1), -9884 + 325 + 1366 * 7, 9040 + -6036 + -7 * 429, rainbowmenu ? [colors['r'] * (1820 + 7546 + -9365.25), colors['g'] * (-11 * 384 + -115 * -73 + -4170.25), colors['b'] * (6614 + 7639 + -14252.25), -3583 + 3337 + 501] : [color[1 * 8642 + -4673 + -3969] * (7750 + -7514 * 1 + -235.25), color[-33 * 191 + -14 * -581 + 305 * -6] * (-1 * 1004 + -3798 * 1 + 4802.75), color[-1 * -1949 + -383 * 15 + 3798] * (181 * 1 + -6893 + 6712.75), -35 * -103 + 1117 + -4467 * 1], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[-4 * -263 + -1 * -7945 + -4497 * 2]] : color);
}

function Ddropdown(_3972168, _3937010, _3425573, _3166366, _3923055, _4253763) {
    var _3175130 = Input['GetCursorPosition'](),
        _1369428 = _3175130[9984 + 1067 * -2 + -7850],
        _6190636 = _3175130[-15 * 118 + 4215 * -1 + 73 * 82],
        _3021367 = _4253763,
        _5672322 = -1 * 4445 + -7112 + 1 * 11657,
        _3942657 = Render['AddFont']('Tahoma', -2698 * -2 + 5931 * 1 + -11320, -9258 + 8560 + 1598),
        _5856974 = -1 * 4523 + -6067 * 1 + 10 * 1059,
        _1483665 = Render['TextSizeCustom']('' + _3021367, _3942657);
    Render['Rect'](_3937010 + (4614 + -475 + 1 * -4058), _3425573 - (1 * 1561 + 119 * 32 + -671 * 8), 5205 + 47 * 138 + -11588, -5390 + -2524 + 7936, [56 + -22 * 101 + -1 * -2241, -5100 + 5603 + 209 * -2, -14 * 488 + 1 * 1223 + -476 * -12, -1193 * 1 + 1 * -7549 + 8997]), Render['Rect'](_3937010 + (-2876 + 1 * -8821 + -11777 * -1), _3425573, 4 * 611 + -7793 + 54 * 101, -29 * -239 + 13 * 398 + -12085, [-2102 * -2 + -8936 + 1 * 4807, -761 + 1 * 2581 + 1 * -1735, 8758 * -1 + 2267 + 6594, -2 * -1232 + -1462 * 6 + 6563 * 1]);
    if (_1369428 > _3937010 && _1369428 < _3937010 + (47 * -109 + 12 * -383 + 9904) && _6190636 > _3425573 && _6190636 < _3425573 + (7004 + -5818 * 1 + -168 * 7) + _1483665[-1829 * 3 + -2 * 2777 + 11042]) {
        Render['Rect'](_3937010 + (-47 * 71 + 1 * -2666 + -9 * -676), _3425573 - (1688 * -2 + 7489 + -2056 * 2), -59 * -164 + 26 + -9599, -2 * -2043 + -29 * -219 + -2083 * 5, [color[3804 + -2 * -33 + 18 * -215], color[696 + -1070 + 375], color[-8657 * -1 + 1 * -5590 + -5 * 613], -843 + -6764 + 7862]), Render['Rect'](_3937010 + (7303 + -355 * 15 + -1898), _3425573, -1589 * 2 + 4 * -526 + 5387, -5 * 343 + 1 * 9965 + -8230, [color[211 * 16 + -5410 + 2034], color[5366 + -5488 + 3 * 41], color[59 * 101 + 4682 + -1 * 10639], -270 * 34 + 5037 + -2 * -2199]);
        if (Input['IsKeyPressed'](-3187 * 1 + 25 * -43 + 29 * 147) && Globals['Realtime']() > globaltime + (9805 + -2406 + -7398.8)) return globaltime = Globals['Realtime'](), 'closed';
    }
    Render['FilledRect'](_3937010 + (-9319 + -1 * 1378 + -3 * -3593), _3425573, 1346 * -5 + -4929 + -8 * -1470, 2 * -217 + -5552 + 6006, [-8678 + -9241 + -178 * -101, 1 * 219 + 2933 * 2 + 3011 * -2, 6352 + -3186 + -13 * 238, -623 + -1 * 9522 + 10400]), Render['FilledRect'](_3937010 + (1 * -2586 + 4335 + -1668), _3425573 + (-3248 * -1 + -6105 + -2858 * -1), 6396 + 4132 * 1 + -2085 * 5, 31 * 81 + -1961 * -2 + -6415, [6162 + 5235 * -1 + 1 * -868, 6720 + -1231 + 2 * -2713, 1 * -1254 + 186 + 570 * 2, -3909 + 3110 + 1054]), Render['StringCustom'](_3937010 + (-1618 + 9907 + -1640 * 5), _3425573 + (-2374 * -2 + -6339 + 1595), -1 * -6921 + 2174 + 17 * -535, '' + _3021367, [4382 + 2816 + -6943, 4650 + 1 * 7534 + -11929, 7911 + 2 * -2476 + -2704, -1171 * 1 + -6131 * 1 + 7452], _3942657), Render['StringCustom'](_3937010, _3425573 + (-6153 + -4743 + 10900), 199 * 39 + -5944 + -23 * 79, _3972168, [3471 + 3712 + -16 * 433, 1 * -9989 + -2966 + 13210, -7079 * -1 + 5699 + -1789 * 7, 107 * 48 + -7729 + 13 * 211], _3942657);
    if (_3923055) {
        for (i = -1 * 251 + -9517 + 9768; i < _3166366['length']; i++) {
            var _3955356 = Render['TextSizeCustom'](_3166366[i], _3942657);
            _5856974 += _3955356[-41 * 167 + -3335 + 10183], Render['FilledRect'](_3937010 + (5405 + -8666 + 3343), -2122 * 1 + 7 * -111 + 2923 + _3425573 + i * (-9265 + -9801 + 19079), -3486 + 4 * 1789 + -3569, _3955356[4493 * -2 + -9448 + 18435] + (8885 + -4 * 2133 + 27 * -13), [-7404 + 9965 + -2502, -3 * 1382 + -5640 + 7 * 1407, 761 * 5 + -4458 + 725, 1163 + 6433 + -1 * 7341]);
            if (_1369428 - (8263 * -1 + -2069 + -21 * -496) > _3937010 && _1369428 - (43 * -173 + -1867 + 2 * 4703) < _3937010 + (4760 + 1 * -18 + -4656) && _6190636 > -4133 * -1 + -9 * 653 + 9 * 197 + _3425573 + i * (3659 + -46 * 89 + 448) && _6190636 < 1921 * -4 + -2440 * 1 + 10156 + _3425573 + i * (-2420 + 8859 + -6426) + _3955356[2144 + -1405 + -738]) {
                Render['FilledRect'](_3937010 + (-1 * 353 + -2929 + 3364), 4957 * 1 + 3235 + -8166 + _3425573 + i * (52 * 26 + -5 * 671 + 2016), -73 * 31 + -9479 * 1 + 11843, _3955356[170 * -3 + -1 * 6703 + -1 * -7214] + (-1 * -6949 + -119 * 67 + 1026), [-9770 + 9503 + -156 * -2, -7881 + 8064 + -136, 5435 + 3349 + -8724, 2 * -2274 + -1 * -1990 + 2813]), Render['StringCustom'](_3937010 + (-8324 + 5684 + 1 * 2729), -5350 + 4997 + 379 * 1 + _3425573 + i * (-506 + -1322 * 2 + 1 * 3163), 2863 + -623 + -32 * 70, _3166366[i], [color[375 * -26 + 9442 + 154 * 2], color[343 + 517 + 859 * -1], color[-1 * 2033 + 6102 + 1 * -4067], 377 * 8 + 3 * 892 + -5437], _3942657);
                if (Input['IsKeyPressed'](-6469 + 8325 + -371 * 5)) return _5672322 = i, _5672322;
            }
            Render['StringCustom'](_3937010 + (161 * 47 + -3231 + 4247 * -1), 5205 + -22 + 191 * -27 + _3425573 + i * (-2482 + 1793 + 117 * 6), 1071 + -4 * 874 + 2425, _3166366[i], [-9564 + 9 * -3 + -4923 * -2, -7697 + 22 * -80 + 607 * 16, -1 * -4669 + 3346 + -8 * 970, 3115 * 1 + -1 * -4717 + 334 * -23], _3942657);
        }
        if (Input['IsKeyPressed'](-343 * 25 + -283 * 19 + 3 * 4651) && Globals['Realtime']() > globaltime + (4770 + 7525 + -12294.8)) return globaltime = Globals['Realtime'](), 'closed';
        Render['Rect'](_3937010 + (857 * -1 + 9844 + -8905), _3425573 + (-704 * 14 + 5 * 415 + 7805), 101 + -2741 * -3 + -8223, _5856974 + _3166366['length'] * (6123 + 9745 * -1 + 1 * 3625) - (-6629 + -2 * 2677 + 11986 * 1), [-643 + 347 + 371, -2 * 4513 + -1742 * -2 + 1 * 5627, 3071 + -1429 * 1 + -1539, 288 * 4 + -111 * -19 + 3006 * -1]);
    }
}

function Dtextbox(_1398565, _2602559, _6181399, _1893258, _6137965) {
    const _4712658 = Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((8250 + -228 * -22 + 7 * -1895) / (-3889 * -1 + 2102 + -5990.5)) % (Math['PI'] * (8753 + 4818 + 1 * -13569)))) * (-281 * 19 + 4919 + 75 * 9);
    lmao = '';
    var _2211915 = Input['GetCursorPosition'](),
        _4277328 = _2211915[-6 * -710 + -2910 + -1350],
        _2451430 = _2211915[-3650 + 872 * 10 + -5069],
        _2015062 = Render['AddFont']('Tahoma', 6398 + 365 + -6756, 2050 + 43 * 77 + -4461),
        _6203983 = '';
    Render['Rect'](_2602559 + (6997 + -8781 + 1855), _6181399 - (-501 * 1 + -2 * -397 + -292), -20 + 2948 + -2815, -1694 * -4 + -2 * -4093 + -14940, [-4405 + 6215 + -1735, -103 * -6 + -2978 * 1 + 2445, 1 * -6988 + 9506 + 3 * -805, -10 * -454 + 2207 + -3 * 2164]), Render['Rect'](_2602559 + (7044 + 439 * 14 + -13120), _6181399, -3257 + -2989 + -6361 * -1, 715 + -1 * -1508 + -2203, [-15 * -575 + 2700 + -11250, 709 * -11 + -1547 + 9431, -3858 + 1 * 7343 + 1691 * -2, 3018 + 1 * 9491 + 1114 * -11]);
    var _2736466 = 'effects/';
    if (_1893258['length'] == 2869 + -2 * -4789 + -12437 * 1) _2736466 = 'ffects/';
    else {
        if (_1893258['length'] == -9668 + -9538 + 19217) _2736466 = 'fects/';
        else {
            if (_1893258['length'] == -1574 + -2 * 1823 + 109 * 48) _2736466 = 'ects/';
            else {
                if (_1893258['length'] == -233 * -6 + 1 * -3156 + 1771 * 1) _2736466 = 'cts/';
                else {
                    if (_1893258['length'] == -1119 * 3 + 3 * -1431 + 8 * 958) _2736466 = 'ts/';
                    else {
                        if (_1893258['length'] == -1 * 6509 + -7 * -349 + 4081) _2736466 = 's/';
                        else {
                            if (_1893258['length'] == -4 * 751 + 6920 + -325 * 12) _2736466 = '/';
                            else _1893258['length'] == 3451 + 8423 + -11857 && (_2736466 = '');
                        }
                    }
                }
            }
        }
    }
    if (_4277328 > _2602559 && _4277328 < _2602559 + (531 * -6 + 991 + -474 * -5) && _2451430 > _6181399 && _2451430 < _6181399 + (-5392 + 1 * 79 + 5325) + (-157 * 5 + 4 * 2063 + -7450)) {
        _4712658 > 1 * 956 + 9732 + -10561 ? lmao = '|' : lmao = '';
        Render['Rect'](_2602559 + (1567 * 1 + -1 * 3853 + 2357), _6181399 - (3052 + -5954 + -2903 * -1), -4258 * 1 + 41 * -1 + 4 * 1103, 1220 + -23 * 281 + 351 * 15, [color[5 * -707 + 275 * -1 + -1905 * -2], color[-5657 + 4 * 139 + 2551 * 2], color[-3257 + 5964 + -2705], -25 * 66 + 3169 + -1264]), Render['Rect'](_2602559 + (-1 * 7325 + -8 * 720 + 13155), _6181399, 699 + 2 * -3961 + 7338, -5749 + 710 + 5059, [color[-2779 * -1 + 33 * -51 + -1096], color[-2054 + 9146 + 1013 * -7], color[-2248 * 1 + 7331 + 5081 * -1], -5645 + 99 * -61 + -11939 * -1]);
        if (_1893258['length'] < -7509 + -8 * 354 + 10358)
            for (i = 3 * 3246 + 2 * 2283 + -14304; i < keyCodes['length']; i++) {
                Input['IsKeyPressed'](keyCodes[i]) && Globals['Realtime']() > globaltime + (-7337 + 555 * 17 + -2097.91) && (globaltime = Globals['Realtime'](), _1893258 += keyChar[i]), Input['IsKeyPressed'](3 * 2068 + 277 * -1 + 3 * -1970) && Input['IsKeyPressed'](2111 + 2224 * 3 + -8775) && Globals['Realtime']() > globaltime + (5 * 1011 + 5840 + -10894.91) && (globaltime = Globals['Realtime'](), _1893258 = _1893258['substring'](5867 + -9332 + 3465, _1893258['length'] - _1893258['length']));
            }
        Input['IsKeyPressed'](-8828 + -5 * -1318 + 2246) && Globals['Realtime']() > globaltime + (-3044 + 4371 + -1326.91) && (globaltime = Globals['Realtime'](), _1893258 = _1893258['substring'](-1 * -4093 + -31 * -113 + -7596, _1893258['length'] - (-8546 + -4590 + 13137)));
    }
    return _6137965 ? _6203983 = _2736466 + _1893258 : _6203983 = _1893258, Render['FilledRect'](_2602559 + (2 * -3668 + -9735 + 17143), _6181399, 1282 * -2 + 9511 + -1 * 6836, 3673 * -1 + -9175 + 12868, [-893 + 5615 + -4663 * 1, -2509 + -1696 + 4268, -9835 + 279 * 33 + 700, 8843 + 7563 + -16151]), Render['FilledRect'](_2602559 + (8896 + 856 * -7 + 2833 * -1), _6181399 + (-9785 + 4 * -725 + 12686), 1546 + 4538 + -7 * 853, -2632 + -12 * -284 + -758, [-7055 + -2712 + -4913 * -2, -367 * 19 + -28 * -73 + -8 * -624, 8253 + 4660 + 12841 * -1, -221 + 9302 * -1 + 9778]), Render['StringCustom'](_2602559 + (5611 * 1 + -4 * -1637 + -12080), _6181399 + (43 * 214 + -7 * -323 + 11459 * -1), 9700 + -1 * 9448 + -252, _6203983 + lmao, [-5266 + 2 * 4759 + -3997, -1491 + 8352 + -3303 * 2, 9935 + 1504 + 233 * -48, -4292 + -1 * 127 + 3 * 1523], _2015062), Render['StringCustom'](_2602559, _6181399 + (1716 + -9478 + 7766), 4087 * 1 + 7 * -703 + 834, _1398565, [-1 * -6485 + -136 * -18 + 2 * -4339, 6620 + 3939 + -10304, -9727 + 5595 + 4387, -409 * 15 + 79 * -73 + 12052], _2015062), _1893258;
}

function cleartabs() {
    aimbottab = ![], antiaimtab = ![], visualstab = ![], misctab = ![];
}
var first = !![],
    firstspec = !![],
    firstkey = !![];

function moveElement(_2836610, _5415265, _1801469) {
    cursor_pos = Global['GetCursorPosition']();
    if (Input['IsKeyPressed'](1 * 2201 + -1 * 1315 + -885) && cursor_pos[3430 * -1 + -9656 + -9 * -1454] > _2836610[2893 * -1 + -1657 + 4550] - (6425 + -1092 + -5328) && cursor_pos[-926 * 3 + 28 + 2750] < _2836610[-5433 + -9674 * 1 + 15107] + _5415265 + (-2121 + -2699 + -1 * -4825) && cursor_pos[-1748 * 1 + 467 + 1282] > _2836610[4937 * -2 + 9720 + 155] - (740 + -5792 + -389 * -13) && cursor_pos[-4447 + -8338 * -1 + -3890] < _2836610[-8413 + -472 * 7 + -1953 * -6] + _1801469) return first && (difference = [cursor_pos[-1471 + -306 + 1777] - _2836610[1 * 8401 + 6334 + 2947 * -5], cursor_pos[136 * -50 + 3201 * 1 + 3600] - _2836610[-181 * 22 + 2378 * 3 + -137 * 23]], first = ![]), [cursor_pos[5279 + -2025 * -2 + -9329] - difference[-5 * -1349 + 7836 + -14581], cursor_pos[8363 + -651 * 1 + -1 * 7711] - difference[868 * 4 + -2006 + -1465]];
    else {
        if (!first && Input['IsKeyPressed'](645 + 3672 + -4316)) return [cursor_pos[1 * 681 + -1 * 5107 + 2 * 2213] - difference[9286 * -1 + -1 * 784 + -106 * -95], cursor_pos[2 * 4754 + -2579 + -3464 * 2] - difference[9880 + -5452 * 1 + -19 * 233]];
        else return first = !![], _2836610;
    }
}

function moveElementspec(_3938078, _2701341, _8955331) {
    cursor_pos = Global['GetCursorPosition']();
    if (Input['IsKeyPressed'](-1954 + 1507 + 64 * 7) && cursor_pos[-3392 + 6902 + -18 * 195] > _3938078[4971 + 9116 + -14087] - (9007 + 149 * -43 + -2595) && cursor_pos[8932 + -4512 * -1 + -13444 * 1] < _3938078[7697 + 1114 + -8811] + _2701341 + (-22 * 33 + -1 * 3159 + 1 * 3890) && cursor_pos[9202 + -4889 * 1 + -4312] > _3938078[131 * 24 + -1202 * -2 + -5547] - (533 + -7219 + 6691) && cursor_pos[2 * 2245 + 9 * -562 + 569 * 1] < _3938078[-101 * 52 + -5665 + 10918] + _8955331) return firstspec && (difference = [cursor_pos[-2 * -1308 + -2099 * 4 + 5780] - _3938078[-6785 + 7790 + -1005], cursor_pos[113 * -62 + -420 + -1 * -7427] - _3938078[-5214 + -10 * -509 + -5 * -25]], firstspec = ![]), [cursor_pos[-2 * 1405 + 196 * 8 + 1242] - difference[-1017 + -1 * 1294 + 2311], cursor_pos[-3126 * -3 + 1 * -1303 + 2 * -4037] - difference[-1 * -4317 + -2582 + 17 * -102]];
    else {
        if (!firstspec && Input['IsKeyPressed'](-49 * 4 + -1327 * -5 + -6438)) return [cursor_pos[9460 + 563 * -17 + 37 * 3] - difference[-1 * -6423 + 8 * -524 + -2231], cursor_pos[26 * -303 + -1 * -9833 + -1954] - difference[-1221 + 2364 + -1142]];
        else return firstspec = !![], _3938078;
    }
}

function moveElementkey(_15191392, _6191075, _5393860) {
    cursor_pos = Global['GetCursorPosition']();
    if (Input['IsKeyPressed'](-5 * 1373 + -6887 + 13753) && cursor_pos[9043 + 9791 * -1 + 748] > _15191392[-43 * -22 + -1 * -6819 + 1 * -7765] - (283 * 19 + 11 * -515 + 1 * 293) && cursor_pos[2438 + 2 * -2468 + 2498] < _15191392[1623 + -2 * -1772 + 1 * -5167] + _6191075 + (6164 + -462 + 27 * -211) && cursor_pos[-5623 + -1 * 1795 + 7419] > _15191392[9845 + 10 * -120 + -2 * 4322] - (-497 * -10 + 7697 + -12662) && cursor_pos[-1700 + 8388 + -6687] < _15191392[482 * 1 + -1 * -6691 + -1793 * 4] + _5393860) return firstkey && (difference = [cursor_pos[-3657 + -9 * 64 + 4233] - _15191392[4177 * -1 + 380 * -26 + -14057 * -1], cursor_pos[3938 + -1 * 9805 + 5868] - _15191392[-613 * 10 + -4669 * 1 + 10800]], firstkey = ![]), [cursor_pos[7555 * -1 + -6560 + -4705 * -3] - difference[97 * -55 + 8407 + -3072], cursor_pos[5648 + -419 * 7 + -1 * 2714] - difference[5 * 709 + -3 * 22 + 1739 * -2]];
    else {
        if (!firstkey && Input['IsKeyPressed'](-58 * 29 + 4 * -1880 + 9203)) return [cursor_pos[2087 * 1 + 7355 + 1 * -9442] - difference[-1556 * 6 + -9088 + -56 * -329], cursor_pos[8407 + -2 * -4178 + 17 * -986] - difference[-2 * 1 + -312 + -1 * -315]];
        else return firstkey = !![], _15191392;
    }
}
var textboxstring = 'cube_white',
    base = 'vgui/white';

function MenuRender() {
    if (!yes) return;
    UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'improveddtcheck', improveddt), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'lethaldtcheck', lethaldt), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'safeawpcheck', safeawp), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'safelimbcheck', safelimb), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'dtbaimcheck', dtbaim), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'mindmgcheck', mindmg), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'awpcheck', awpautobuy), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'nameespcheck', nameesp), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'weaponiconscheck', weaponicons), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'hitmarkerscheck', hitmarkers), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'legacykillcheck', legacykill), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'transparentnadecheck', transparentnade), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'customchamcheck', customcham), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'speclistcheck', speclist), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'keybindlistcheck', keybindlist), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'grenadecirclescheck', grenadecircles), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'manualaacheck', manualaa), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'legitaacheck', legitaa), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'AA mode', chosenoption), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'manualmodes', chosenthing), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'customchampreset', preset), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'adaptiveflagcheck', adaptiveflag), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'fakelagcheck', fakelagspam), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'disableflagcheck', disableflag), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'fakeduckcheck', fakeduck), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'speedcheck', speedupfd), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'watermarkcheck', watermark), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'clantagzcheck', clantagz), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'hitlogcheck', hitlog), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'tponpeekcheck', tponpeek), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'autopeekcheck', autopeek), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'r8hccheck', r8hc), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'fastduckcheck', fastduck), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'rainbowlinecheck', rainbowline), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'rainbowmenucheck', rainbowmenu), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'underglowcheck', underglow), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'killsaycheck', killsay), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'pulsatecheck', pulsate), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'Animated Indicators', animatedindicators), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'fakeamountcheck', fakeamount), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'Static color', staticcolor), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'Minimum damage', mindmgslider), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'Blend amount', blendslider), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'Hitchance', r8slider), pos = moveElement(pos, -4930 + -148 + 5578, -458 * 8 + -3798 + -4 * -1873);
    var _1844519 = pos[3 * 2554 + -6303 * -1 + 4655 * -3] + (1405 * -5 + -8269 + 1 * 15337),
        _1603949 = pos[-11 * -153 + -1963 + 281] + (8199 + -2167 * -3 + -14590 * 1);
    if (UI['IsMenuOpen']()) {
        Dmenu('D', pos[5612 + 4 * -1660 + 1 * 1028], pos[-6513 + 9764 + 65 * -50], -9292 * -1 + 5996 + -4 * 3647, 9 * 395 + -5487 * -1 + -8742);
        Dtab('Aimbot', pos[-39 * -135 + -4664 + 601 * -1] + (-8132 + 41 * -107 + 12579), pos[-1 * -5 + -3 * 401 + 1199] + (-1583 * -5 + 1 * -6185 + -1 * 1700)) && (cleartabs(), aimbottab = !![]);
        Dtab('Anti-aim', pos[1641 * 4 + -7048 + -11 * -44] + (2244 + 3 * 661 + -1 * 4057), pos[39 * -43 + -802 + 2480] + (-13 * -90 + 9348 + -10488)) && (cleartabs(), antiaimtab = !![]);
        Dtab('Visuals', pos[-1 * 7631 + -913 + 16 * 534] + (1255 + -4 * -833 + 4297 * -1), pos[-2307 * 1 + -1891 + 4199] + (7415 + -6719 + 111 * -6)) && (cleartabs(), visualstab = !![]);
        Dtab('Misc', pos[9657 + -1 * 1379 + 4139 * -2] + (-1 * -6674 + 1 * -7582 + 327 * 4), pos[1 * -7327 + -5481 + 12809] + (2 * 616 + -1 * 3719 + 2517)) && (cleartabs(), misctab = !![]);
        if (aimbottab) {
            mindmg ? Dcategory(_1844519 - (971 * 1 + 4 * 797 + 4149 * -1), _1603949 - (-423 * -7 + -111 * -73 + -11049), -1364 * -7 + -41 * -137 + -14965, -1 * 1238 + -1009 + 2307, 'Aimbot') : Dcategory(_1844519 - (-2202 + -1061 + 3273), _1603949 - (4398 + -52 * 79 + -25 * 11), 6896 + 1 * -3899 + -2797, -2269 * 4 + -2754 + 11875, 'Aimbot');
            r8hc && mindmg ? Dcategory(_1844519 - (-6610 * -1 + 3647 + -10247), _1603949 - (3544 * -1 + 5087 + -8 * 191), -35 * 149 + 180 + 5235, 187 * -33 + 9733 * 1 + 1741 * -2, 'Aimbot') : Dcategory(_1844519 - (7652 + 4049 + 27 * -433), _1603949 - (4988 + 8879 + -4 * 3463), 2 * 1977 + -2520 + 1 * -1234, 6373 + 1873 * -2 + -2582, 'Aimbot');
            r8hc ? Dcategory(_1844519 - (-1 * -2393 + 5333 + 6 * -1286), _1603949 - (-7572 + 8715 + 1 * -1128), 2679 * -1 + 774 * 12 + -6409, 1 * -6297 + -4035 + 10397 * 1, 'Aimbot') : Dcategory(_1844519 - (-1 * 4693 + 22 * 349 + -25 * 119), _1603949 - (-6230 + 101 * 84 + 2239 * -1), 9047 + -4457 + 10 * -439, 1441 + 3 * 2214 + -8038, 'Aimbot');
            Dcategory(_1844519 + (-3512 + -3 * 1244 + 7464), _1603949 - (7 * 481 + -1 * -8731 + -12083), -3593 + -4586 + -49 * -171, 6486 + 4 * -1877 + -1 * -1082, 'Doubletap'), Dcategory(_1844519 + (1056 + -1 * 4353 + 3517), _1603949 + (510 + -20 * -1 + -93 * 5), 15 * 390 + 2906 + 12 * -713, -8611 + 1 * -8860 + 8758 * 2, 'Target safety');
            if (Dcheckbox('Revolver hitchance in air', _1844519, _1603949, r8hc)) r8hc = !r8hc;
            if (r8hc) {
                r8slider = Dslider('Hitchance', _1844519, _1603949 + (-861 + 55 * 43 + -1 * 1499), r8slider, -1 * -3748 + 6176 + -9923);
                var _7865191 = pos[4486 * -2 + 5868 + -207 * -15] + (-5722 + 1 * -9457 + 15309);
            } else var _7865191 = pos[-29 * -307 + -2194 * 3 + -2320] + (-15 * 10 + 1 * 1281 + -1021);
            if (Dcheckbox('Minimum damage override', _1844519, _7865191 + (3770 + -1 * 9599 + 974 * 6), mindmg, !![], 'Overrides minimum damage')) mindmg = !mindmg;
            mindmg && (mindmgslider = Dslider('Damage', _1844519, _7865191 + (79 * -68 + 2527 + 2865), mindmgslider, -1544 + -1371 + 2916, !![], !![]));
            if (Dcheckbox('Improved Doubletap', _1844519 + (-1753 * -1 + -723 + 800 * -1), _1603949, improveddt, !![], 'Speeds up doubletap')) improveddt = !improveddt;
            if (Dcheckbox('Ensure Lethal Doubletap', _1844519 + (6619 * 1 + 5993 * 1 + 6191 * -2), _1603949 + (-6946 + 9387 + -2426), lethaldt, !![], 'HP / 2 while doubletap is active')) lethaldt = !lethaldt;
            if (Dcheckbox('Force Doubletap baim', _1844519 + (-45 * 119 + -1 * -7418 + -1833), _1603949 + (3641 * 1 + 631 * -3 + 859 * -2), dtbaim, !![], 'Prefers body while doubletapping')) dtbaim = !dtbaim;
            if (Dcheckbox('Force safe point on awp', _1844519 + (2704 + -80 + 114 * -21), _1603949 + (-1811 * 1 + -180 + 2071), safeawp)) safeawp = !safeawp;
            if (Dcheckbox('Force safe point on limbs', _1844519 + (33 * 210 + 44 * -23 + 237 * -24), _1603949 + (1595 + -7534 * -1 + -1 * 9034), safelimb)) safelimb = !safelimb;
        }
        if (antiaimtab) {
            fakeduck ? (Dcategory(_1844519 - (-5306 + -7705 + 13021), _1603949 - (6 * -947 + 264 + -3 * -1811), 1 * -4723 + -3083 * 3 + -2 * -7086, 4841 + 109 * 77 + -13134, 'Zona Anti-aim'), _1913200 = pos[4914 + 1 * 1579 + -12 * 541] + (2801 + -9 * 318 + 1 * 186)) : (Dcategory(_1844519 - (3233 + -5412 + 2189), _1603949 - (83 * -29 + 1 * 5303 + -67 * 43), -763 * 4 + 5868 + 3 * -872, -4063 * 1 + 2379 + 1769, 'Zona Anti-aim'), _1913200 = pos[-8946 + -26 * -114 + 5983] + (3 * 1282 + 1 * -166 + 105 * -34));
            Dcategory(_1844519 + (-5243 + -8518 + 13981), _1603949 - (-6654 + -1594 + 8263), 40 * 103 + -8567 + -4647 * -1, 11 * -841 + 1 * 7234 + 2077, 'Fakelag');
            if (Dcheckbox('Manual AA', _1844519, _1603949, manualaa)) manualaa = !manualaa;
            if (server == 'valve') {
                if (Dcheckbox('Matchmaking fakeduck', _1844519, _1603949 + (-8 * 773 + -7849 + 14048), fakeduck)) fakeduck = !fakeduck;
            } else {
                if (Dcheckbox('Matchmaking fakeduck [disabled]', _1844519, _1603949 + (701 + 2521 * -2 + 4356), fakeduck)) fakeduck = !fakeduck;
            }
            if (fakeduck) {
                if (Dcheckbox('Speed up FD', _1844519, _1603949 + (6138 + 3 * 107 + -6429), speedupfd)) speedupfd = !speedupfd;
            }
            if (Dcheckbox('Legit AA on use key', _1844519, _1913200 + (4221 + -2857 * 2 + 1523), legitaa)) legitaa = !legitaa;
            var _5091876 = ['Off', 'Primary', 'Anti-brute', 'Reverse freestand', 'Legit'],
                _2062653 = Ddropdown('AA mode', _1844519, _1913200 + (13 * 30 + 2771 + -3116), _5091876, arrayopened, _5091876[chosenoption]);
            _2062653 != undefined && (_2062653 == 'closed' ? arrayopened = !arrayopened : (chosenoption = _2062653, arrayopened = !arrayopened));
            if (UI['GetValue']('AA mode') == 5601 + 6478 + -12075) legitaa = ![];
            if (Dcheckbox('Adaptive fakelag', _1844519 + (2 * 1553 + 5565 + -8441), _1603949, adaptiveflag)) adaptiveflag = !adaptiveflag;
            if (Dcheckbox('Fakelag spammer', _1844519 + (-8615 + 7472 + 1373), _1603949 + (-303 * 25 + -564 + 8154), fakelagspam)) fakelagspam = !fakelagspam;
            if (Dcheckbox('Disable fakelag while standing', _1844519 + (10 * -469 + 45 * 211 + 915 * -5), _1603949 + (3545 * 1 + 1560 + -5075), disableflag)) disableflag = !disableflag;
        }
        if (visualstab) {
            Dcategory(_1844519 - (-346 * 22 + -206 * 4 + 1 * 8446), _1603949 - (-1 * 1829 + -1 * -7667 + -5823), 2 * 394 + -6084 + 5496, 4914 + 3 * 57 + 10 * -501, 'Player ESP'), Dcategory(_1844519 + (7867 * -1 + -3259 * -1 + -284 * -17), _1603949 - (5284 * -1 + 7812 + -2513), -533 * -6 + 52 * 25 + -4298, -1 * -8298 + 12 * 477 + -264 * 53, 'World ESP');
            customcham && Dcategory(_1844519 - (2200 + -1 * 9584 + 7394), _1603949 - (2 * -191 + 3158 + -11 * 251), 62 * 36 + 2492 + 29 * -156, 9417 + -6 * -1434 + -17921, 'Player ESP');
            customcham && UI['GetValue']('customchampreset') == 914 * -9 + -3673 + 11899 && Dcategory(_1844519 - (-1500 + 83 + -1427 * -1), _1603949 - (1299 + 8613 * 1 + -9897 * 1), 9282 + 7989 + 17071 * -1, -8135 + 22 * -16 + 8637, 'Player ESP');
            UI['GetValue']('manualmodes') == -866 * 7 + 568 * 7 + -348 * -6 && Dcategory(_1844519 + (-50 * 65 + 254 + 1 * 3216), _1603949 + (-6053 * -1 + 23 * -389 + 2929), 2706 + 1773 + -4279, 169 * 19 + -5939 * 1 + 2828, 'Indicators');
            UI['GetValue']('manualmodes') == -79 * -84 + 2749 + -9383 && legacykill && Dcategory(_1844519 + (1387 * 7 + -1 * 122 + -551 * 17), _1603949 + (4050 + -103 * -19 + -4 * 1493), -7603 + -2966 + 121 * 89, -5 * -674 + -2 * -3624 + -10493, 'Indicators');
            if (legacykill) {
                Dcategory(_1844519 + (-3 * 1526 + 2316 + 2482), _1603949 + (2207 + -2 * 1237 + -2 * -151), -27 * -169 + -1 * -2177 + 3 * -2180, 1 * -6893 + 1 * 9977 + 2 * -1487, 'Indicators');
                var _1913200 = pos[-7980 + 47 * -149 + -4 * -3746] + (671 * 13 + 2 * -3583 + 1 * -1327);
            } else {
                Dcategory(_1844519 + (-1 * -575 + 570 + -925), _1603949 + (-5350 + 3178 + 2207), -7769 + 2772 + 5197, -8393 + -550 * 5 + 11228, 'Indicators');
                var _1913200 = pos[-523 * 7 + -1049 * -1 + 1 * 2613] + (-7027 + -4716 + 4 * 2987);
            }
            if (Dcheckbox('Name ESP', _1844519, _1603949, nameesp, !![], 'Creates a custom name ESP')) nameesp = !nameesp;
            if (Dcheckbox('Custom weapon icons', _1844519, _1603949 + (1528 + 2840 + -4353), weaponicons, !![], 'Creates coloured weapon icons')) weaponicons = !weaponicons;
            if (Dcheckbox('Hitmarker', _1844519, _1603949 + (1 * 2041 + 1 * -9053 + 7042), hitmarkers)) hitmarkers = !hitmarkers;
            if (Dcheckbox('Custom chams', _1844519, _1603949 + (-3 * -951 + 9622 * -1 + 6814 * 1), customcham)) customcham = !customcham;
            if (customcham) {
                UI['GetValue']('customchampreset') == -272 + 3225 + -2953 * 1 && (base = Dtextbox('Basetexture', _1844519, _1603949 + (2 * 4097 + -2637 + 608 * -9), base), textboxstring = Dtextbox('Envmap', _1844519, _1603949 + (23 * -293 + 8954 + -2105), textboxstring, !![]));
                var _1233733 = ['Custom', 'Skeet', 'Metal', 'Pearl'],
                    _5050450 = Ddropdown('Presets', _1844519, _1603949 + (-6540 + 690 + 5910), _1233733, chamarray, _1233733[preset]);
                _5050450 != undefined && (_5050450 == 'closed' ? chamarray = !chamarray : (preset = _5050450, chamarray = !chamarray));
            }
            if (Dcheckbox('Grenade circles', _1844519 + (6883 + 9121 + 3 * -5258), _1603949, grenadecircles, !![], 'Creates Circles around smokes and infernos')) grenadecircles = !grenadecircles;
            if (Dcheckbox('Keybinds list', _1844519 + (-4353 * 2 + -27 * -367 + -139 * 7), _1603949 + (4642 * -1 + 8463 + 1 * -3771), keybindlist, !![], 'Displays keybinds')) keybindlist = !keybindlist;
            if (Dcheckbox('Spectator list', _1844519 + (830 + -3481 + -43 * -67), _1603949 + (-14 * 23 + -1 * 6041 + 1 * 6428), speclist, !![], 'Displays spectators')) speclist = !speclist;
            if (Dcheckbox('Legacy kill indicators', _1844519 + (-1 * 1989 + 6801 + 1 * -4582), _1603949 + (-589 * 1 + -669 * -1 + 0), legacykill, !![], 'Returns onetap v2 kill indicators')) legacykill = !legacykill;
            if (legacykill) {
                if (Dcheckbox('Animated indicators', _1844519 + (-1331 * 2 + 1 * -1861 + 4753), _1603949 + (-1 * -3467 + 3 * 1487 + -7833), animatedindicators, !![], 'Animates onetap v2 kill indicators')) animatedindicators = !animatedindicators;
                if (Dcheckbox('Static color', _1844519 + (2554 + -8 + -2316), _1603949 + (7247 + 8754 + -15891), staticcolor)) staticcolor = !staticcolor;
            }
            if (UI['GetValue']('manualmodes') == 1 * 7127 + -1693 * 1 + -5432) {
                if (Dcheckbox('Fake amount color', _1844519 + (11 * -169 + 8875 + -6786), _1913200 + (-1 * -1987 + -3823 + 1861 * 1), fakeamount, !![], 'Animates onetap v2 kill indicators')) fakeamount = !fakeamount;
            }
            var _3474271 = ['Off', 'Simple', 'Advanced'],
                _6135020 = Ddropdown('AA Indicator', _1844519 + (-9530 + -185 + 9945), _1913200, _3474271, arrayopened2, _3474271[chosenthing]);
            _6135020 != undefined && (_6135020 == 'closed' ? arrayopened2 = !arrayopened2 : (chosenthing = _6135020, arrayopened2 = !arrayopened2));
        }
        if (misctab) {
            underglow ? (Dcategory(_1844519 - (253 + 7664 + -7907), _1603949 - (3379 + -6906 + -322 * -11), -2966 + 2164 * 1 + -1 * -1002, 4 * -1601 + -7512 + 319 * 44, 'Visual misc'), _1913200 = pos[-980 + -3635 + 4616] + (-5207 * -1 + -1938 + 12 * -262), sy3 = pos[3559 + 8963 + -659 * 19] + (3508 + -7037 + 9 * 406)) : (Dcategory(_1844519 - (1532 + 2015 + -3537), _1603949 - (-117 * 19 + 935 + 1303), 5 * 167 + 127 * -13 + 1016, 1 * -4783 + 129 * 26 + -26 * -59, 'Visual misc'), _1913200 = pos[1 * 1082 + 166 * -59 + 8713] + (7185 + -4621 + -409 * 6), sy3 = pos[-6597 + 6321 * -1 + -1 * -12919] + (-1128 * -6 + 1048 + -7706));
            transparentnade && (Dcategory(_1844519 - (-9397 + -3653 + 13060), _1603949 - (-6976 + 6088 + 903), -6662 * -1 + -5 * 1194 + -492, -8415 + 7 * 811 + -2863 * -1, 'Visual misc'), sy3 = pos[2068 + 6341 + -2 * 4204] + (-1 * -189 + 1 * -5515 + 5456));
            transparentnade && underglow && (Dcategory(_1844519 - (8188 + -5621 + -2557 * 1), _1603949 - (-3335 + 4057 * -1 + 7407), 7243 + 8199 + -1 * 15242, 884 * -1 + -2274 * -4 + -8072, 'Visual misc'), sy3 = pos[4244 + -8874 + 4631] + (317 * -15 + 209 * -23 + 9707));
            Dcategory(_1844519 + (2 * 481 + 9642 + -11 * 944), _1603949 + (-8513 + -8579 + 17157), 6236 + 1 * 797 + -6833 * 1, -2397 + 8766 + -701 * 9, 'Misc'), Dcategory(_1844519 + (-1942 + -38 * -127 + -18 * 148), _1603949 - (-9037 + -5054 + 6 * 2351), 5530 + -7 * -649 + 9873 * -1, -880 * 1 + -3569 + 4509, 'Movement');
            if (Dcheckbox('Watermark', _1844519, _1603949, watermark, !![], 'Zona watermark')) watermark = !watermark;
            if (Dcheckbox('Rainbow menu', _1844519, _1603949 + (-8359 * 1 + 2209 + 6165), rainbowmenu)) rainbowmenu = !rainbowmenu;
            if (Dcheckbox('Rainbow line', _1844519, _1603949 + (-9152 + -7308 + 16490), rainbowline)) rainbowline = !rainbowline;
            if (Dcheckbox('Underglow', _1844519, _1603949 + (-8083 * -1 + -1709 + -6329), underglow)) underglow = !underglow;
            if (underglow) {
                if (Dcheckbox('Pulsate', _1844519, _1603949 + (11 * 629 + 5159 + -12018), pulsate)) pulsate = !pulsate;
            }
            if (Dcheckbox('Transparency on grenade', _1844519, _1913200 + (3 * -866 + 31 * 255 + -5247), transparentnade)) transparentnade = !transparentnade;
            transparentnade && (blendslider = Dslider('Blend amount', _1844519, _1913200 + (2629 + -923 + -1641 * 1), blendslider, -1236 + 9943 + -2 * 4353));
            if (Dcheckbox('Kill say', _1844519, sy3 + (9613 + -19 * -175 + -12863), killsay)) killsay = !killsay;
            if (Dcheckbox('Fast duck', _1844519 + (6711 + 1 * -6707 + 226 * 1), _1603949, fastduck)) fastduck = !fastduck;
            if (Dcheckbox('Teleport on peek', _1844519 + (-5617 + 1 * 9567 + 248 * -15), _1603949 + (-2813 + 152 * -60 + 11948), tponpeek)) tponpeek = !tponpeek;
            if (Dcheckbox('Auto peek', _1844519 + (9818 + 3211 + -12799), _1603949 + (-37 * -1 + -61 * 63 + -274 * -14), autopeek)) autopeek = !autopeek;
            if (Dcheckbox('Hitlogs', _1844519 + (3 * 2279 + -9188 + -89 * -29), _1603949 + (-1423 * 1 + 1410 + 3 * 31), hitlog)) hitlog = !hitlog;
            if (Dcheckbox('Clantag', _1844519 + (1 * -3893 + 8360 + -4237), _1603949 + (-8260 + -8090 + 253 * 65), clantagz, !![], 'Zona clantag')) clantagz = !clantagz;
            if (Dcheckbox('Faster awp autobuy', _1844519 + (6892 + 4 * -193 + 190 * -31), _1603949 + (97 * 29 + 1 * 1231 + -2 * 1967), awpautobuy, !![], 'Autobuys the awp faster')) awpautobuy = !awpautobuy;
        }
    }
    UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'menu list x', pos[-7 * -406 + 1894 * -2 + 2 * 473]), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'menu list y', pos[-152 * -12 + -2936 + -1113 * -1]);
}
Cheat['RegisterCallback']('Draw', 'MenuRender');

function player_death() {
    if (Entity['GetEntityFromUserID'](Event['GetInt']('attacker')) == Entity['GetLocalPlayer']() && legacykill) {
        var _4042466 = Render['GetScreenSize']()[-688 + -321 * 31 + -1 * -10639] / (131 * -59 + 1733 * 2 + 4265 * 1),
            _4690318 = Render['GetScreenSize']()[-193 * -13 + 562 * 2 + -3632] / (2498 + -86 * 17 + 517 * -2),
            _3594105 = [1 * -8724 + 4763 + -1 * -4021, -1089 + 6525 * 1 + -1782 * 3 + (7 * 69 + 2309 + -2762), 4779 + -1 * -8941 + -13540 + (-1 * -3248 + -293 * -9 + -233 * 25), -2451 * 3 + 34 * -10 + 1 * 7963 + (6703 + 3038 + -1 * 9711)];
        effects['push']([texts[Math['min'](kills, texts['length'])], -7871 + -4002 * 1 + 11873, !![], _4042466, _4690318, _3594105[kills % _3594105['length']], -211 * -5 + 2499 + 1777 * -2, 709 * -13 + -2574 + -1 * -12391, !![],
            [Math['random']() * (-3076 + -6666 + -1 * -9997) / (-5693 * 1 + 9021 + -3326) + (-6823 + 3778 * -2 + 9 * 1626) / (-8768 + 2 * 4684 + -598), Math['random']() * (7372 + 5381 * -1 + -62 * 28) / (-9648 + 1985 + 2555 * 3) + (-4658 * -1 + -8406 + 4003) / (-102 * 25 + -1938 + 4490), Math['random']() * (-68 * 82 + 3232 * 1 + 2599 * 1) / (-1 * -3136 + 6123 + -9257) + (-28 * 328 + 3 * 1155 + 5974 * 1) / (1 * 1447 + 2476 + -3921)]
        ]), kills++;
    }
}

function roundstart() {
    kills = 5921 + -6967 + 1 * 1046, globals['alternate']['tickcount'] = -6583 + -4742 * 1 + 11325, localobservers = [], n_localobservers = [];
}

function itemcheck() {
    UI['IsMenuOpen']() && (UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'menu list x', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'menu list y', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'spectator list x', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'spectator list y', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'keybinds list y', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'keybinds list x', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'customchampreset', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'improveddtcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'lethaldtcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'safeawpcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'awpcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'safelimbcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'dtbaimcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'mindmgcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'nameespcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'weaponiconscheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'hitmarkerscheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'legacykillcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'transparentnadecheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'customchamcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'speclistcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'keybindlistcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'grenadecirclescheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'hitlogcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'manualaacheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'adaptiveflagcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'fakelagcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'disableflagcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'fakeduckcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'speedcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'watermarkcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'clantagzcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'tponpeekcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'autopeekcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'r8hccheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'fastduckcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'rainbowlinecheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'rainbowmenucheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'underglowcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'killsaycheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'pulsatecheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'manualmodes', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'fakeamountcheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'legitaacheck', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Animated Indicators', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Static color', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'AA mode', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Hitchance', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Minimum damage', ![]), !mindmg ? UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Minimum damage key', ![]) : UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Minimum damage key', !![]), !manualaa ? (UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Manual left', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Manual right', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Manual back', ![])) : (UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Manual left', !![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Manual right', !![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Manual back', !![])), !tponpeek ? UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Teleport key', ![]) : UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Teleport key', !![]), !customcham ? UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Zona chams', ![]) : UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Zona chams', !![]), !autopeek ? (UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Auto peek key', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Auto peek color', ![])) : (UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Auto peek key', !![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Auto peek color', !![])), !grenadecircles ? (UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Inferno color', ![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Smoke color', ![])) : (UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Inferno color', !![]), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Smoke color', !![])), UI['SetEnabled']('Misc', 'JAVASCRIPT', 'Script items', 'Blend amount', ![]));
}
vec = [], vec2 = [], lpe = [], delay = -1 * -3938 + -2384 + -74 * 21;

function reload() {
    Curtime = Globals['Curtime'](), Curtime >= delay && (delay = Curtime + (-4403 + -1294 * 1 + 5701), vec = [], vec2 = []);
}
var accs = ['- gone -', 'customwhitelist', 'midniight', 'Hyu', 'anticlub', 'Lythicals', 'erupt', 'Antismog', 'vapingcat', 'd3tox', 'xslayer6969'];

function usercheck_old(_1177916, _5839654) {
    return _1177916['indexOf'](_5839654) != -(-3 * 2721 + 6 * -717 + 12466);
}

function a() {
    var _2899564 = Globals['Tickrate']()['toString']();
    usercheck(accs, niggas) ? cring && (Cheat['PrintChat'](' [' + 'deso' + 'late' + '] ' + 'Whitelist verified '), Cheat['PrintChat'](' [' + 'deso' + 'late' + '] ' + 'Welcome to Zona, ' + niggas), cring = ![]) : yes && (Cheat['PrintChat'](' [' + 'deso' + 'late' + '] ' + 'Whitelist failed '), yes = ![]);
    _2899564 == 917 * -6 + 1743 + 3887 ? exploitwarning && (Cheat['PrintChat'](' [' + 'deso' + 'late' + '] ' + 'WARNING You are on an 128 tick server! Exploits will be greatly effected! '), exploitwarning = ![]) : exploitwarning = !![];
    server == 'valve [aimstep]' || server == 'valve' ? matchmakingwarning && (Cheat['PrintChat'](' [' + 'deso' + 'late' + '] ' + 'WARNING You are on a Valve server! Exploits have been disabled! '), matchmakingwarning = ![]) : matchmakingwarning = !![];
    if (Cheat['GetUsername']['toString']() != 'function () { [native code] }')
        while (!![]) {
            Cheat['Print']('stop cracking 5 my script lmfao');
        }
    if (Global['GetUsername']['toString']() != 'function () { [native code] }')
        while (!![]) {
            Cheat['Print']('stop cracking 3 my script lmfao');
        }
    if (Cheat['GetUsername']['toString']['name'] == '')
        while (!![]) {
            Cheat['Print']('stop cracking my script lmfao');
        }
    if (Global['GetUsername']['toString']['name'] == '')
        while (!![]) {
            Cheat['Print']('stop cracking  9 my script lmfao');
        }
    if (Function['prototype']['toString']['name'] == '')
        while (!![]) {
            Cheat['Print']('stop cracking  2 my script lmfao');
        }
    if (Function['toString']['hasOwnProperty']('prototype'))
        while (!![]) {
            Cheat['Print']('stop cracking my 45 script lmfao');
        }
    if (Cheat['GetUsername']['toString']['hasOwnProperty']('prototype'))
        while (!![]) {
            Cheat['Print']('stop cracking my 5 5 script lmfao');
        }
    if (Global['GetUsername']['toString']['hasOwnProperty']('prototype'))
        while (!![]) {
            Cheat['Print']('stop cracking my 77 script lmfao');
        }
    if (Object['getPrototypeOf'](Function['prototype']['toString']) == null)
        while (!![]) {
            Cheat['Print']('stop cracking my 6 script lmfao');
        }
    if (Object['getPrototypeOf'](Cheat['GetUsername']['toString']) == null)
        while (!![]) {
            Cheat['Print']('stop cracking my3 3 3 script lmfao');
        }
    if (Object['getPrototypeOf'](Global['GetUsername']['toString']) == null)
        while (!![]) {
            Cheat['Print']('stop cracking my 23 script lmfao');
        }
}
var frame = 8519 + -253 * 9 + -3121 * 2;

function cm() {
    if (!yes) return;
    update(), handle_hotkeys(), adjust_antiaim(), adjust_lag(), plocal = Entity['GetLocalPlayer']();
    Input['IsKeyPressed'](6147 * 1 + 4726 + -10784) && (typing = !![]);
    (Input['IsKeyPressed'](4892 + -3791 * 2 + 11 * 247) || Input['IsKeyPressed'](-8171 + -4764 + -249 * -52)) && (typing = ![]);
    (UI['GetValue']('AA mode') == -811 + 1366 * -7 + 10377 || legitaa && Input['IsKeyPressed'](-4 * 67 + 2 * -1063 + 2463) && !typing) && plegitaa();
    if (fastduck) {
        var _2550161 = UserCMD['GetButtons']();
        UserCMD['SetButtons'](_2550161 | -4102 + 1 * 5703 + -1600 << 4101 * 2 + -4546 * 1 + -3634);
    }
    if (fakeduck && UI['IsHotkeyActive']('Anti-Aim', 'Extra', 'Fake duck') && server == 'valve') {
        UI['SetValue']('Anti-Aim', 'Fake-Lag', 'Limit', 4339 * 1 + 1455 * 3 + -8690);
        var _1297279 = Entity['GetProp'](Entity['GetLocalPlayer'](), 'CCSPlayer', 'm_flDuckAmount');
        UserCMD['Choke']();
        speedupfd ? _1297279 <= (3125 * -2 + 1 * -4621 + -10931 * -1) / (7039 + 1 * 2609 + 2 * -4774) && (globals['fd']['crouch'] = !![]) : _1297279 <= (2523 * 1 + 63 * 119 + -2 * 5009) / (-69 * -92 + 5 * -303 + -4733) && (globals['fd']['crouch'] = !![]);
        _1297279 >= -569 * -6 + 530 + -3943.22 && (globals['fd']['crouch'] = ![], UserCMD['Send']());
        var _3581643 = 3259 + -2 * -4250 + -11758 * 1 << 4001 * 1 + 57 * -119 + 2784,
            _2550161 = UserCMD['GetButtons']();
        globals['fd']['crouch'] ? _2550161 |= _3581643 : _2550161 &= ~_3581643, UserCMD['SetButtons'](_2550161 | -6405 + -2547 + 8953 << 91 * 43 + 1519 + -1082 * 5);
    }
    UI['GetValue']('AA mode') != -71 + 3413 * -1 + 3485 && AntiAim['SetOverride'](-4353 + -779 + 5132);
    if (improveddt) {
        var _5603267 = Entity['GetName'](Entity['GetWeapon'](Entity['GetLocalPlayer']())),
            _1410519 = Exploit['GetCharge'](),
            _6108520 = -8242 + 189 + 1 * 8053;
        Exploit[(_1410519 != 1657 + 8825 + -10481 ? 'Enable' : 'Disable') + 'Recharge'](), shiftshit(-3 * 379 + -1 * 1259 + 2410) && _1410519 != -5821 * 1 + 7108 + -1286 && (Exploit['DisableRecharge'](), Exploit['Recharge']()), Exploit['OverrideTolerance'](_6108520), Exploit['OverrideShift'](4 * -1198 + -471 * 8 + 6 * 1429 - _6108520);
    }!improveddt && (Exploit['EnableRecharge'](), Exploit['OverrideTolerance'](1 * 1447 + -47 * 45 + -335 * -2), Exploit['OverrideShift'](-8591 + -9232 + 17835));
    disableflag && (get_velocity() < -6029 + -8117 * 1 + 14151 ? UI['SetValue']('Anti-Aim', 'Fake-Lag', 'Enabled', ![]) : UI['SetValue']('Anti-Aim', 'Fake-Lag', 'Enabled', !![]));
    if (autopeek) {
        var _5129143 = Entity['GetRenderOrigin'](plocal);
        if (plocal || Entity['IsAlive'](plocal)) {
            UI['IsHotkeyActive']('Script items', 'Auto peek key') ? moving = !![] : (saved = ![], moving = ![]);
            fired && UI['IsHotkeyActive']('Script items', 'Auto peek key') ? (playing = !![], UI['IsHotkeyActive']('Script items', 'Auto peek key') && (moving = ![])) : (playing = ![], fired = ![]);
            if (moving) {
                savestartpos();
                var _2550161 = UserCMD['GetButtons']();
                safeloc['push']([Local['GetViewAngles'](), _2550161]);
            } else {
                if (playing) {
                    if (get_velocity() < 643 * -14 + -8053 + 17065 * 1 && _5129143 >= startpos + (-8926 + -6167 * -1 + 3259)) {
                        UI['ToggleHotkey']('Misc', 'GENERAL', 'Movement', 'Auto peek');
                        return;
                    }
                    Return2Dest(startpos);
                }
            }
        }
    }
    if (dtbaim) {
        local_player_eyepos = Entity['GetEyePosition'](plocal);
        var _3234177;
        if (dtbaim && Exploit['GetCharge']() == -1 * -4759 + -15 * -579 + -3 * 4481 && UI['GetValue']('Rage', 'GENERAL', 'Exploits', 'Doubletap') && UI['IsHotkeyActive']('Rage', 'GENERAL', 'Exploits', 'Doubletap')) _3234177 = !![];
        else _3234177 = ![];
        for (i = -1 * 5101 + -1 * 2579 + 7680; i < enemies['length']; i++) {
            if (Entity['IsAlive'](enemies[i]) && Entity['IsValid'](enemies[i]) && !Entity['IsDormant'](enemies[i])) {
                var _1778977 = Entity['GetProp'](enemies[i], 'CBasePlayer', 'm_iHealth');
                for (j = 4450 + -3135 * 3 + -1 * -4957; j <= -5909 + 75 * 113 + -2554; j++) {
                    hitbox_pos = Entity['GetHitboxPosition'](enemies[i], j), traced = Trace['Bullet'](plocal, enemies[i], local_player_eyepos, hitbox_pos);
                    if (traced == null) continue;
                    if (traced[2612 + 19 * -47 + 859 * -2] >= _1778977) {
                        force_baim = 21 * 293 + -3089 + -3063;
                        return;
                    }
                    if (_3234177 && traced[8341 * -1 + -9684 + 18026] >= _1778977 / (-80 * -99 + -1 * -9658 + -17576)) {
                        force_baim = -7216 + -9533 + 16751;
                        return;
                    }
                }
            }
        }
    }
    if (manualaa) {
        isLeftActive = UI['IsHotkeyActive']('Misc', 'JAVASCRIPT', 'Script items', 'Manual left'), isRightActive = UI['IsHotkeyActive']('Misc', 'JAVASCRIPT', 'Script items', 'Manual right'), isBackActive = UI['IsHotkeyActive']('Misc', 'JAVASCRIPT', 'Script items', 'Manual back');
        if (!typing && isLeftActive) drawLeft = 911 * -1 + -4969 * 1 + -1 * -5881, drawBack = -8931 + -18 * 167 + 11937, drawRight = -8429 + -2798 + -11227 * -1, UI['SetValue']('Anti-Aim', 'Rage Anti-Aim', 'Yaw offset', -(-2 * -1253 + 9018 + -5717 * 2)), UI['SetValue']('Anti-Aim', 'Rage Anti-Aim', 'At targets', ![]);
        else {
            if (!typing && isRightActive) drawLeft = -3761 + 6540 + 7 * -397, drawBack = 1462 + -101 * 61 + 127 * 37, drawRight = 678 * 1 + 26 * 269 + 1 * -7671, UI['SetValue']('Anti-Aim', 'Rage Anti-Aim', 'Yaw offset', -1868 + 3 * -2195 + 8543), UI['SetValue']('Anti-Aim', 'Rage Anti-Aim', 'At targets', ![]);
            else !typing && isBackActive && (drawLeft = -2463 * -3 + -3 * 218 + -6735, drawBack = 7423 + -2725 * 3 + 753, drawRight = 6612 + -1912 + -4700, UI['SetValue']('Anti-Aim', 'Rage Anti-Aim', 'Yaw offset', 2296 + 135 * -1 + -2161), UI['SetValue']('Anti-Aim', 'Rage Anti-Aim', 'At targets', !![]));
        }
    }
    if (lethaldt && UI['IsHotkeyActive']('Rage', 'GENERAL', 'Exploits', 'Doubletap') && !UI['IsHotkeyActive']('Misc', 'JAVASCRIPT', 'Script items', 'Minimum damage key') && !UI['IsHotkeyActive']('Anti-Aim', 'Extra', 'Fake duck'))
        for (i in enemies) {
            if (Exploit['GetCharge']() == 4383 + -274 * -6 + -6026) Ragebot['ForceTargetMinimumDamage'](enemies[i], Math['round'](Entity['GetProp'](enemies[i], 'CBasePlayer', 'm_iHealth') / (1510 + -62 * -7 + 2 * -971)));
            else {
                if (Entity['GetProp'](enemies[i], 'CBasePlayer', 'm_iHealth') <= -8 * 796 + 7099 * -1 + 13517) Ragebot['ForceTargetMinimumDamage'](enemies[i], Entity['GetProp'](enemies[i], 'CBasePlayer', 'm_iHealth'));
            }
        }
    if (safelimb)
        for (i = 2267 * -1 + -5239 + 1 * 7507; i < -5120 + 3936 + -1196 * -1; i++) {
            Ragebot['ForceHitboxSafety'](i);
        }
    if (tponpeek && UI['IsHotkeyActive']('Rage', 'GENERAL', 'Exploits', 'Doubletap') && UI['IsHotkeyActive']('Misc', 'JAVASCRIPT', 'Script items', 'Teleport key')) {
        var _2127922 = Entity['GetEyePosition'](plocal),
            _4720691 = Entity['GetProp'](plocal, 'CBasePlayer', 'm_vecVelocity[0]');
        _4720691[-1220 + -1 * 342 + 1562] *= 31 * -220 + -6515 + 13335.2, _4720691[6771 * -1 + -37 * 157 + 12581] *= -8465 + 11 * -698 + 16143.2, _4720691[-4145 + -9927 + 14074] *= -8085 + 4 * 1655 + 1465.2, _4720691 = vec_add(_2127922, _4720691);
        for (i in enemies) {
            if (!Entity['IsAlive'](enemies[i]) || Entity['IsDormant'](enemies[i])) continue;
            var _2730420 = Trace['Line'](enemies[i], Entity['GetEyePosition'](enemies[i]), _4720691);
            if (_2730420 && _2730420[1522 + 8929 + 10450 * -1] && _2730420[-7 * 549 + 3724 + 20 * 6] == 27 * 84 + 2066 * -3 + 3931 * 1) {
                UI['ToggleHotkey']('Rage', 'GENERAL', 'Exploits', 'Doubletap');
                break;
            }
        }
    }
    if (fakelagspam) {
        frame++;
        if (frame == 8846 + 7 * 524 + -12504) frame = -134 * 22 + -2505 * -2 + -2061;
        if (frame >= -5797 + 4 * 2114 + 2654 * -1 && frame <= -55 * -166 + 9944 + -2383 * 8) UI['SetValue']('Anti-Aim', 'Fake-Lag', 'Enabled', !![]);
        else UI['SetValue']('Anti-Aim', 'Fake-Lag', 'Enabled', ![]);
    }
    if (safeawp) {
        var _5603267 = Entity['GetName'](Entity['GetWeapon'](Entity['GetLocalPlayer']()));
        _5603267 == 'awp' && (target = Ragebot['GetTarget'](), Ragebot['ForceTargetSafety'](target));
    }
}

function get_velocity() {
    return velocity = Entity['GetProp'](Entity['GetLocalPlayer'](), 'CBasePlayer', 'm_vecVelocity[0]'), speed = Math['sqrt'](velocity[4769 + -5473 + 704] * velocity[2826 + -6 * 580 + 654] + velocity[2706 * -1 + -6731 * 1 + 9438] * velocity[1351 + 7626 + -8976]), speed;
}

function rand_int(_5417823, _5931797) {
    return Math['floor'](Math['random']() * (_5931797 - _5417823 + (-185 * -38 + 118 * -82 + 2647 * 1)) + _5417823);
}

function update() {
    globals['tick_count'] = Globals['Tickcount'](), globals['cur_time'] = Globals['Curtime'](), local['real'] = Math['floor'](Local['GetRealYaw']()), local['fake'] = Math['floor'](Local['GetFakeYaw']()), local['duck_amount'] = Entity['GetProp'](Entity['GetLocalPlayer'](), 'CBasePlayer', 'm_flDuckAmount');
}

function set_wish_angles() {
    if (!yes || UI['GetValue']('AA mode') != 239 * -11 + 7772 + -857 * 6) return;
    AntiAim['SetOverride'](-3221 * 1 + 4 * -1033 + -7354 * -1), AntiAim['SetRealOffset'](wish['real']), AntiAim['SetFakeOffset'](wish['fake']), AntiAim['SetLBYOffset'](wish['lby']);
}

function handle_hotkeys() {
    wish['side'] = UI['IsHotkeyActive']('Anti-Aim', 'Fake angles', 'Inverter') ? 2537 + 1754 * -4 + 1120 * 4 : 921 * 5 + -3581 + 512 * -2, local['shifting'] = Input['IsKeyPressed'](-542 + -4 * -2462 + -9290) ? !![] : ![];
}

function adjust_antiaim() {
    if (!yes || UI['GetValue']('AA mode') != -8049 + -1631 + 9681) return;
    if (local['shifting']) get_velocity() > 20 * -85 + 44 * -63 + 4474 && (wish['lby'] = -(2371 + 7 * 872 + -135 * 61), wish['real'] = globals['tick_count'] % (236 * -18 + 5878 + 407 * -4) ? rand_int(-(5569 + 8752 + -14266), -(4535 + 1 * -4853 + 2 * 170)) : rand_int(-2935 + 7771 + -58 * 83, -9886 + -3031 + 12972));
    else {
        if (wish['side'] == 4729 * 1 + -1 * -1643 + 1062 * -6) wish['lby'] = -(-401 * -20 + -2 * 807 + 13 * -482), wish['real'] = globals['tick_count'] % (-7957 * 1 + 455 * 10 + 3 * 1158) ? rand_int(-(-520 + -6777 + 7382), -(9497 + -122 * -29 + -4 * 3252)) : rand_int(9214 * -1 + -327 * -10 + -5991 * -1, 891 * 3 + -1 * -601 + -3259 * 1);
        else wish['side'] == -1252 + -6284 + 7537 && (wish['lby'] = -(4427 + -373 + 1 * -3914), wish['real'] = globals['tick_count'] % (358 * 4 + -4385 + 3020) ? rand_int(-13 * -141 + 1 * -2638 + -89 * -10, 317 * 21 + -8893 + 2263) : rand_int(-(1478 * 2 + 8295 + 5602 * -2), -(7438 + 290 * 24 + -1 * 14383)));
    }
    set_wish_angles();
}

function adjust_lag() {
    if (!yes || !adaptiveflag) return;
    in_air() ? (distance_per_tick = get_velocity() * Globals['TickInterval'](), choked_ticks = Math['ceil']((-3783 + 1861 * 3 + 124 * -14) / distance_per_tick), wish['limit'] = Math['min'](choked_ticks, 200 + -1153 * -5 + 5949 * -1)) : wish['limit'] = rand_int(116 * -12 + -134 * 55 + 381 * 23, -1 * 3199 + -134 * 10 + 4548), UI['SetValue']('Anti-Aim', 'Fake-Lag', 'Limit', wish['limit']);
}

function ifunload() {
    AntiAim['SetOverride'](1 * 30 + -2844 + 2814 * 1), Local['SetClanTag'](''), Exploit['EnableRecharge'](), Exploit['OverrideTolerance'](-1010 + 5585 + -4573), Exploit['OverrideShift'](224 + -2966 * 1 + 2754);
    for (i in materials) {
        Material['Destroy'](materials[i][-3125 + -4765 * -1 + -1639]);
    }
}

function HSVtoRGB(_2624683, _5914367, _3529420) {
    var _5682297, _5725499, _2099085, _4085698, _5788323, _1139914, _4410919, _2604367;
    arguments['length'] === 2 * -321 + -3668 + 4311 && (_5914367 = _2624683['s'], _3529420 = _2624683['v'], _2624683 = _2624683['h']);
    _4085698 = Math['floor'](_2624683 * (-6367 * 1 + -1604 * -3 + 1561)), _5788323 = _2624683 * (-1 * 6401 + -11 * -635 + -578) - _4085698, _1139914 = _3529420 * (-20 * -83 + -32 * -27 + 2523 * -1 - _5914367), _4410919 = _3529420 * (1476 + 800 + -2275 - _5788323 * _5914367), _2604367 = _3529420 * (2667 + 13 * -659 + -3 * -1967 - (-5 * -1329 + -43 * -1 + -6687 - _5788323) * _5914367);
    switch (_4085698 % (1739 * 1 + 3 * 3011 + -14 * 769)) {
        case 773 * 9 + -6895 + 62 * -1:
            _5682297 = _3529420, _5725499 = _2604367, _2099085 = _1139914;
            break;
        case 7187 + 4149 + -11335:
            _5682297 = _4410919, _5725499 = _3529420, _2099085 = _1139914;
            break;
        case 7265 + -8912 * 1 + -97 * -17:
            _5682297 = _1139914, _5725499 = _3529420, _2099085 = _2604367;
            break;
        case -2876 + 12 * -316 + -1 * -6671:
            _5682297 = _1139914, _5725499 = _4410919, _2099085 = _3529420;
            break;
        case 3236 + 9653 + -12885:
            _5682297 = _2604367, _5725499 = _1139914, _2099085 = _3529420;
            break;
        case 9241 + -9949 + 713:
            _5682297 = _3529420, _5725499 = _1139914, _2099085 = _4410919;
            break;
    }
    var _4023899 = {};
    return _4023899['r'] = Math['round'](_5682297 * (341 + 4290 + 4376 * -1)), _4023899['g'] = Math['round'](_5725499 * (6577 * -1 + -7694 * 1 + -27 * -538)), _4023899['b'] = Math['round'](_2099085 * (3762 + -2 * -3158 + 1 * -9823)), _4023899;
}
var disabled = -113 * -73 + 2084 + -10333,
    started = 6398 + 8 * 454 + -10030;
timezz = Globals['Curtime'](), delayzz = timezz + (-2 * 3628 + 2738 * 1 + -4519 * -1);
var shitcum = -35 * -143 + 2803 + -8 * 976,
    autopeeksmall = -826 * -7 + 7264 * 1 + -13046,
    autopeekstarted = 5547 + 9741 * 1 + -15288;

function paint() {
    tickcount = Global['Tickcount'](), colors = HSVtoRGB(Globals['Realtime']() / (-8556 + 269 * -2 + 9114), -3545 + -544 + -1 * -4090, 5949 * -1 + -21 * -291 + -1 * 161, 1330 * 5 + 1906 + -8555, 9645 + -1689 * 2 + -18 * 334), itemcheck();
    if (!yes) return;
    plocal = Entity['GetLocalPlayer']();
    var _3621139 = Render['AddFont']('Verdana', 2283 * 1 + 5809 + 2695 * -3, 2165 + 9152 + -10917),
        _1178285 = Render['AddFont']('gotham-bold', 7571 + -22 * 267 + -1677, 2063 * 4 + 3 * -2679 + -115),
        _5112437 = Render['AddFont']('gotham-bold', -7535 + 1975 + 188 * 30, -303 * -8 + 5351 + 1 * -7675);
    color = UI['GetColor']('Misc', 'JAVASCRIPT', 'Script items', 'Main color'), espcolor = UI['GetColor']('Misc', 'JAVASCRIPT', 'Script items', 'ESP color');
    if (color[614 * -1 + 77 * -67 + 5773] === -3 * 123 + -1493 * 3 + 808 * 6 && color[3535 + 2 * -165 + -12 * 267] === 94 * -1 + -1820 + 1914 && color[-9793 + 8943 + 1 * 852] === -21 * 314 + 8579 + -1 * 1985 && color[-1644 + -3538 + 5185] === -8673 + -1094 * 5 + 14143) UI['SetColor']('Misc', 'JAVASCRIPT', 'Script items', 'Main color', [-6309 + 9241 + -2795, -4906 + 589 * 8 + 1 * 323, -4856 + 3112 + 1999, -4062 + -448 + -1 * -4765]);
    if (espcolor[3342 + -94 * -53 + -8324] === -6757 + -1 * 6551 + 13308 && espcolor[-2 * -4990 + -79 * 2 + -9821] === 7 * 374 + 3836 + -6454 && espcolor[3812 + -8668 + 4858] === 9229 * 1 + -2344 + -6885 && espcolor[-5002 + 9 * 135 + 3790] === -8053 * 1 + 2343 + 5710) UI['SetColor']('Misc', 'JAVASCRIPT', 'Script items', 'ESP color', [-2995 + -93 * -93 + -5516, -672 + -49 * 23 + 1902, -5076 + -488 + 5809, 341 * -26 + 4090 + 5031]);
    var _4515289 = Global['GetScreenSize']()[-7716 * 1 + 2511 + 5205] / (-1 * 6551 + 725 * -1 + -7278 * -1) - (457 * -13 + 203 + 5998);
    curpos = Global['GetScreenSize']()[-8123 + -2436 * 1 + -160 * -66] / (1418 * -4 + 3 * 2113 + -658), poopshartfont = Render['AddFont']('consolas', -1079 * -3 + 4324 + -7531, -4874 + -5498 + 10462), welcomer = 'Polags can\'t code';
    var _2034788 = Render['TextSizeCustom'](welcomer, poopshartfont)[-3 * -685 + -4150 + 2095] + (-43 * 49 + -8747 + 10924);
    const _7460700 = Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((-2762 + 37 * 241 + 362 * -17) / (-113 * -37 + 7909 + -12089.5)) % (Math['PI'] * (-2710 + 5937 + -3225)))) * (4682 * 2 + 9051 + -18160);
    stupidnn = Globals['Curtime']();
    if (stupidnn >= delayzz) {
        if (started == 1 * -4027 + -9638 + 3 * 4555) {
            if (disabled >= 2409 * 3 + 530 * -14 + 193) disabled++;
            if (disabled == -9631 + -9801 + 19622);
        }
    }
    started != -1441 * 3 + 5017 + 63 * -11 && (Render['FilledRect'](_4515289, curpos - (-225 + -1402 * 3 + 4441 * 1) - disabled, _2034788 + (10 * -244 + -4585 + 7035), 4957 * 2 + -328 * -19 + -16066 * 1, [-7538 * -1 + -4 * -2443 + -17265, -1026 + 5 * -395 + 3049, 213 * 40 + -7757 + -236 * 3, -5 * 146 + -906 + 1891]), Render['FilledRect'](_4515289 - (506 + -7844 + -41 * -179), curpos - (2 * -2509 + 2 * 4198 + -3369) - disabled, _2034788 + (-538 * -2 + 1307 + -2371), -9727 + -4488 * -1 + -1 * -5317, [5348 + -3231 + -2072 * 1, 3 * 1816 + -157 * -13 + -7441 * 1, -1102 + 38 * 33 + -97 * 1, -7455 + 43 * 73 + 4571]), Render['GradientRect'](_4515289, curpos - (-28 * 308 + -6426 + 443 * 34) - disabled, _2034788 + (-747 + 4148 + -3392), -3817 + 9904 + -1 * 6061, 1 * 4979 + -1 * -9239 + -7109 * 2, rainbowmenu ? [colors['r'], colors['g'], colors['b'], _7460700] : [color[5827 + 4260 + -131 * 77], color[-2383 + 8283 + -5899], color[-2430 + 9813 + -11 * 671], _7460700], [-4506 + -1 * 7892 + 12398, 3 * -253 + -5160 + -1973 * -3, -655 * 7 + 161 * 24 + 721 * 1, -1 * -6544 + 1587 + 47 * -173]), Render['GradientRect'](_4515289, curpos - (11 * 824 + 613 * -2 + -7818) - disabled, _2034788 + (3 * -309 + 3434 + -1 * 2497), -9438 + -3 * 1249 + -15 * -880, 127 * 65 + -206 * 3 + -23 * 332, rainbowmenu ? [colors['r'] * (-4871 + 893 + 3978.75), colors['g'] * (-6348 + 716 * -3 + 8496.75), colors['b'] * (-5 * 1801 + -128 * 7 + 9901.75), -1538 * 6 + 4363 + 5120] : [color[8752 + 7891 * 1 + -11 * 1513] * (-46 * -186 + 1991 + -10546.25), color[5636 * 1 + 411 * 16 + -12211] * (-3 * -1531 + 2 * -2095 + -402.25), color[9965 + 1 * 6917 + -16880] * (-4914 + 179 * 43 + -2782.25), -1196 * -3 + 9170 + -12503], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[2103 * -4 + 1065 + 7350]] : [color[-3 * -3317 + 1 * 3679 + -13630], color[6380 + -620 * 13 + 1681], color[983 * 3 + -17 * -1 + -2964], color[-274 * 31 + -61 * 134 + 16671]]), Render['GradientRect'](_4515289 - (2790 + -6016 + -1 * -3227), curpos - (-3 * -1345 + -11 * -345 + 107 * -73) - disabled, _2034788 + (-7083 * -1 + 7 * 985 + -13966), -1 * 3209 + -2833 * 2 + 8888, 1 * -5949 + -1201 + 7151, rainbowmenu ? [colors['r'] * (-5087 + 9493 + -4405.25), colors['g'] * (8161 * -1 + -27 * 127 + 11590.75), colors['b'] * (-34 * 27 + 2533 + -1614.25), 6838 + -9210 + 71 * 37] : [color[-603 + -2 * -33 + 537] * (8121 + -2008 * 2 + -4104.25), color[4 * -43 + 61 * -131 + 8164] * (7440 + 4755 + -12194.25), color[26 * 73 + -3261 * 1 + 1365] * (2727 + -5487 + 2760.75), -359 + -3445 + 1 * 4059], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[463 + -5671 + 1737 * 3]] : [color[-5962 + -5 * 582 + -8872 * -1], color[-1615 + -22 * -313 + 17 * -310], color[-1587 + 1297 * -1 + 3 * 962], color[8292 + 2387 * 3 + -15450]]), Render['Rect'](_4515289, curpos - (-319 * 16 + -433 * -5 + 2955), _2034788 + (1 * 9319 + 8461 + -1367 * 13) - disabled, 25 * -45 + 5029 * 1 + -3878, 4821 + 136 + 4957 * -1, [-5606 + 5948 + -342, -569 * -13 + 8883 + -37 * 440, -2798 + 1898 * 5 + -6692, -6 * -1091 + 1 * 589 + -6880]), bettercircle(_4515289 - (1 * -7263 + -2935 + -59 * -173), curpos + (303 * 13 + -1 * 7001 + 1 * 3082) - disabled, 567 + -2217 + 1710, rainbowmenu ? [colors['r'], colors['g'], colors['b'], 2185 + -1984 * 5 + 7990] : [color[468 * 17 + 5 * 1873 + 1 * -17321], color[218 * 26 + 1463 + -7130], color[-14 * -657 + 4401 + 1 * -13597], 5875 + 5497 + 1 * -11117]), bettercircle(_4515289 - (1 * -3109 + -3970 + 7088), curpos + (-3218 * 1 + -5883 + 1 * 9121) - disabled, 274 + -3451 + -809 * -4, [-6291 + -1 * -4790 + 1546, -1039 * 1 + -2 * -1193 + -3 * 433, -3710 + 1 * 1180 + 2585, 5507 + -6193 * 1 + -1 * -941]), Render['StringCustom'](_4515289 - (20 * -92 + -8013 + 9898), curpos - (6120 + 2219 + -8294) - disabled, 2214 + -116 * -2 + -2446, 'D', rainbowmenu ? [colors['r'], colors['g'], colors['b'], -89 * -89 + -303 + -1 * 7363] : [color[-2 * 4055 + -7306 + 15416], color[6227 + 274 * -23 + 4 * 19], color[-5983 + 2566 * 2 + -853 * -1], 889 * -6 + 2707 + 2882], _5112437), Render['StringCustom'](_4515289 + (-8138 + 1 * -8027 + -55 * -295), curpos + (-28 * -232 + 360 * 19 + -13331) - disabled, 1385 + 8543 * 1 + 146 * -68, welcomer, [8152 + -1 * 9263 + 1 * 1366, 1 * -2821 + -8809 + 11885, -596 * -14 + -3 * 2959 + -4 * -197, 34 * -214 + -1 * -7463 + 68 * 1], poopshartfont));
    if (clantagz && server != '') {
        var _2178750 = 'Zona                ';
        for (_2599962 = -1 * 9852 + 3156 + -124 * -54; _2599962 < Math['floor'](Globals['Tickcount']() / (-8066 + 4402 * 1 + -368 * -10)) % _2178750['length']; _2599962++) {
            _2178750 += _2178750['substr'](-9982 + -1299 * 7 + -35 * -545, -6761 + 6608 + 154), _2178750 = _2178750['substr'](-4747 * -1 + 7661 + 12407 * -1);
        }
        _2178750 != lasttag && (lasttag = _2178750, Local['SetClanTag'](_2178750)), autodisable = !![];
    } else autodisable && (autodisable = ![], Local['SetClanTag'](''));
    if (watermark) {
        var _3050479 = '';
        if (usercheck(accs[-7123 * 1 + 1163 * 1 + -1987 * -3], niggas)) _3050479 = 'Dev';
        else {
            if (!usercheck(accs[1 * -3085 + -173 * 21 + 6718], niggas) && !usercheck(accs[-3 * -1913 + -2351 + -3387 * 1], niggas)) _3050479 = niggas + ' | alpha';
            else usercheck(accs[5673 + -1 * -6791 + -12464], niggas) && (_3050479 = niggas);
        }
        const _4248115 = Math['floor'](Global['Latency']() * (7401 + -6961 * 1 + -4 * -140) / (-1 * 4637 + 2 * 1156 + 2326.5));
        var _4598539 = Globals['Tickrate']()['toString']();
        const _5349765 = Globals['Curtime']();
        _5349765 - last_update > -2997 * -1 + 1692 + -4688.8 && (fps = (9640 + -6013 * -1 + 26 * -602) / Globals['Frametime'](), last_update = _5349765);
        var _4953783 = _3050479 + ' | delay: ' + _4248115 + ' | fps: ' + Math['round'](fps) + ' | tick: ' + _4598539,
            _5998224 = Render['TextSizeCustom'](_4953783, _3621139)[1 * -5029 + 1 * -6469 + -11498 * -1] + (1033 * 9 + -1 * 6221 + -3071),
            _2448774 = Global['GetScreenSize']()[1063 * -3 + -97 * -1 + 3092],
            _15675000 = -(-5345 + 6738 + -1385);
        Render['FilledRect'](_2448774 - (9849 + 67 * -91 + 7 * -526) - _5998224, _15675000 + (1 * 3693 + 3 * 599 + -5454), _5998224 + (-7 * 923 + 3188 + -50 * -66), -1 * 3782 + -16 * 149 + 6192, [3425 + -9 * 591 + 1939, 4702 + 1261 * -2 + -2132, -4503 + 29 * 313 + -1 * 4519, -2519 + 2 * 4177 + 62 * -90]), Render['FilledRect'](_2448774 - (2344 + 1 * -2735 + 462) - _5998224, _15675000 + (-1 * 6002 + -748 + 6787), _5998224 + (-7093 + -3 * -2297 + -21 * -11), 107 * -28 + -8269 + 11289, [-2994 + -5101 + 8140, 861 + 8587 * 1 + -4700 * 2, -185 * 21 + 6053 + -2113 * 1, -3 * -1394 + 849 * -6 + -1 * -1167]), Render['Rect'](_2448774 - (-1258 * -2 + 5562 * -1 + 3100) - _5998224, _15675000 + (-48 * 18 + -4459 + 23 * 233), _5998224 + (1877 + -1279 * -4 + -6983 * 1), -40 + 743 * -5 + -16 * -235, [9742 * 1 + 1435 + -11177, 44 * -74 + 8186 * -1 + -3814 * -3, 10 * 310 + -9270 + 6170, -6647 + 23 * 211 + 2049]), Render['StringCustom'](_2448774 - (-202 * -33 + 3379 + -10000) - _5998224, _15675000 + (76 * 94 + 4950 + -12051), -1 * -2434 + -19 * 382 + 4824, _4953783, [-23 * 163 + -5831 * -1 + -87 * 21, 8843 * -1 + -4794 + 1 * 13892, -4282 + -1424 + -1987 * -3, 99 * -62 + -59 * -103 + 316], _3621139), underglow && (pulsate ? Render['GradientRect'](_2448774 - (10 * -732 + -5993 + 13367) - _5998224, _15675000 + (-3 * 2446 + 4887 + 2488), _5998224 + (4196 * -1 + 1045 + -1 * -3161), 6212 + -2 * -2581 + -11363, -184 * 26 + 7746 * 1 + -2962, rainbowmenu ? [colors['r'], colors['g'], colors['b'], Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((1 * 9845 + -6398 + -3446 * 1) / (9445 + 6422 + -15866.5)) % (Math['PI'] * (-361 * 6 + -6354 + 8522)))) * (-1 * 7034 + -1551 + 8840)] : [color[2310 + 6898 * -1 + 4588], color[1221 * 7 + 4 * 676 + 50 * -225], color[28 * -45 + -2136 + 2 * 1699], Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((-2485 + -4360 + 326 * 21) / (-5669 + -349 + 6018.5)) % (Math['PI'] * (-7218 + 121 * 81 + -2581)))) * (6123 + -5933 + 65)], [4189 * 1 + 8947 + -13136, 8637 + -1 * 9557 + 92 * 10, 2036 + -2491 * 2 + 3 * 982, 5955 + 2781 * -2 + -393]) : Render['GradientRect'](_2448774 - (-4933 + -2 * -981 + -605 * -5) - _5998224, _15675000 + (-7 * -356 + -3 * 1906 + -251 * -13), _5998224 + (-158 * 53 + -2 * 3040 + 452 * 32), -9468 + -1 * 6726 + 16205, -9144 + 106 * -33 + -12642 * -1, rainbowmenu ? [colors['r'], colors['g'], colors['b'], 801 + 8899 + -5 * 1889] : [color[7 * 1413 + 7720 + -17611], color[5 * 431 + -2783 * 1 + 37 * 17], color[-679 + 3503 + -2822], 1 * 2085 + -8106 + -3 * -2092], [555 + -1 * -7076 + -7631, -8103 + 1 * -5853 + 13956, -8108 + -13 * -5 + 21 * 383, -9316 * 1 + 340 + 17 * 528])), Render['GradientRect'](_2448774 - (1 * 4471 + 1 * -7972 + 15 * 237) - _5998224, _15675000 + (7554 + 3752 + 1127 * -10), _5998224 + (1 * 2894 + -4 * -1003 + -6896), -612 * 1 + -1402 + 1 * 2018, 7291 + -2490 + -4800, rainbowmenu ? [colors['r'] * (6853 + -7662 * 1 + 809.75), colors['g'] * (2714 + -4834 * -1 + -7547.25), colors['b'] * (-2941 * 1 + -2 * -3023 + -3104.25), -9051 + 8773 + -41 * -13] : [color[1 * -1319 + -1 * 1327 + 63 * 42] * (1 * -4285 + -509 * 10 + 9375.75), color[-1129 * -4 + -3993 + -522] * (7568 + -4442 + -3125.25), color[-4416 + 1 * 6421 + -2003] * (-748 * -5 + 22 * 350 + -11439.25), -7121 + 9574 + 2198 * -1], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[-4555 + -3 * 1029 + 7645]] : color), Render['GradientRect'](_2448774 - (5902 + -1413 + -4434) - _5998224, _15675000 + (2811 + 3 * 295 + -3659), _5998224 + (-665 * 15 + 9625 + -2 * -181), -7884 + -167 * -23 + 4045, -7571 * -1 + 2554 * -2 + -1231 * 2, rainbowmenu ? [colors['r'] * (4006 + -7 * 539 + -232.25), colors['g'] * (-4759 * -2 + -3 * -361 + -10600.25), colors['b'] * (9103 + 7439 + -16541.25), -2570 + -1003 + -1276 * -3] : [color[-44 * -149 + 267 + -6823 * 1] * (1 * -2859 + 3646 + -786.25), color[-7545 + 5033 * -1 + -21 * -599] * (-2441 * -2 + 7719 + -12600.25), color[9578 + -862 * 11 + -1 * 94] * (14 * -390 + 665 + 4795.75), 3518 * -2 + 4459 + 2832], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[7968 + 286 + -8251]] : color), bettercircle(_2448774 - (-1722 + 8606 + -6814) - _5998224, _15675000 + (-7043 + 3899 + 3194), -9532 + 9643 + -90, rainbowmenu ? [colors['r'], colors['g'], colors['b'], 124 * 7 + -149 * 1 + -464] : [color[8759 + -7980 + -779], color[944 + 9666 + -103 * 103], color[-1035 * -1 + -2697 + 1664], -1 * 4133 + 4294 + 94]), bettercircle(_2448774 - (-3454 + -3976 + 7500) - _5998224, _15675000 + (1 * -5707 + 9215 + 38 * -91), -2 * -331 + -1 * 3115 + -1 * -2473, [1 * -5899 + 1 * -5513 + 1273 * 9, -7225 * -1 + 2 * 2434 + -12045, -4713 + 4609 * -2 + 13986, -359 * 27 + 7845 + 701 * 3]), Render['StringCustom'](_2448774 - (6463 + -7274 + 889.5) - _5998224, _15675000 + (-3273 + -7009 * -1 + -3702), 9777 + -2 * 2179 + -5419, 'D', rainbowmenu ? [colors['r'], colors['g'], colors['b'], -9317 + -1 * -4995 + 4577] : [color[-2 * -92 + -3103 + -139 * -21], color[-2621 * 3 + 3 * 2783 + -5 * 97], color[-189 + -3 * -2797 + 2050 * -4], 2352 + -1077 * -2 + 1 * -4251], _1178285);
    }
    if (rainbowline) Render['GradientRect'](-6889 * 1 + 1565 + -5324 * -1, 2321 * 1 + 4577 + -6898, Global['GetScreenSize']()[-9301 + 1 * 4781 + 4520], -1961 + 4364 + -25 * 96, -4187 + -1119 + 5307, [colors['g'], colors['b'], colors['r'], -9991 + -973 + -13 * -863], [colors['r'], colors['g'], colors['b'], -2951 + 7627 + 4421 * -1]);
    var _5604378 = Entity['GetName'](Entity['GetWeapon'](Entity['GetLocalPlayer']()));
    if (keybindlist) {
        keybindpos = moveElementkey(keybindpos, 552 * -6 + 4252 * 2 + -93 * 54, -3110 + 6943 * 1 + 1 * -3803);
        var _514256 = -333 + 283 * 3 + -516,
            _1762337 = 17 * 133 + -1685 + -501,
            _4973439 = [];
        UI['IsHotkeyActive']('Misc', 'JAVASCRIPT', 'Script items', 'Teleport key') && tponpeek && _4973439['push']('Teleport');
        (UI['IsHotkeyActive']('Misc', 'GENERAL', 'Movement', 'Auto peek') && UI['GetValue']('Misc', 'GENERAL', 'Movement', 'Auto peek') || UI['IsHotkeyActive']('Script items', 'Auto peek key') && autopeek) && _4973439['push']('Auto peek');
        UI['IsHotkeyActive']('Misc', 'JAVASCRIPT', 'Script items', 'Minimum damage key') && mindmg && _4973439['push']('Damage override');
        UI['IsHotkeyActive']('Rage', 'GENERAL', 'Resolver override') && _4973439['push']('Resolver override');
        safeawp && _5604378 == 'awp' && _4973439['push']('Safe awp');
        UI['IsHotkeyActive']('Rage', 'GENERAL', 'Force body aim') && _4973439['push']('Force baim');
        UI['IsHotkeyActive']('Rage', 'GENERAL', 'Force safe point') && _4973439['push']('Safe point');
        UI['IsHotkeyActive']('Anti-Aim', 'Extra', 'Fake duck') && _4973439['push']('Fake duck');
        UI['IsHotkeyActive']('Rage', 'Exploits', 'Doubletap') && UI['GetValue']('Rage', 'Exploits', 'Doubletap') && _4973439['push']('Doubletap');
        UI['IsHotkeyActive']('Rage', 'Exploits', 'Hide shots') && UI['GetValue']('Rage', 'Exploits', 'Hide shots') && _4973439['push']('Hide shots');
        UI['IsHotkeyActive']('Anti-Aim', 'Fake angles', 'Inverter') && _4973439['push']('Inverted');
        UI['IsHotkeyActive']('Anti-Aim', 'Extra', 'Slow walk') && _4973439['push']('Slow walk');
        for (_2599962 = 4229 + 1 * -5587 + 2 * 679; _2599962 < _4973439['length']; _2599962++) {
            Render['TextSize'](_4973439[_2599962])[7076 + 205 * 5 + -8101] > _514256 && (_514256 = Render['TextSize'](_4973439[_2599962])[-7673 + 87 + 2 * 3793]);
        }
        if (_514256 == 1351 + -71 * 1 + 1 * -1280) _514256 = 1198 * -1 + 136 * -8 + -292 * -8;
        _1762337 = _1762337 + _514256;
        (Entity['IsAlive'](plocal) || UI['IsMenuOpen']()) && ((_4973439 != -1370 + -1207 * -1 + 163 || UI['IsMenuOpen']()) && (Render['Rect'](keybindpos[1 * -5242 + 7248 + -2006] - (2805 + 2 * -2408 + -33 * -61), keybindpos[8648 + -2105 * -4 + 1 * -17067], _1762337, -77 * 47 + 1639 * -1 + 5265, [4 * -1469 + 8154 + -2278, -3985 + -5858 + 9843, 1 * 3427 + -9 * -73 + -4084, -38 * 165 + 1723 * 2 + 3079]), Render['FilledRect'](keybindpos[-9999 + 1723 + 8276], keybindpos[6177 + 9553 + -15729], _1762337 - (-329 * 1 + -1 * -3827 + -1165 * 3), 4586 + -2932 + -1624, [683 * -3 + -3833 * -1 + -37 * 47, 809 * -9 + -4811 * -2 + -1 * 2293, 375 * -3 + 4423 * -1 + 13 * 431, 3149 + 2549 * 1 + -1 * 5443]), Render['FilledRect'](keybindpos[-2142 + 5058 + -2916] - (12 * -382 + -7961 + 12546), keybindpos[1 * 2347 + -3011 + 95 * 7] + (16 * 582 + -1 * -7513 + -16824), _1762337 - (-565 + -7627 + 3 * 2731), -2414 + -1039 * 2 + 4520, [-5660 + 3391 + 2314, -2 * 2228 + -1 * -5309 + -805, 173 * 47 + -70 + -2 * 4003, 139 * 2 + -8920 + 8897]), Render['StringCustom'](keybindpos[-9397 * -1 + 882 * -5 + 1 * -4987] + _514256 / (2195 * -1 + -1 * 4395 + 6592) - (-9014 + 13 * 683 + 138), keybindpos[4 * 1846 + -1711 + -5672] + (9585 + -2040 + 11 * -685), 8612 + 4390 + -13002, ' Keybinds (' + _4973439['length'] + ')', [9067 + -953 * -3 + -11671, 8107 * 1 + -6849 * 1 + -1 * 1003, -9572 * -1 + -6801 + 37 * -68, -4783 + 1 * 3176 + 1862], 9470 + 3231 + -12694), underglow && (pulsate ? Render['GradientRect'](keybindpos[51 * 157 + -57 * 101 + -2250] - (-2 * -3974 + 107 * 41 + 4111 * -3), keybindpos[4045 + 4158 * -2 + 4272] + (-8 * 655 + -7962 + 1 * 13205), _1762337, 2822 + 7671 + -10482, -5833 + 4961 * 1 + 4 * 218, rainbowmenu ? [colors['r'], colors['g'], colors['b'], Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((-6264 + 7097 + -26 * 32) / (-3 * -2570 + 5158 + -12867.5)) % (Math['PI'] * (-1626 + 4969 + -3341)))) * (7877 * -1 + -3013 + 743 * 15)] : [color[-1 * 5042 + -2451 + 7493], color[-10 * -459 + 3301 + 5 * -1578], color[2045 + 4658 + 6701 * -1], Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((8629 + 1412 + -10040) / (27 * 155 + 71 * 19 + -5533.5)) % (Math['PI'] * (-544 * 1 + -5823 * 1 + 6369)))) * (-1348 * 2 + -811 * 1 + 3762)], [2958 + -3484 + 526, 8844 + -6223 + 2621 * -1, 9437 + -6169 + -4 * 817, -17 * 190 + -8357 * 1 + 11587]) : Render['GradientRect'](keybindpos[6371 + -9507 + 3136] - (27 * 53 + -389 * -18 + -1 * 8431), keybindpos[-9509 + 1398 + 8112] + (7791 + -3964 + -4 * 956), _1762337, -1289 + 588 + 712, 8446 + 3557 * 1 + 4001 * -3, rainbowmenu ? [colors['r'], colors['g'], colors['b'], -1409 + -66 * -9 + 1070] : [color[-631 * 1 + -1943 + -22 * -117], color[-4735 + 37 * 102 + 962], color[6141 + 2393 + -8532], -6612 + -12 * -755 + -2193 * 1], [7519 + -9646 + 2127, 1 * -5431 + -1 * 3701 + 1 * 9132, -11 * -797 + 1 * 8956 + -17723, 995 + 1 * 2411 + -3406])), Render['GradientRect'](keybindpos[-2 * 691 + 424 + 2 * 479] - (1 * -3624 + -213 * -8 + 1922), keybindpos[303 * 17 + -7 * -975 + -11975], _1762337, 2927 * 3 + 4994 * 1 + -13769, -1 * -2173 + -964 + -1208, rainbowmenu ? [colors['r'] * (3216 + 43 * -103 + 1213.75), colors['g'] * (1 * 2284 + -2 * 4907 + 7530.75), colors['b'] * (9056 + -5041 + -4014.25), -14 * -90 + 5523 + 544 * -12] : [color[1686 + 2976 + -4662] * (-490 + 2289 + -1798.25), color[323 * -29 + 2056 * -1 + 136 * 84] * (17 * -419 + -1 * -1326 + 5797.75), color[-914 * 5 + 6637 + 59 * -35] * (477 + 9551 + -10027.25), 1 * -4127 + -4127 + 8509], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[-7946 + -5753 + 13702]] : color), Render['GradientRect'](keybindpos[-2208 + -4031 + 6239] - (-5245 + -8557 + -11 * -1255), keybindpos[-1 * 3642 + 2 * -3349 + 3447 * 3] + (2 * -1454 + -6003 + 8912), _1762337 + (-5010 + 7200 + 1094 * -2), 551 * 2 + -1 * -4253 + 1 * -5351, 7845 + -8759 + 1 * 915, rainbowmenu ? [colors['r'] * (-70 * 13 + 5 * -302 + 2420.75), colors['g'] * (854 + 574 + -1427.25), colors['b'] * (-8504 + -2102 * 1 + 10606.75), 311 * -3 + -1515 * -5 + -1 * 6387] : [color[-6594 + -73 * 8 + -2 * -3589] * (1310 + 3571 + -4880.25), color[-1439 + -1677 * -3 + -3591] * (9455 + 5 * -400 + -7454.25), color[2092 + -4517 + -1 * -2427] * (7662 + 4742 + -12403.25), 714 + -7532 + -1 * -7073], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[7916 * 1 + -8 * -286 + -10201]] : color)));
        (Entity['IsAlive'](plocal) || UI['IsMenuOpen']()) && (_4973439 != 241 * -29 + 3713 + 3276 && (Render['FilledRect'](keybindpos[-514 * 4 + -5890 + 274 * 29], keybindpos[8870 + 2 * 29 + -1 * 8927] + (9281 + -4981 + -5 * 853), _1762337 - (1 * 2663 + 3592 + -6252), (-1 * 2425 + -751 * 2 + 3942) * _4973439['length'] + (-4 * -1061 + 98 * 55 + -9627), [5726 + -359 * 3 + -4604, -6625 * 1 + -1 * -2382 + 7 * 613, 3669 + -4 * 358 + -2 * 1091, 557 * 10 + 8764 + 1 * -14079]), Render['FilledRect'](keybindpos[-512 * 17 + -6321 + 15025] - (1 * 9469 + -2 * 2968 + -3532), keybindpos[-3259 + -8342 + 5801 * 2] + (-2265 + 1399 + 902), _1762337 - (-13 * 39 + 1477 + -3 * 323), (-9607 + -6693 + 16315) * _4973439['length'] + (1 * -7292 + 143 * -41 + 329 * 40), [8842 + -1 * 3889 + -4908, 9286 + -2142 + -7096, -107 * -11 + -8221 * -1 + 1 * -9343, 144 * 27 + -1050 + -2583])));
        for (_2599962 = -1912 + -22 * 37 + -1 * -2726; _2599962 < _4973439['length']; _2599962++) {
            (Entity['IsAlive'](plocal) || UI['IsMenuOpen']()) && Render['String'](keybindpos[2443 + -4943 + -625 * -4] + (9726 + -32 * -149 + 51 * -284), keybindpos[-2324 * -1 + -6158 + 3835] + (1769 + -8747 + 7019) + (-1 * 2127 + -8954 + 11096) * _2599962, 2179 + -6852 + -1 * -4673, _4973439[_2599962], [-6365 + -24 * 95 + -4450 * -2, -5189 + -3814 * -1 + 163 * 10, 208 + 7822 * 1 + -25 * 311, 65 * -33 + 4694 + -2294], -4 * 1909 + -5177 * -1 + 1 * 2467);
        }
        UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'keybinds list x', keybindpos[-7022 + 927 * 1 + 6095]), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'keybinds list y', keybindpos[1579 * -1 + 197 * -25 + 6505]);
    }
    var _3946263 = Entity['GetPlayers'](),
        _2475541 = Entity['GetTeammates'](),
        _1054851 = Entity['GetLocalPlayer']();
    local_dead = ![];
    var _3621475 = [];
    n_localobservers = [], n_local_obs = [];
    if (plocal) {
        for (_2599962 = _3946263['length'] - (146 * 43 + -1030 + -5247); _2599962 >= -1 * 6918 + -8774 * -1 + -4 * 464; _2599962--) {
            if (_3946263[_2599962] == _1054851 || Entity['GetName'](_3946263[_2599962])['toString']()['localeCompare']('GOTV') == 845 + -7529 * -1 + -106 * 79) _3946263['splice'](_2599962, -278 * 18 + -7246 + 12251);
        }
        for (_2599962 = _2475541['length'] - (-6085 * -1 + 2587 + -8671); _2599962 >= -8696 + -6824 + 15520; _2599962--) {
            if (_2475541[_2599962] == _1054851 || Entity['GetName'](_2475541[_2599962])['toString']()['localeCompare']('GOTV') == -8230 + -3791 + 1 * 12021) _2475541['splice'](_2599962, 8969 + 6945 + -15913);
        }
        for (_2599962 = 475 * -8 + 2682 + 1118; _2599962 < _3946263['length']; _2599962++) {
            if (!_3946263[_2599962] || Entity['IsDormant'](_3946263[_2599962])) continue;
            var _3910732 = Entity['GetProp'](_3946263[_2599962], 'DT_BasePlayer', 'm_hObserverTarget');
            if (!_3910732) continue;
            local_dead = ![], _3910732 == _1054851 && n_localobservers['push'](Entity['GetName'](_3946263[_2599962]));
        }
        localobservers = n_localobservers;
    }
    if (speclist) {
        specpos = moveElementspec(specpos, 732 + 6297 + -6859 * 1, 4435 + -7 * 656 + 187);
        if (local_dead) total_spec = n_local_obs['length'] + _3621475['length'];
        else total_spec = localobservers['length'];
        Entity['IsAlive'](plocal) && (localobservers != 1 * 3691 + 8996 + -1 * 12687 && (Render['FilledRect'](specpos[-3 * -1436 + -199 * 31 + 1861], specpos[-7603 + 5407 + 2197] + (6207 * 1 + -7390 * -1 + -13562), 930 + -9091 * -1 + 1 * -9851, (-3686 + -4506 + 1 * 8207) * localobservers['length'] + (5816 + 8519 + -3582 * 4), [1957 * -1 + 1341 * -3 + -1 * -6025, 1 * -8345 + -6421 + 14814, -197 * 25 + -6739 + 11719, -5881 + -1621 * -1 + -1 * -4515]), Render['FilledRect'](specpos[-9344 + 7267 + 2077] - (1030 + 87 * -61 + -62 * -69), specpos[2 * -2452 + 1400 + -1 * -3505] + (2204 + 167 * -12 + -1 * 164), -361 * -26 + 481 * -1 + -8733, (-347 * 2 + -5104 + -1 * -5813) * localobservers['length'] + (3972 * 1 + -7223 + 3256), [9191 + -9885 + 739 * 1, -1368 + -5 * -1191 + 267 * -17, 7298 + -6076 + 389 * -3, -8248 + -1 * -1493 + 7010])));
        if (!total_spec == 6182 * 1 + -1729 + -1 * 4453 || UI['IsMenuOpen']()) {
            spec_count = -1 * 6229 + 4614 + 95 * 17, Render['FilledRect'](specpos[-40 * -225 + -1717 * -4 + 4 * -3967], specpos[144 * -66 + 4294 + 5211], 7 * -523 + -110 * 2 + 4051 * 1, -8344 + 7107 + 1267, [13 * 379 + 117 * 28 + 8158 * -1, -29 * 51 + -1495 + 3022, 7348 + 6097 + -13390, -1 * -8157 + -821 * 1 + 7081 * -1]), Render['FilledRect'](specpos[-4842 + -407 * 3 + 6063] - (-8150 + 5 * -1942 + -1 * -17861), specpos[-1480 + -2 * -2633 + -3785 * 1] + (-1 * -543 + -3868 + 3326 * 1), -8389 + -6000 + 1 * 14561, -8123 + 787 * 11 + -506, [3934 + 2638 * -3 + 4025, -4836 + -9765 + 19 * 771, -287 * 23 + 195 + -497 * -13, -2 * 2617 + -7113 * 1 + 12602]), Render['Rect'](specpos[1 * 2495 + -944 * -6 + 1 * -8159] - (-6 * -106 + 1 * -1115 + -37 * -13), specpos[1516 + 248 * -10 + 5 * 193], -4288 + -6834 + 11295, 6855 + -162 + -6686, [23 * 393 + -2518 + 1 * -6521, 823 * 1 + -1 * -9526 + -10349, 383 * -1 + 2 * -2052 + 4487, -4901 + -1 * 7717 + 12873]), Render['StringCustom'](specpos[151 * 66 + 9364 + -19330] + (2242 + 8811 + 3670 * -3), specpos[-8035 + -16 * -256 + -394 * -10] + (3641 + -8427 * 1 + -4 * -1199), 5 * 881 + 2 * 4456 + -13317, ' Spectators (' + localobservers['length'] + ')', [2640 + 4241 * -1 + -464 * -4, 1 * 41 + -8925 + 703 * 13, 9193 + 8811 * -1 + -1 * 127, 4294 + 4629 + 22 * -394], -7454 + 848 + -1 * -6613);
            underglow && (pulsate ? Render['GradientRect'](specpos[32 * -239 + 9489 * -1 + 17137] - (8089 + 5584 + 1 * -13671), specpos[-4319 + 2992 + 1328] + (-8072 + 1 * 6252 + 1823 * 1), -29 * 329 + -137 * 61 + 18071, 9096 + -9639 + 554, 414 * -12 + -7 * -155 + 353 * 11, rainbowmenu ? [colors['r'], colors['g'], colors['b'], Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((-10 * -757 + 7 * -563 + -3628) / (103 * 63 + 2956 + -9444.5)) % (Math['PI'] * (3893 + -2231 + -1660)))) * (-1325 + -1 * 1342 + 1461 * 2)] : [color[-1 * 1466 + 2927 * -1 + 4393], color[2418 + -4729 * -2 + -1 * 11875], color[-1460 + -101 * 67 + 8229], Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((5394 + -1234 * -1 + -6627) / (-5078 + -932 + 6010.5)) % (Math['PI'] * (1778 + -914 * -5 + -6346)))) * (9 * 794 + 9498 * 1 + -16389)], [-2899 * 1 + 687 + 2212, 4 * -207 + -2526 + 86 * 39, -1313 * 5 + 2948 + -1 * -3617, 1 * 2401 + -1 * -3031 + 2716 * -2]) : Render['GradientRect'](specpos[-7186 + 1 * -4237 + 11423] - (-41 * -29 + -1248 + 61), specpos[3012 + 7965 + 112 * -98] + (-47 * 25 + 8424 + -7246), -129 * 1 + 9 * -249 + 2543 * 1, -1 * 7014 + 7236 + 1 * -211, 3691 + 5633 + 9324 * -1, rainbowmenu ? [colors['r'], colors['g'], colors['b'], 3899 * 2 + -8657 + 2 * 557] : [color[1 * -81 + -2884 + 2965], color[2053 + 8 * -1146 + -4 * -1779], color[6403 + -23 * -1 + -6424], 28 * 189 + -1 * 9887 + 4850], [5228 + -4029 * 1 + -1199, 4933 + 8855 + -6894 * 2, -4181 * -2 + -2058 + -6304, -44 * -82 + 145 * 67 + -13323]));
            Render['GradientRect'](specpos[9941 + 4 * 294 + -11117] - (-1477 + 18 * -49 + 3 * 787), specpos[-8194 + -4910 + 13105], -3433 * 1 + -2449 + 35 * 173, -1 * 9767 + -1 * 2374 + 12147, 11 * 422 + 5710 * 1 + -10351, rainbowmenu ? [colors['r'] * (578 * -6 + 3297 * 3 + -6422.25), colors['g'] * (29 * -110 + -59 * -4 + 2954.75), colors['b'] * (7755 + 1 * -4657 + -3097.25), -829 + 8897 + -7813 * 1] : [color[8670 + -5935 + 2735 * -1] * (279 * 11 + 1 * 3590 + -6658.25), color[-907 + 4 * -1087 + 2 * 2628] * (-5851 + 573 * 9 + 694.75), color[2983 + 3220 + -6201] * (-9764 + -7479 + 17243.75), -5539 * -1 + 9209 * -1 + 3925], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[0 + -724 * 8 + 5795]] : color), Render['GradientRect'](specpos[-2894 + 5563 * -1 + -8457 * -1] - (-7316 + -7122 + -2063 * -7), specpos[-9058 + -7981 + 48 * 355] + (-4457 + 3170 + 8 * 161), 6362 + -19 * -450 + 1 * -14737, -14 * 371 + -274 * 16 + 4791 * 2, -2 * -4907 + -7332 + -2481, rainbowmenu ? [colors['r'] * (-3202 + -886 * -6 + -2113.25), colors['g'] * (2014 + -3547 + 1533.75), colors['b'] * (6672 + -6953 + 281.75), 1 * 4889 + -1339 * 1 + -3295] : [color[-5461 + 1 * 9559 + 2 * -2049] * (-9761 + 4 * -1000 + 13761.75), color[-2 * -832 + -1892 + 229] * (-3 * -717 + -6826 + 4675.75), color[-5547 * 1 + -251 * 37 + -3709 * -4] * (8 * -208 + -2426 * -2 + -3187.25), -1 * -3707 + 1 * 9287 + 12739 * -1], rainbowmenu ? [colors['r'], colors['g'], colors['b'], color[-177 * -26 + 1 * 108 + 1569 * -3]] : color);
            if (!local_dead)
                for (_2599962 = -1581 * -6 + 1237 * -2 + -7012; _2599962 < localobservers['length']; _2599962++) {
                    Render['String'](specpos[-5120 * -1 + 7384 * 1 + -12504] + (8177 + 5476 + 13643 * -1), specpos[3988 + -11 * -547 + -10004] + (-2137 + -9171 + 11349) + (-2592 + 1048 + -1 * -1559) * spec_count, 6263 * 1 + 6515 * 1 + 1 * -12778, localobservers[_2599962], [6807 + 4167 + 1191 * -9, -9394 + -9016 + -5 * -3733, 9701 + -41 * -201 + -17687, 3 * 669 + -1 * 9201 + 7449], -5567 + -4301 * 1 + 6 * 1646), spec_count++;
                }
            UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'spectator list x', specpos[-4695 + -43 * 91 + -4 * -2152]), UI['SetValue']('Misc', 'JAVASCRIPT', 'Script items', 'spectator list y', specpos[882 * -1 + -1 * 5983 + 6866]);
        }
    }
    if (weaponicons) {
        plr = Entity['GetPlayers']();
        for (_2599962 = -1808 + -1299 * -5 + -4687 * 1; _2599962 < plr['length']; _2599962++) {
            if (Entity['IsEnemy'](plr[_2599962]) && Entity['IsAlive'](plr[_2599962]) && !Entity['IsDormant'](plr[_2599962])) {
                pothing = Entity['GetRenderBox'](plr[_2599962]), playerWeapon = Entity['GetName'](Entity['GetWeapon'](plr[_2599962]));
                if (pothing[1799 + -4342 + -1 * -2543] == 1 * 4548 + 4517 + -9064) {
                    var _2327934 = pothing[1427 + 5066 + -649 * 10] - pothing[-7759 + -8867 * 1 + -16627 * -1];
                    _2327934 /= 3399 + 8612 * -1 + 5215, _2327934 += pothing[-1532 + 5297 + -3764], render_string(_2327934 + (526 + 2069 + 2 * -1297) * (-1 * 84 + -5141 + 5225.75), pothing[798 * 8 + -8963 + 123 * 21] + (1 * 1942 + 7199 + -9131), -2890 + -15 * 112 + 4571 * 1, weapon_to_icon(playerWeapon), [espcolor[-7 * 313 + 2 * -1553 + 5297 * 1], espcolor[4358 + 782 + -5139], espcolor[-8442 * -1 + 8828 * 1 + -5756 * 3], 2262 + 1 * -1481 + -526], -8542 + 2999 * -1 + 11547);
                }
            }
        }
    }
    if (legacykill) {
        var _3621139 = Render['AddFont']('', 8622 + -6959 + -1 * 1631, 32 * 139 + 1159 * -7 + -1405 * -3);
        for (_2599962 in effects) {
            if (!effects[_2599962][-4347 + -4136 * 1 + 8483]) continue;
            if (animatedindicators && !staticcolor) Render['StringCustom'](effects[_2599962][-3273 + 7161 + 3 * -1295], effects[_2599962][-41 * 13 + -7166 + -7703 * -1], -1237 + 7986 + -6748, effects[_2599962][4690 + 9581 + -201 * 71] + '', [effects[_2599962][-9206 * -1 + -4164 + -1 * 5033][-6396 + -8149 + 14545], effects[_2599962][273 + -883 + 619 * 1][5379 + 4158 + -9536], effects[_2599962][25 * -142 + -89 * 73 + 10056][-2429 + 8619 + -6188], effects[_2599962][8122 + 3826 + 13 * -919]], _3621139);
            else {
                if (!animatedindicators && !staticcolor) {
                    if (kills == 1 * 7807 + 4014 + 1 * -11820) Render['StringCustom'](Render['GetScreenSize']()[432 + -1 * 4059 + 1 * 3627] / (-605 + 1152 + 1 * -545), 1 * 9689 + 2633 * 2 + 173 * -85, -1458 + 37 * -247 + 10598, 'FIRST BLOOD', [effects[_2599962][8766 + 6888 * -1 + 7 * -267][5708 + -9 * -251 + 257 * -31], effects[_2599962][-4598 + 2299 * 1 + 2308][-7937 + 14 * -530 + 15358], effects[_2599962][4833 + -10 * -431 + -9134][-9171 + -9719 * -1 + 39 * -14], effects[_2599962][8294 + 35 * -250 + -457 * -1]], _3621139);
                    else {
                        if (kills == -1371 + 9877 + 4252 * -2) Render['StringCustom'](Render['GetScreenSize']()[1 * 8555 + 3595 + 6075 * -2] / (-53 * -79 + 8154 + 457 * -27), -239 * -27 + 5471 * 1 + -11674, 9780 + 5 * -805 + 7 * -822, 'DOUBLE KILL', [effects[_2599962][-2 * 3734 + -5849 + 13326][-4846 + 4476 + -74 * -5], effects[_2599962][-1 * 7141 + 999 + 6151][1 * -6565 + -2098 + 8664], effects[_2599962][724 + -1534 + 819][67 * 65 + -10 * 334 + 1013 * -1], effects[_2599962][-8427 * -1 + -1 * -8521 + -269 * 63]], _3621139);
                        else {
                            if (kills == 1 * 9743 + 5536 + -15276) Render['StringCustom'](Render['GetScreenSize']()[5460 + 2 * 4415 + 10 * -1429] / (-2562 + 5464 + 116 * -25), 841 + -1 * -3877 + -4468, -501 + -2854 * -2 + -5206, 'MULTI KILL', [effects[_2599962][7323 + -41 * 163 + -631][-3 * 1 + -15 * 569 + 8538], effects[_2599962][-223 * 39 + -7257 + 15963][-2235 * 1 + -4 * -566 + -4 * 7], effects[_2599962][-2746 + 8015 * 1 + -2630 * 2][1 * -4455 + -3 * 3266 + 14255], effects[_2599962][-1 * 6078 + 5955 + 124]], _3621139);
                            else {
                                if (kills == 387 + 843 + -1226) Render['StringCustom'](Render['GetScreenSize']()[6249 + 9965 + -16214] / (-2962 + -2 * 2329 + 7622), 0 + -19 * -82 + -1308, 9838 + 497 * 3 + 59 * -192, 'ULTRA KILL', [effects[_2599962][-2 * 3561 + 7649 + -7 * 74][1 * 71 + 9774 + -11 * 895], effects[_2599962][-7492 + 1 * 6133 + 12 * 114][-2878 + 7964 * -1 + -7 * -1549], effects[_2599962][6121 + 2417 + 3 * -2843][-2 * -4657 + -6661 + -2651], effects[_2599962][1647 * 1 + 14 * -502 + 5382]], _3621139);
                                else {
                                    if (kills == 1 * -1798 + 1253 + 550) Render['StringCustom'](Render['GetScreenSize']()[16 * -324 + 3038 + -37 * -58] / (-6564 + -2657 * -3 + 5 * -281), 416 + -4024 + -3858 * -1, -3328 + 8 * -437 + 325 * 21, 'PENTA KILL', [effects[_2599962][-7915 + 3598 + 2 * 2163][13 * 282 + 3 * 233 + -4365], effects[_2599962][5 * -227 + 9667 + -8523 * 1][1535 * 1 + -3 * 303 + -625], effects[_2599962][1 * 9957 + 5158 + -15106][-2480 + -7200 + -47 * -206], effects[_2599962][-26 * -179 + 30 * -90 + -1953]], _3621139);
                                    else {
                                        if (kills == 9506 + -9498 + 1 * -2) Render['StringCustom'](Render['GetScreenSize']()[-1398 * -1 + -9365 + 7967] / (-4250 + 6 * -1563 + 13630), 977 + 16 * -583 + -3 * -2867, 446 + 9531 + -9976, 'GOD LIKE', [effects[_2599962][3 * -2368 + -223 * 3 + 7782][-2 * -596 + -1451 * 5 + 6063], effects[_2599962][-1 * 629 + -5225 + 143 * 41][8565 + 9457 + 3 * -6007], effects[_2599962][-7127 + -679 * 7 + 3 * 3963][1 * 2978 + -1 * -926 + 3902 * -1], effects[_2599962][-41 * 102 + -8289 + -12472 * -1]], _3621139);
                                        else {
                                            if (kills == -6119 + 7175 + -1049) Render['StringCustom'](Render['GetScreenSize']()[-7893 + -132 * -21 + 569 * 9] / (-3 * -2031 + -5532 + -559 * 1), 6666 + -4668 + -23 * 76, 358 * 4 + -2251 * 1 + 820, 'LUDICROUS', [effects[_2599962][-1 * -5371 + -2247 + -7 * 445][1 * -1089 + 7614 + -6525], effects[_2599962][7451 + 6045 + -13487][-6480 + -365 * 17 + 2 * 6343], effects[_2599962][-1 * 494 + -1 * -6499 + -1499 * 4][-6524 + -740 + 7266], effects[_2599962][-2 * -4852 + 5542 + -15245]], _3621139);
                                            else kills >= -1926 * -2 + 1 * 941 + -2 * 2393 && kills <= -9251 + -1102 * 7 + -3397 * -5 && Render['StringCustom'](Render['GetScreenSize']()[14 * -697 + -8479 + 18237] / (-723 * -11 + -5268 + -1 * 2683), -175 * 6 + -9791 + 11091, 3 * 3141 + -5396 + -4026, 'UNSTOPPABLE', [effects[_2599962][-451 * 22 + -8506 + -18437 * -1][-34 * 98 + -1805 + 5137], effects[_2599962][-8120 + 12 * -3 + -1 * -8165][-7 * -1018 + -554 * -16 + -15989], effects[_2599962][4036 + -1104 * 5 + -1493 * -1][-395 * -3 + 2 * -769 + 355], effects[_2599962][3046 + -5364 + 2319]], _3621139);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (animatedindicators && staticcolor) Render['StringCustom'](effects[_2599962][-95 * 61 + 1 * 2921 + 2877], effects[_2599962][-11 * -5 + -6062 + 6011], 337 * -17 + 6914 + -1184, effects[_2599962][-51 * -44 + -247 * 26 + 1 * 4178] + '', espcolor, _3621139);
            else {
                if (!animatedindicators && staticcolor) {
                    if (kills == 5968 + -304 + -1 * 5663) Render['StringCustom'](Render['GetScreenSize']()[-150 + -11 * 203 + 2383] / (-2340 + -11 * -271 + -639), 9400 + 9256 + -18406, 3360 + 1 * -8905 + 5546, 'FIRST BLOOD', espcolor, _3621139);
                    else {
                        if (kills == -6975 + 3929 * -2 + -129 * -115) Render['StringCustom'](Render['GetScreenSize']()[-4 * -1663 + 348 + -7000] / (-3079 * 1 + 6406 + 133 * -25), -2610 + 2 * -2443 + 7746, 4586 + 2 * -2694 + 803, 'DOUBLE KILL', espcolor, _3621139);
                        else {
                            if (kills == -3939 + 2 * -823 + -2794 * -2) Render['StringCustom'](Render['GetScreenSize']()[4907 * -1 + 448 + 4459] / (9799 + -2142 + 1531 * -5), 2615 * 3 + 9983 + -1034 * 17, -2 * -2657 + -11 * -33 + -5676, 'MULTI KILL', espcolor, _3621139);
                            else {
                                if (kills == 617 * 3 + -3409 + 1562) Render['StringCustom'](Render['GetScreenSize']()[-1 * 2923 + 11 * 458 + -5 * 423] / (2 * 3635 + 30 * 115 + -233 * 46), 4039 + 6871 + -2665 * 4, -5 * -1039 + 7124 * -1 + 1930, 'ULTRA KILL', espcolor, _3621139);
                                else {
                                    if (kills == -5512 + -1823 * 3 + -2 * -5493) Render['StringCustom'](Render['GetScreenSize']()[-7201 + 2151 + 5050] / (-7931 * -1 + 879 + 367 * -24), 1617 * 2 + 845 + -3829, -8 * 88 + 6294 + -1863 * 3, 'PENTA KILL', espcolor, _3621139);
                                    else {
                                        if (kills == -6965 + 2548 + 1 * 4423) Render['StringCustom'](Render['GetScreenSize']()[-4413 + 83 + -10 * -433] / (2157 + 4927 * -1 + -66 * -42), -11 * -223 + -20 * -208 + -6363, 4871 + -3885 * 1 + -985, 'GOD LIKE', espcolor, _3621139);
                                        else {
                                            if (kills == 42 + -13 * -329 + -4312) Render['StringCustom'](Render['GetScreenSize']()[6546 + -3517 + -13 * 233] / (497 + 7271 + -7766), -1549 + -2384 + -47 * -89, -13 * -473 + -6766 + 3 * 206, 'LUDICROUS', espcolor, _3621139);
                                            else kills >= -2278 + -597 * 3 + 4076 && kills <= 3123 + 6174 + 1 * -9277 && Render['StringCustom'](Render['GetScreenSize']()[2877 + -2 * 2177 + 1477] / (-4919 + -1266 + 1 * 6187), 1 * -3305 + -3438 + 999 * 7, 2005 + -3 * 2228 + -780 * -6, 'UNSTOPPABLE', espcolor, _3621139);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            effects[_2599962][2987 + -4479 * 1 + 1495] += Math['sin'](effects[_2599962][2 * 2324 + 2 * -2239 + 1 * -165] / (-11 * -813 + 1699 * 1 + -10462 * 1) * Math['PI']) * Globals['Frametime']() * effects[_2599962][-563 * -3 + -6780 + 5098], effects[_2599962][-17 * 582 + -6803 + 16701] += Math['cos'](effects[_2599962][-4199 + -5948 + 10152] / (-1393 + 1 * 7090 + -9 * 613) * Math['PI']) * Globals['Frametime']() * effects[_2599962][571 * 13 + -1641 * -1 + -3019 * 3], effects[_2599962][5672 + 7561 + -13225] ? (effects[_2599962][8443 * -1 + -2150 + -424 * -25] -= Globals['Frametime']() * (6879 + 8208 + -14887), effects[_2599962][-2 * 3308 + -89 * -103 + -2544] < -4769 * 1 + 3 * 3322 + -19 * 263 && (effects[_2599962][-401 * 21 + 1 * -4603 + 13032] = ![])) : effects[_2599962][-5851 + -43 * -53 + 3 * 1193] += Globals['Frametime']() * (3509 + 8448 + -11657), effects[_2599962][182 * 15 + -1 * 7871 + 1 * 5143] ? (effects[_2599962][3 * -1671 + -8809 * 1 + -23 * -601] += Globals['Frametime']() * (-19 * -7 + 4182 + -5 * 663), effects[_2599962][2 * -3524 + 9221 + -2172] > 7860 + -22 * 159 + -1369 * 3 && effects[_2599962][-3530 + 7833 + -1 * 4297] == -7484 + 8182 + 698 * -1 && (effects[_2599962][-233 * -29 + 227 * 6 + -8118] = -2696 * 1 + 9854 + 117 * -59, effects[_2599962][47 * 34 + -7431 * 1 + 5839] = Globals['Realtime'](), effects[_2599962][-307 + -4146 + 4455] = ![])) : Globals['Realtime']() - effects[_2599962][1 * -6681 + 1203 * 8 + -89 * 33] > -8200 + 3627 + 4575 && (effects[_2599962][-7451 * 1 + 2 * 3290 + 872] -= Globals['Frametime']() * (-2778 + 227 * -11 + 5775), effects[_2599962][-8864 + -10 * 779 + 16655] < 1 * 5489 + 362 + 1 * -5851 && (effects['splice'](_2599962, 65 + -6 * -1452 + -8776), _2599962--));
        }
    }
    if (nameesp) {
        plr = Entity['GetPlayers']();
        for (_2599962 = 149 * -60 + 7 * -103 + -9661 * -1; _2599962 < plr['length']; _2599962++) {
            if (Entity['IsEnemy'](plr[_2599962]) && Entity['IsAlive'](plr[_2599962]) && !Entity['IsDormant'](plr[_2599962])) {
                pothing = Entity['GetRenderBox'](plr[_2599962]), playerName = Entity['GetName'](plr[_2599962]);
                var _3621139 = Render['AddFont']('Verdana', 1 * 3891 + 630 + -4513 * 1, -11 * -28 + -1 * 2043 + 2235);
                const _1715307 = Render['TextSize'](playerName)[-4 * -1346 + -9380 + -27 * -148];
                if (pothing[47 * 19 + 3319 * -1 + 2426] == 9173 + 4927 * -1 + -4245) {
                    var _2327934 = pothing[-930 + -8258 + 9191] - pothing[8765 + -1 * 189 + -8575];
                    _2327934 /= 1993 * 1 + -2 * 3022 + 7 * 579, _2327934 += pothing[-668 + 43 * -178 + 1 * 8323], Render['FilledRect'](_2327934 - (1976 * -3 + -1843 + 1 * 7772) - _1715307 * (2857 + -3 * -2731 + -11049.5), pothing[-127 * 31 + 2 * -3400 + -1 * -10739] - (1 * -5974 + 5000 + 992), _1715307 + (1356 + 1 * -4517 + 3165), -9001 + 1 * -4790 + 493 * 28, [-9143 + -4001 * 1 + -8 * -1643, 9342 + -4 * -86 + -9686, 4 * -797 + 152 * 43 + -3348, 6598 + -32 * 214 + 330]), Render['FilledRect'](_2327934 - (7378 + 6884 * -1 + -493) - _1715307 * (13 * -23 + -5 * -367 + -1535.5), pothing[-8788 + 993 * -1 + 9783 * 1] - (3118 * 1 + 3499 * 2 + -10096), _1715307 + (128 * -46 + 125 * 12 + 4392), -2 * 97 + 3984 + -3788, [espcolor[3161 + -1743 + -1418], espcolor[1 * 4735 + 1 * -830 + -3904], espcolor[-2510 + 1 * 1555 + -11 * -87], 9507 * 1 + 6006 + -15258]), Render['StringCustom'](_2327934 + (194 + 1307 + -1500) * (654 + -2137 + 1485), pothing[-368 * 14 + -2 * 223 + 5600] - (5730 * -1 + 59 * -14 + 6574.5), -6930 + 514 * -18 + 16183, playerName, [-5809 + -6 * 1304 + 13888, 155 * -38 + 4145 + 2000, 1 * 6721 + 9003 + -1 * 15469, -443 * -5 + 6282 + -8242], _3621139);
                }
            }
        }
    }
    if (awpautobuy) run && Globals['Curtime']() + Local['Latency']() / (-9978 + -3914 + 14892) >= estimate && purchase(-7622 + -1 * -2209 + -1 * -5413);
    if (r8hc) {
        hc = UI['GetValue']('Hitchance');
        var _5458680 = onGround(plocal);
        _5458680 ? UI['SetValue']('Rage', 'HEAVY PISTOL', 'Accuracy', 'Hitchance', hc) : UI['SetValue']('Rage', 'HEAVY PISTOL', 'Accuracy', 'Hitchance', heavy_cache);
    }
    if (transparentnade) {
        var _11280010 = {};
        _11280010['flashbang'] = [566 * 14 + 127 * 26 + 211 * -53], _11280010['molotov'] = [-4277 + 3 * 1279 + 486, 5813 + 47 * -164 + 1943], _11280010['smoke'] = [-4 * 2 + -267 * -33 + -8758], _11280010['nade'] = [-162 + 5527 + -313 * 17], nades = _11280010, weapon = Entity['GetProp'](Entity['GetWeapon'](Entity['GetLocalPlayer']()), 'CEconEntity', 'm_iItemDefinitionIndex'), [2843 * -1 + 4509 + -1620, 562 + 5 * -1523 + 1 * 7101, -1654 * -4 + 5051 + -11622 * 1, -6867 + -3119 + 10029, 1 * -1227 + 7 * -401 + 4078]['indexOf'](weapon) < 37 * 97 + -1221 + -2368 ? (UI['SetValue']('Visual', 'SELF', 'Chams', 'Visible transparency', transparency_cache), !UI['GetValue']('Visual', 'SELF', 'Chams', 'Visible override') && (UI['SetValue']('Visual', 'SELF', 'Chams', 'Visible override', !![]), UI['SetValue']('Visual', 'SELF', 'Chams', 'Visible type', -9716 + -3111 + 12839))) : (UI['SetValue']('Visual', 'SELF', 'Chams', 'Visible transparency', blendslider), !UI['GetValue']('Visual', 'SELF', 'Chams', 'Visible override') && UI['SetValue']('Visual', 'SELF', 'Chams', 'Visible transparency', 1220 + -4475 + 3255));
    }
    for (var _2599962 = 11 * -81 + -6843 + 7734; _2599962 < hitlogs['length']; _2599962++) {
        hitlogs[_2599962][-1716 + 7177 * -1 + 1 * 8897]++, damagelog = 'Hit ' + victimName + ' in the ' + hitboxName + ' for ' + damageDone + ' damage (' + healthRemaining + ' health remaining)';
        if (Globals['Curtime']() - hitlogs[_2599962][-3558 + -106 * -47 + -1 * 1417] < 3959 + -4 * 126 + 2 * -1726) continue;
        hitlogs[_2599962][51 * 103 + -8129 + -43 * -67] -= Globals['Frametime']() * (-5495 + -1586 + -7681 * -1), hitlogs[_2599962][-2098 * 1 + -9595 + 11698] < -8821 * 1 + -7402 + 16223 && hitlogs['shift'](_2599962, 2457 + -62 * 157 + 1 * 7278);
    }
    if (hitlog) {
        _4515289 = -2188 + 3661 + -77 * 19, hitlogy = -1424 + 359 * 1 + 1075;
        for (var _2599962 = 6143 + -1 * -5142 + -11285; _2599962 < hitlogs['length']; _2599962++) {
            currentLog = hitlogs[_2599962], victimName = currentLog[942 + 971 * 9 + 3227 * -3], hitboxName = currentLog[14 * -202 + 3 * -3244 + 79 * 159], damageDone = currentLog[3309 * -1 + 2080 + 1231], healthRemaining = currentLog[7345 + 6857 * -1 + -485], poopshartfont = Render['AddFont']('consolas', -1 * -4024 + -356 + -3658, 2598 + 8933 + -11441), curpos = hitlogy + (-4168 * 1 + -1 * -7523 + -3305) * _2599962;
            healthRemaining == 1 * -7727 + -6328 + 14055 ? damagelog = ' Did ' + damageDone + ' damage to ' + victimName + "'s " + hitboxName + ' (KILLED)' : damagelog = ' Did ' + damageDone + ' damage to ' + victimName + "'s " + hitboxName + '\x20(' + healthRemaining + ' hp remaining)';
            var _2034788 = Render['TextSizeCustom'](damagelog, poopshartfont)[-3060 * -1 + 7988 + -11048] + (-252 * -27 + 7783 + -14579 * 1);
            Render['FilledRect'](_4515289 + hitlogs[_2599962][-4449 + -9377 + -13831 * -1] - (6856 + -3435 + -3211), curpos + (33 * 179 + 5528 * -1 + 3 * -125), _2034788 + (-9081 + 3411 + 5680), -2322 + 202 * 27 + -3102, [878 * -7 + 4944 + 1247, 8541 + -1508 + -6985, 2477 * -4 + -2 * 1021 + 12005, hitlogs[_2599962][1 * -7235 + 1 * -9862 + 503 * 34]]), Render['FilledRect'](_4515289 + hitlogs[_2599962][-4933 * 1 + 5545 * 1 + -607] - (-1 * 7419 + 1448 + 6182), curpos + (-17 * 584 + -2210 + 1 * 12143), _2034788 + (-3952 + 579 + 3385), 1 * -743 + -4 * -2179 + -1 * 7945, [13 * 409 + 1463 * -1 + -1 * 3809, -1238 * 7 + -108 * 49 + 1 * 14006, -7061 + -5379 + 12495, 7295 * -1 + 3680 + 3870]), underglow && (pulsate ? Render['GradientRect'](_4515289 + hitlogs[_2599962][-3048 + -3 * -349 + -1003 * -2] - (-1841 * -3 + -1 * 1388 + -1 * 3925), curpos + (-3183 + 5450 * -1 + -1 * -8639), _2034788 + (-2 * 2159 + 6286 + 3 * -653), -164 * 34 + -7554 + -239 * -55, 8487 + -401 * -9 + -144 * 84, rainbowmenu ? [colors['r'], colors['g'], colors['b'], Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((-38 * 111 + -1 * 5574 + -9793 * -1) / (2194 + 598 + -2791.5)) % (Math['PI'] * (-2 * 4889 + -4882 + -14662 * -1)))) * (5398 * 1 + 4036 * -1 + 1 * -1107)] : [color[230 * 38 + 4357 + -7 * 1871], color[-4373 + -648 + 558 * 9], color[7250 + -370 * 1 + 362 * -19], Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((4511 * -1 + -598 + 5110) / (1942 * 2 + -6126 + 2242.5)) % (Math['PI'] * (-4949 + 5198 + -247)))) * (-1 * -4525 + -18 * -268 + -4547 * 2)], [-3333 * -2 + 7 * 719 + -11699, 756 + -29 * -343 + -10703, -325 * -4 + 9809 + -11109, 3 * -862 + 337 * -17 + 8315]) : Render['GradientRect'](_4515289 + hitlogs[_2599962][829 + 4 * 1061 + -181 * 28] - (-479 * -19 + 38 * -253 + 723), curpos + (989 + 7001 + -7984), _2034788 + (-1163 * 7 + 11 * -701 + 51 * 311), -14 * 449 + -2 * -3052 + 1 * 197, 388 * -6 + 7692 + -5364, rainbowmenu ? [colors['r'], colors['g'], colors['b'], hitlogs[_2599962][3035 + 125 * -43 + 2345]] : [color[-82 * 71 + -7686 * 1 + -2 * -6754], color[-698 * 5 + -109 * 36 + 7415 * 1], color[7967 + -1220 + 1 * -6745], 7497 + 88 * -113 + 2702], [2 * 109 + -2215 + 1997 * 1, 7742 + -3507 + -4235, 2981 + -5443 + 1 * 2462, 69 * 107 + -1823 * 1 + 40 * -139])), Render['GradientRect'](_4515289 + hitlogs[_2599962][2194 + 8 * -832 + 4467 * 1] - (-6634 + 267 * -2 + 7378), curpos + (929 * -4 + 7322 + -3602), _2034788 + (5216 + -5384 + 178), 4054 + -2 * -2687 + -9423, -8425 * 1 + -1114 + 9 * 1060, rainbowmenu ? [colors['r'] * (-4808 + 668 * 13 + -3875.25), colors['g'] * (-5657 + -1765 + 7422.75), colors['b'] * (-6021 + -4174 + 10195.75), hitlogs[_2599962][7761 * -1 + -4846 * -1 + 2920]] : [color[-4015 + -215 * -32 + -3 * 955] * (-3575 * 1 + -8126 + 11701.75), color[431 * 11 + -8237 + -269 * -13] * (997 * -4 + -7972 * -1 + -3983.25), color[-4506 + -413 * 14 + -3430 * -3] * (-5422 * -1 + -5084 + -337.25), hitlogs[_2599962][-1585 * 1 + 7937 * -1 + -1361 * -7]], rainbowmenu ? [colors['r'], colors['g'], colors['b'], hitlogs[_2599962][-1 * -7655 + 31 * 201 + -13881]] : [color[-706 * -8 + -2349 + -3299], color[-3084 + -4 * -1370 + 1 * -2395], color[2389 * -1 + 3369 + 978 * -1], hitlogs[_2599962][3203 + -4266 + -356 * -3]]), Render['GradientRect'](_4515289 + hitlogs[_2599962][6041 + -7891 + 1855] - (-7491 * -1 + 1206 + -1 * 8486), curpos + (-5651 + 179 * -43 + -1 * -13353), _2034788 + (8187 + -5749 + -2426 * 1), -5366 + -5009 + 10378, 6487 + -2 * -2917 + -12320, rainbowmenu ? [colors['r'] * (3128 + -139 * 22 + -69.25), colors['g'] * (-1821 * -1 + -1282 * 5 + 4589.75), colors['b'] * (822 * 4 + -2 * -4696 + -12679.25), hitlogs[_2599962][-7230 + 6329 + 906]] : [color[2194 + -828 * 4 + 1118] * (-6 * 991 + 5432 + 514.75), color[-1 * -4663 + -3 * 1937 + 1149 * 1] * (-4394 + -2 * 601 + 5596.75), color[3688 + -172 * -40 + -2 * 5283] * (-3 * 1424 + 8485 + -4212.25), hitlogs[_2599962][-4847 * 2 + -164 + 9863]], rainbowmenu ? [colors['r'], colors['g'], colors['b'], hitlogs[_2599962][-6887 + -1 * 899 + -21 * -371]] : [color[-13 * -523 + 2243 * 4 + -2253 * 7], color[383 + 3864 + -2 * 2123], color[-391 * 24 + 7327 + 2059], hitlogs[_2599962][1 * -4463 + -6964 + 11432]]), bettercircle(_4515289 + hitlogs[_2599962][3405 + -1 * -7247 + -10647] - (3 * -2765 + 2309 + 6205), curpos + (581 * 11 + -3731 + -30 * 88), 1 * 1871 + 8255 + -10105, rainbowmenu ? [colors['r'], colors['g'], colors['b'], hitlogs[_2599962][-8650 + 230 * -8 + 5 * 2099]] : [color[3345 + -9769 * 1 + 1 * 6424], color[9238 + 4030 + -13267], color[7655 + 8407 + -16060], hitlogs[_2599962][-1 * 704 + -1 * -619 + 90]]), bettercircle(_4515289 + hitlogs[_2599962][-7243 + 1576 * -4 + 13552] - (-3996 + -1305 + -552 * -10), curpos + (2 * 87 + -4146 + 1996 * 2), -2609 * 1 + -6343 + -8972 * -1, [-7559 + -4519 + 449 * 27, -218 * -13 + -4 * 1766 + 4278, 7 * 788 + 109 * -68 + 1951, hitlogs[_2599962][-2879 + 5042 + -2158]]), Render['StringCustom'](_4515289 + hitlogs[_2599962][1 * 5239 + 29 * -3 + -5147] - (1 * -4185 + -6111 + 4 * 2631), curpos + (34 * -129 + -1 * -3723 + -667 * -1), 5221 + -1084 + -4137, 'D', rainbowmenu ? [colors['r'], colors['g'], colors['b'], hitlogs[_2599962][-9263 * -1 + -1 * -6771 + -9 * 1781]] : [color[749 * 1 + 3105 + -3854], color[11 * 543 + 1 * 2019 + -131 * 61], color[4060 + 5632 * 1 + -9690], hitlogs[_2599962][9551 * 1 + -3284 + 62 * -101]], _1178285), Render['StringCustom'](_4515289 + hitlogs[_2599962][8354 + 6705 + -15054] - (5276 + 6837 * -1 + 587 * 3), curpos + (-5321 + 8689 + -3355), -11 * -356 + 11 * 179 + -5885, damagelog, [-205 + 727 * 1 + -267, 7 * 1363 + 3418 + -794 * 16, -7 * -1266 + -1 * -8503 + -17110, hitlogs[_2599962][467 * -1 + 3 * 1190 + 1 * -3098]], poopshartfont);
        }
    }
    if (hitmarkers) {
        if (Entity['IsAlive'](plocal)) {
            var _1534121 = Global['GetScreenSize'](),
                _5006340 = _1534121[-110 * 5 + -6679 * 1 + -7229 * -1] / (-9187 + -4161 + 10 * 1335),
                _2097974 = _1534121[-3791 + -2252 * 2 + -8 * -1037] / (-1 * 3408 + 7826 * -1 + -53 * -212);
            if (disableTime > Global['Curtime']()) {
                hitmarkercolor = [espcolor[8663 + -6023 + -2640], espcolor[115 * -30 + 439 * 2 + 2573], espcolor[-1567 + 5168 + -3599], 7053 * 1 + 5921 + 79 * -161];
                if (UI['GetValue']('manualmodes') == 194 + 6 * -883 + -2553 * -2) var _2448774 = 44 + -7769 + -1 * -7745,
                    _15675000 = _2448774 + (-433 * -19 + -4406 * -1 + -12627);
                else var _2327934 = 146 * -68 + -3955 + 1 * 13887,
                    _15675000 = _2448774 + (-9108 + -313 + 9427);
                var _1395981 = (disableTime - Global['Curtime']()) / hitmarkerTime;
                hitmarkercolor[139 * 46 + 9768 + 143 * -113] *= _1395981, Render['Line'](_5006340 - _15675000, _2097974 - _15675000, _5006340 - _2448774, _2097974 - _2448774, hitmarkercolor), Render['Line'](_5006340 - _15675000, _2097974 - _15675000, _5006340 - _2448774, _2097974 - _2448774, hitmarkercolor), Render['Line'](_5006340 - _15675000, _2097974 + _15675000, _5006340 - _2448774, _2097974 + _2448774, hitmarkercolor), Render['Line'](_5006340 - _15675000, _2097974 + _15675000, _5006340 - _2448774, _2097974 + _2448774, hitmarkercolor), Render['Line'](_5006340 + _15675000, _2097974 + _15675000, _5006340 + _2448774, _2097974 + _2448774, hitmarkercolor), Render['Line'](_5006340 + _15675000, _2097974 + _15675000, _5006340 + _2448774, _2097974 + _2448774, hitmarkercolor), Render['Line'](_5006340 + _15675000, _2097974 - _15675000, _5006340 + _2448774, _2097974 - _2448774, hitmarkercolor), Render['Line'](_5006340 + _15675000, _2097974 - _15675000, _5006340 + _2448774, _2097974 - _2448774, hitmarkercolor);
            }
        }
    }
    if (autopeek && Entity['IsAlive'](plocal)) {
        var _3310210 = Entity['GetRenderOrigin'](plocal);
        if (UI['IsHotkeyActive']('Script items', 'Auto peek key')) {
            if (autopeekstarted == -7680 + 419 * 21 + 373 * -3) {
                if (autopeeksmall >= -5428 + -105 * 41 + 9733) autopeeksmall++;
                if (autopeeksmall == -38 * 6 + -8479 + 8725) autopeekstarted = 263 + -4718 + 4456;
            }
        } else {
            if (autopeekstarted == -3 * 1659 + -2677 * 1 + 7655) {
                autopeeksmall--;
                if (autopeeksmall == -7209 + -1 * 13 + 7222) autopeekstarted = 6654 + -6 * 62 + -3 * 2094;
            }
        }
        draw_circle(startpos[1371 * -3 + 2974 + 1139], startpos[323 * -21 + -17 * -97 + -5 * -1027], startpos[-2771 + 7973 + 65 * -80], autopeeksmall, 1314 * -1 + -9591 + 10905.3, UI['GetColor']('Misc', 'JAVASCRIPT', 'Script items', 'Auto peek color'));
    }
    UI['IsHotkeyActive']('Misc', 'JAVASCRIPT', 'Script items', 'Minimum damage key') ? (!LMAOWTF && (general = UI['GetValue']('Rage', 'GENERAL', 'Minimum damage'), pistol = UI['GetValue']('Rage', 'PISTOL', 'Minimum damage'), heavy = UI['GetValue']('Rage', 'HEAVY PISTOL', 'Minimum damage'), scout = UI['GetValue']('Rage', 'SCOUT', 'Minimum damage'), awp = UI['GetValue']('Rage', 'AWP', 'Minimum damage'), auto = UI['GetValue']('Rage', 'AUTOSNIPER', 'Minimum damage'), LMAOWTF = !![]), mindmg && (UI['SetValue']('Rage', 'GENERAL', 'Minimum damage', mindmgslider), UI['SetValue']('Rage', 'PISTOL', 'Minimum damage', mindmgslider), UI['SetValue']('Rage', 'HEAVY PISTOL', 'Minimum damage', mindmgslider), UI['SetValue']('Rage', 'SCOUT', 'Minimum damage', mindmgslider), UI['SetValue']('Rage', 'AWP', 'Minimum damage', mindmgslider), UI['SetValue']('Rage', 'AUTOSNIPER', 'Minimum damage', mindmgslider))) : LMAOWTF && (mindmg && (UI['SetValue']('Rage', 'GENERAL', 'Minimum damage', general), UI['SetValue']('Rage', 'PISTOL', 'Minimum damage', pistol), UI['SetValue']('Rage', 'HEAVY PISTOL', 'Minimum damage', heavy), UI['SetValue']('Rage', 'SCOUT', 'Minimum damage', scout), UI['SetValue']('Rage', 'AWP', 'Minimum damage', awp), UI['SetValue']('Rage', 'AUTOSNIPER', 'Minimum damage', auto)), LMAOWTF = ![]);
    Input['IsKeyPressed'](-7728 + -6789 * 1 + 1 * 14606) && (typing = !![]);
    (Input['IsKeyPressed'](4 * 1455 + -152 * 43 + 743) || Input['IsKeyPressed'](6416 + -1 * 8304 + 1 * 1901)) && (typing = ![]);
    if (rainbowmenu) _4949814 = colors['r'], _3614977 = colors['g'], _2767436 = colors['b'];
    else {
        if (UI['GetValue']('manualmodes') == 5407 + -6859 + 1 * 1454 && fakeamount) {
            var _2406718 = Local['GetRealYaw'](),
                _5700610 = Local['GetFakeYaw'](),
                _2531647 = _2406718 - _5700610;
            if (_2531647 > -7768 + -668 * 10 + 14628) _2531647 -= -1 * 4978 + 1 * 5471 + -133;
            if (_2531647 < -(4795 + 13 * 62 + -5421)) _2531647 += 13 * 102 + -14 * 516 + 6258;
            _2531647 = Math['abs'](_2531647) / (209 * -31 + 7003 * 1 + 1 * -404);
            var _4949814 = 4896 + -8237 * 1 + 3596 - _2531647 * (-9341 + 4229 + 5212) * (-426 * -6 + -7451 + 4897.55),
                _3614977 = _2531647 * (823 + -751 * -6 + -7 * 747) * (154 * 30 + -1 * -8213 + -12830.45),
                _2767436 = 43 * -121 + 335 * 11 + 22 * 69;
        } else selectedcp = espcolor, _4949814 = selectedcp[4202 + 7481 * 1 + -11683], _3614977 = selectedcp[-4457 + 4869 + -411], _2767436 = selectedcp[4789 * 1 + -5560 + -773 * -1];
    }
    const _3161072 = Math['sin'](Math['abs'](-Math['PI'] + Globals['Curtime']() * ((-3861 + -3 * 1213 + 7501) / (-4681 * -2 + -5596 + -3765.5)) % (Math['PI'] * (1 * -4404 + 3885 + -1 * -521)))) * (5471 + -3181 * 3 + -4327 * -1);
    if (Entity['IsAlive'](plocal)) {
        if (UI['GetValue']('manualmodes') == 4020 + 1814 + -5833 * 1) {
            Render['Line'](screensize[73 * -1 + -9597 + 9670] / (-1 * 5227 + 2761 + 2468) - (-3449 * -1 + 1 * 7905 + -11314 * 1), screensize[5091 + 573 * -3 + -3371 * 1] / (-13 * 587 + -1707 + 9340), screensize[5309 + 206 * -5 + -389 * 11] / (-13 * -122 + -6795 + -1737 * -3) - (-301 * 23 + 6562 + 401), screensize[10 * 91 + 3 * -2462 + 6477] / (-8202 + 8710 + -506) + (-1 * -2823 + -33 * -75 + -439 * 12), [-7156 + 2776 + 4460, -769 + -2 * -1619 + 1 * -2389, -66 * -75 + 8956 + -31 * 446, -5570 + 154 + 5566], -4 * -1065 + -1296 + -2464), Render['Line'](screensize[3957 + -7375 + 2 * 1709] / (-122 * -30 + -6322 + -18 * -148) + (-559 * -1 + 59 * -98 + -5263 * -1), screensize[4 * 287 + -2 * 4946 + -15 * -583] / (6198 + -7619 + 1423), screensize[13 * 426 + 211 * -41 + 3113 * 1] / (-47 * -142 + -7989 + 1317) + (2817 + -2 * 2909 + 3041 * 1), screensize[8000 + 7868 + 1 * -15867] / (1 * 7927 + -1158 + 6767 * -1) + (2493 + -6423 + 3960), [-1410 * 7 + 222 * 23 + 4844, -8208 + 6287 * 1 + -1 * -2001, 6914 * 1 + 4886 + -11720, -9 * 443 + -1378 + 5515], 833 * -3 + -60 * -114 + 1 * -3841), Render['Line'](screensize[3 * -429 + -11 * -764 + 647 * -11] / (7697 + 3447 + -11142) - (164 * 34 + 4154 + -9690), screensize[-2 * -4447 + 5685 + 1 * -14578] / (4058 + 6079 + -10135) + (-4274 + 3294 + 1010), screensize[-8376 + -6478 + -1061 * -14] / (6215 + -3797 * -2 + -1 * 13807) - (-7262 + 2425 + 1 * 4857), screensize[1233 + 3272 * -2 + 5312] / (2836 + -1097 * 9 + 7039) + (-583 * 7 + -321 * 31 + 14082), [2311 + -163 * -59 + -8 * 1481, 857 * -6 + -367 * -8 + 254 * 9, 7836 + 540 * -13 + -32 * 23, -5793 + 6433 + 7 * -70], 43 + 2274 * 1 + 79 * -23), Render['Line'](screensize[-854 + 2939 + -2085] / (823 * 2 + 684 + -97 * 24) + (2546 + 8608 * -1 + 6102 * 1), screensize[-493 * 15 + -3 * 2032 + 13492] / (2 * 751 + -1850 + 350) + (-414 * 20 + 7796 * -1 + 16106), screensize[-6895 + -1478 + 8373] / (3 * 1786 + 6484 + -1480 * 8) + (-5814 + -1 * -9861 + -1 * 4027), screensize[5631 + -6617 + 7 * 141] / (1 * 2833 + 5 * -366 + -1 * 1001) + (6554 + 2237 * 4 + -15452), [-1 * -2524 + -4581 + 2137, 2 * 3795 + -5683 + -1827, 3385 + -9453 + 6148, -6 * -159 + 3 * 1931 + -9 * 733], -5919 * -1 + 4148 + -3189 * 3), Render['Line'](screensize[-4 * 2439 + 5106 + 2325 * 2] / (1 * 9646 + 3 * -3329 + 343) - (1 * -6737 + -1925 + 8682), screensize[-8 * 281 + 284 * 28 + -5703 * 1] / (-293 * 14 + 6043 + -7 * 277) + (-32 * 251 + -9730 + -73 * -244), screensize[19 * 458 + -683 + -81 * 99] / (-9335 + 3924 + 5413) + (-17 * 79 + -29 * -326 + -8091), screensize[-1097 * -9 + -3299 * -2 + -5490 * 3] / (-1506 * 6 + -5510 + 14548) + (-5 * -137 + -179 * 28 + 4377), [6768 + -6089 * 1 + -599 * 1, -1 * 8451 + -259 + 8790, -157 * -47 + 1 * -1475 + -832 * 7, -665 + 3139 + -2324], -7855 + 45 * -149 + 15060);
            if (UI['IsHotkeyActive']('Anti-Aim', 'Fake angles', 'Inverter')) Render['Line'](screensize[-38 * -185 + -2491 + -4539] / (-2284 + -6 * -129 + -1 * -1512) - (-1 * 6131 + -1 * -7053 + -882), screensize[386 + 9448 + -9833] / (8002 + -9767 * -1 + -17767 * 1) + (-447 + -22 * 408 + -69 * -137), screensize[-7 * 514 + -5 * 1602 + 11608] / (-5168 + 164 + 5006) - (4400 + -1 * -8922 + -13302), screensize[73 * 103 + 5782 + 2 * -6650] / (2791 + 5410 + 911 * -9) + (-1 * -4261 + 7 * 91 + -4848), [_4949814, _3614977, _2767436, _3161072], -9351 + -225 * -22 + 4901);
            else !UI['IsHotkeyActive']('Anti-Aim', 'Fake angles', 'Inverter') && Render['Line'](screensize[691 * 5 + -70 * 83 + 2355] / (-4749 * 1 + -1 * -7893 + -1571 * 2) + (2488 + -4352 + 1904), screensize[-8195 + 8242 + -2 * 23] / (23 * 217 + 8635 + -13624) + (-31 * -237 + -6796 + -521), screensize[6262 + 535 * -10 + -24 * 38] / (3 * 1091 + -136 * 29 + 673 * 1) + (-7341 + -1899 + -2 * -4630), screensize[49 * -91 + -4725 * -1 + 1 * -265] / (10 * 549 + -3407 * -1 + -8895 * 1) + (1229 * -2 + 7035 + -3 * 1509), [_4949814, _3614977, _2767436, _3161072], -4567 + -7085 + -217 * -56);
            if (drawLeft) Render['Line'](screensize[1725 * -3 + -26 * 250 + 11675] / (-2423 + 694 * 7 + -2433) - (2299 + -3597 + 2 * 669), screensize[-1 * 545 + -3700 + 4246] / (-6127 + -5424 + 11553 * 1), screensize[-1549 * 3 + -3276 + 7923] / (4766 + 9275 + -14039) - (15 * 602 + 7359 + 16349 * -1), screensize[-9415 + 9413 + -1 * -3] / (-6928 + 4539 + -2391 * -1) + (-3634 + -89 * -52 + -964), [_4949814, _3614977, _2767436, -1 * 8320 + 4686 + -1 * -3889], 257 * 17 + 8546 + 12415 * -1);
            else {
                if (drawRight) Render['Line'](screensize[4026 + 4162 + -178 * 46] / (7350 + 2842 + -10190) + (4752 + 89 * -79 + 773 * 3), screensize[-2353 * -2 + -5392 + 687 * 1] / (-33 * 99 + -3668 + 6937), screensize[-5355 + -6461 + 844 * 14] / (-1347 + 3435 + -2086) + (-4956 + -1721 * 5 + 13601), screensize[-3725 + -6 * 512 + 6798] / (-8677 * 1 + 1 * 5663 + 3016) + (1 * -1483 + 8330 + -6817), [_4949814, _3614977, _2767436, -103 * 59 + 7353 + -1021], -271 + -26 * -295 + -6899);
                else drawBack && Render['Line'](screensize[-3067 + -563 * -11 + -1042 * 3] / (14 * -74 + 2 * -2383 + 5804) - (2609 * -1 + -7977 * 1 + 10606), screensize[-1 * 5127 + -3 * 2157 + -1657 * -7] / (2 * -503 + -1 * 5210 + -1 * -6218) + (-4136 + 624 * -13 + 12298), screensize[9848 + 100 * 16 + -11448] / (-4857 + 719 * 6 + 109 * 5) + (-4448 + -8106 + 1 * 12574), screensize[-706 * -1 + -758 * -1 + -1463] / (1318 * 2 + -9888 + 7254) + (-4 * 27 + -4753 + 1637 * 3), [_4949814, _3614977, _2767436, 1 * -2427 + -5162 + 7844], 9395 + -52 * -191 + -67 * 281);
            }
        } else {
            if (UI['GetValue']('manualmodes') == 1 * -3497 + 542 + 2957 * 1) {
                Convar['SetString']('crosshair', '0'), UI['SetValue']('Visual', 'WORLD', 'Penetration dot', !![]);
                var _6044617 = screensize[-4102 + 332 * -26 + 12734 * 1] / (2986 + -6338 + 3354),
                    _4324522 = screensize[-15 * 124 + 1 * -5788 + -1 * -7649] / (4332 + -6428 + 2098),
                    _1238156 = Local['GetViewAngles'](),
                    _2069306 = Local['GetRealYaw'](),
                    _4067807 = _1238156[7778 + 8400 + -16177] - (-258 + 11 * -521 + -1 * -6169),
                    _2406718 = adjust_angle(_2069306 - _4067807);
                removedinner(_6044617, _4324522, -1147 * 1 + 9159 + -7999, -17 * 127 + 6529 + -4365.5, [6813 + -7 * 626 + -2431, -419 * 9 + -9135 + 1 * 12906, -5134 + -449 * -13 + -19 * 37, 1 * 3203 + -1 * 4444 + 1311]), semicircle(_6044617, _4324522, 1750 * 4 + -1 * -277 + -1451 * 5, _2406718 - (-2433 + -5 * 757 + 2 * 3199) * (-3989 + -23 * 258 + 9923.2), -53 * -110 + -556 * 1 + -1 * 5209, 1390 + -1 * 410 + -975, -1601 * -2 + -1 * 1504 + 834 * -2, [_4949814, _3614977, _2767436, 71 * 21 + 127 * -65 + -1 * -7019]), semicircle(_6044617, _4324522, -7069 + -4138 + 11219, UI['IsHotkeyActive']('Anti-Aim', 'Fake angles', 'Inverter') ? -(-9 * -741 + -5085 + -1494) : 1 * 4702 + 137 * 23 + -7763 * 1, -21 * -403 + 7438 + 15721 * -1, -701 * -9 + 50 * 122 + -12404, -2722 * 3 + -1085 + 9331, [_4949814, _3614977, _2767436, -4 * 364 + -4017 + 5728]);
            }
        }
    }
    if (UI['GetValue']('AA mode') == -469 * -1 + -809 + -2 * -171) {
        if (Entity['IsAlive'](plocal)) {
            if (bullet_impact_user != bullet_start_user) return;
            if (bullet_impact_user == -(-2732 + -8628 + 3787 * 3) || bullet_start_user == -(-2 * -97 + -1 * -3665 + -3858) || bullet_start_loc == [] || bullet_impact_loc == []) return;
            local_pos = Entity['GetHitboxPosition'](plocal, -541 + 1911 + -19 * 72), x0 = local_pos[6209 + 421 * 5 + 8314 * -1], y0 = local_pos[40 * 109 + 3 * -2638 + 395 * 9], z0 = local_pos[1066 + -5468 + 3 * 1468], x1 = bullet_start_loc[562 + 5384 + -2973 * 2], y1 = bullet_start_loc[408 * 8 + 2668 + -5931], z1 = bullet_start_loc[-9279 + -161 * 53 + -2 * -8907], x2 = bullet_impact_loc[-7 * -470 + 75 * -31 + -965], y2 = bullet_impact_loc[-10 * 250 + 4588 + -2087], z2 = bullet_impact_loc[2615 * -2 + -7631 + 12863 * 1], t = -((x1 - x0) * (x2 - x1) / Math['pow'](Math['abs'](x2 - x1), 6935 * -1 + -120 * -35 + 2737)), d = Math['sqrt'](Math['pow'](x1 - x0 + (x2 - x1) * t, 2 * -263 + 8263 * 1 + -7735) + Math['pow'](y1 - y0 + (y2 - y1) * t, 464 * -16 + 427 * 5 + 5291) + Math['pow'](z1 - z0 + (z2 - z1) * t, 14 * -83 + 2047 + -883)), d < -103 * 5 + 6503 + -5788 && UI['ToggleHotkey']('Anti-Aim', 'Fake angles', 'Inverter'), bullet_impact_user = -(-6500 + 47 * 94 + 2083), bullet_impact_loc = [], bullet_start_user = -(-4705 * 1 + 25 * -238 + -1776 * -6), bullet_start_loc = [];
        }
    }
    if (grenadecircles) {
        var _3310210 = Entity['GetRenderOrigin'](plocal);
        firecolor = UI['GetColor']('Misc', 'JAVASCRIPT', 'Script items', 'Inferno color'), smokecolor = UI['GetColor']('Misc', 'JAVASCRIPT', 'Script items', 'Smoke color');
        const _15345859 = Entity['GetEntitiesByClassID'](1 * -5647 + -6865 + -1 * -12668)['concat'](Entity['GetEntitiesByClassID'](-9277 + -2189 * 2 + 13768))['concat'](Entity['GetEntitiesByClassID'](-1856 * -2 + 7230 + 417 * -26));
        for (var _2599962 = 761 + 9242 + -1 * 10003; _2599962 < _15345859['length']; _2599962++) {
            const _6931547 = _15345859[_2599962],
                _4167927 = Entity['GetRenderOrigin'](_6931547),
                _4016278 = Entity['GetClassID'](_6931547) === -3736 + 2308 + 191 * 8,
                _3418501 = Entity['GetClassID'](_6931547) === -4305 + -385 + 4846;
            _3418501 && Entity['GetProp'](_6931547, 'CSmokeGrenadeProjectile', 'm_nSmokeEffectTickBegin') && draw_circle(_4167927[1062 + 779 * 5 + -4957], _4167927[8913 + 843 * 4 + -12284], _4167927[-5130 + -40 * -47 + 6 * 542], 4882 * 2 + 9415 + -19009, -774 * 3 + 2078 + 244.15, smokecolor), _4016278 && draw_circle(_4167927[-1339 * -7 + -2 * -2489 + -14351], _4167927[-7714 + 7 * 857 + -11 * -156], _4167927[-1 * 3274 + 841 * 2 + 1594], -7 * 193 + -430 * -5 + -659 * 1, -4355 + 61 + 4294.15, firecolor);
        }
    }
}
const clamp = function(_13249692, _3268851, _5227777) {
    return Math['min'](Math['max'](_13249692, _3268851), _5227777);
};
var localobservers = [],
    n_local_obs = [],
    local_dead, heavy_cache = UI['GetValue']('Rage', 'HEAVY PISTOL', 'Accuracy', 'Hitchance');

function onGround(_2318817) {
    players = Entity['GetPlayers']();
    for (i = 4993 + 684 + 7 * -811; i < players['length']; i++); {
        var _5018269 = Entity['GetProp'](_2318817, 'CBasePlayer', 'm_hGroundEntity');
    }
    return _5018269;
}
var transparency_cache = UI['GetValue']('Visual', 'SELF', 'Chams', 'Visible transparency'),
    stopspam = !![];

function shiftshit(_4112469) {
    plocal = Entity['GetLocalPlayer']();
    if (improveddt) {
        var _2164699 = Entity['GetName'](Entity['GetWeapon'](Entity['GetLocalPlayer']()));
        _2164699 == 'awp' || _2164699 == 'ssg 08' ? UI['IsHotkeyActive']('Misc', 'JAVASCRIPT', 'Script items', 'Teleport key') && tponpeek ? UI['SetValue']('Rage', 'GENERAL', 'Exploits', 'Doubletap', !![]) : (UI['SetValue']('Rage', 'GENERAL', 'Exploits', 'Doubletap', ![]), stopspam = !![]) : stopspam && (UI['SetValue']('Rage', 'GENERAL', 'Exploits', 'Doubletap', !![]), stopspam = ![]);
        var _2441620 = Entity['GetWeapon'](plocal);
        if (plocal == null || _2441620 == null) return ![];
        var _5741463 = Entity['GetProp'](plocal, 'CCSPlayer', 'm_nTickBase'),
            _3207674 = Globals['TickInterval']() * (_5741463 - _4112469);
        if (_3207674 < Entity['GetProp'](plocal, 'CCSPlayer', 'm_flNextAttack')) return ![];
        if (_3207674 < Entity['GetProp'](_2441620, 'CBaseCombatWeapon', 'm_flNextPrimaryAttack')) return ![];
        return !![];
    }
}

function startshit() {
    improveddt && (Exploit['OverrideTolerance'](-2 * 1481 + -3868 + 6830), Exploit['OverrideShift'](5799 + 6802 + -1 * 12587));
}

function pHurt() {
    hitlog && (attackerEntity = Entity['GetEntityFromUserID'](Event['GetInt']('attacker')), attackerEntity == plocal && (victimName = Entity['GetName'](Entity['GetEntityFromUserID'](Event['GetInt']('userid'))), hitboxName = hitgroupToHitbox(Event['GetInt']('hitgroup')), damageDone = Event['GetInt']('dmg_health'), healthRemaining = Event['GetInt']('health'), hitlogs['push']([victimName, hitboxName, damageDone, healthRemaining, 1 * 9569 + 1 * -8597 + -1 * 972, -2 * 202 + -1192 + 1851, (Math['random']() * (-6415 + 6779 + -363.8 - (-617 * -9 + -1258 * -1 + -6809.8)) + (1138 + -256 * 1 + -880.8))['toFixed'](-691 * -14 + 2 * 3072 + 1 * -15814), Globals['Curtime']()]), healthRemaining == 674 * 5 + -7421 + -1 * -4051 ? damagelog = '[Zona] Did ' + damageDone + ' damage to ' + victimName + "'s " + hitboxName + ' (KILLED)' : damagelog = '[Zona] Did ' + damageDone + ' damage to ' + victimName + "'s " + hitboxName + '\x20(' + healthRemaining + ' hp remaining)', Global['PrintColor'](UI['GetColor']('Script items', 'Main color'), damagelog + '\x0a')));
    var _16079430 = Event['GetString']('attacker'),
        _2023364 = Event['GetString']('health'),
        _2133100 = Entity['GetEntityFromUserID'](_16079430),
        _5486324 = 463 * 3 + -2687 + 1299.5;
    _2133100 == plocal && (disableTime = Global['Curtime']() + _5486324, didKill = _2023364 <= 8649 + 2271 + -1560 * 7, hitmarkerTime = _5486324);
}
hitlogs = [], welcomelog = [];

function hitgroupToHitbox(_2193645) {
    hitbox = 'generic';
    switch (_2193645) {
        case 6850 + -81 * 91 + 522:
            hitbox = 'head';
            break;
        case -3373 + -4139 + 1 * 7514:
            hitbox = 'pelvis';
            break;
        case 1 * -5554 + -7984 + 13541:
            hitbox = 'body';
            break;
        case -4972 + -7092 + 12068:
            hitbox = 'chest';
            break;
        case -7821 + -121 * -15 + 6011:
            hitbox = 'chest';
            break;
        case -41 * 185 + 2 * 1892 + -141 * -27:
            hitbox = 'upper chest';
            break;
        case -382 + 8147 + -7758:
            hitbox = 'left thigh';
            break;
        case -5 * -71 + -4300 + 3953:
            hitbox = 'right thigh';
            break;
        case -43 * 187 + -3 * 1769 + 19 * 703:
            hitbox = 'left calf';
            break;
        case 218 * 16 + 845 * 7 + 101 * -93:
            hitbox = 'right calf';
            break;
        case 8073 + 7252 + -38 * 403:
            hitbox = 'left foot';
            break;
        case 274 * -8 + -3193 + 257 * 21:
            hitbox = 'right foot';
            break;
        case 11 * 407 + 11 * 689 + 1 * -12043:
            hitbox = 'left hand';
            break;
        case 6158 + 3076 + -9220:
            hitbox = 'right hand';
            break;
        case 1013 * -2 + 1 * 6901 + -324 * 15:
            hitbox = 'left arm';
            break;
        case 941 * 1 + -1608 + -1 * -683:
            hitbox = 'left forearm';
            break;
        case 4729 * 1 + 1 * -8218 + -3506 * -1:
            hitbox = 'right arm';
            break;
        case 2111 + 4893 + 1 * -6986:
            hitbox = 'right forearm';
    }
    return hitbox;
}
var cnt = 4912 * 1 + -51 * 73 + -1189,
    next_update = 37 * -1 + 167 * 9 + -1466,
    flip = ![];

function plegitaa() {
    !legitaa && (UI['SetValue']('Anti-Aim', 'Rage Anti-Aim', 'Enabled', ![]), UI['SetValue']('Anti-Aim', 'Legit Anti-Aim', 'Enabled', ![]));
    var _4083788 = !![];
    _4083788 = ![];
    if (cnt % (603 + -3840 + 3239)) _4083788 = !![];
    cnt++, flip = !flip;
    var _2494718 = Local['GetViewAngles'](),
        _3071902 = ![],
        _6107533 = Entity['GetProp'](plocal, 'CCSPlayer', 'm_vecVelocity[0]'),
        _3176541 = Math['sqrt'](_6107533[-2661 * -2 + 9385 + -1337 * 11] * _6107533[9509 + 9836 + -265 * 73] + _6107533[-4702 + 6833 + -2130] * _6107533[8948 + -4482 + -235 * 19]),
        _2361573 = UI['IsHotkeyActive']('Anti-Aim', 'Fake angles', 'Inverter'),
        _6095419 = UserCMD['GetButtons'](),
        _2209775 = Entity['GetProp'](plocal, 'CCSPlayer', 'm_nTickBase') * Globals['TickInterval'](),
        _2912037 = Entity['GetProp'](Entity['GetWeapon'](plocal), 'DT_BaseCombatWeapon', 'm_flNextPrimaryAttack') <= _2209775 && Entity['GetProp'](Entity['GetWeapon'](plocal), 'DT_BaseCombatWeapon', 'm_iClip1') > -761 * 11 + 307 * -1 + 2 * 4339,
        _4295709 = -1 * -1193 + -9697 + 8504 * 1,
        _5422727 = 3513 + -3572 * 1 + 1 * 59;
    if (_6095419 & 2071 * -1 + 12 * -145 + -3 * -1441) _5422727 -= 582 * -9 + -1 * -8802 + -6 * 519;
    if (_6095419 & -8159 + -5170 + 463 * 31) _5422727 += -2923 + -1577 * -1 + 1796;
    if (_6095419 & -299 + -8017 * 1 + 8324) _4295709 += 2071 + -161 * -3 + 526 * -4;
    if (_6095419 & -1 * -3089 + -2243 * 3 + -1 * -3656) _4295709 -= 4311 + 14 * -614 + 1 * 4735;
    if (next_update <= Globals['Curtime']()) {
        _3176541 < -136 * 52 + 5 * 1772 + -254 * 7 && (_3071902 = !![]);
        next_update = Globals['Curtime']() + (-9767 * -1 + -932 * -1 + -10698.78);
        if (_5422727 == -302 * 3 + -1 * 8981 + 9887 * 1) {
            var _3344709 = -27 * 281 + -4796 + 12384.1;
            if (_6095419 & 1 * -3479 + 6962 + -3479) _3344709 *= -1 * -1739 + -2168 + 432;
            _5422727 = flip ? _3344709 : -_3344709;
        }
    }
    _6095419 & 5568 + 3352 + -2973 * 3 && _2912037 && (_4083788 = !![], _3071902 = ![]);
    (_6095419 & 1 * 7048 + 6881 + 1 * -11881 || _6095419 & 1 * 2467 + 8390 + 2 * -5428) && Entity['GetName'](Entity['GetWeapon'](plocal))['includes']('knife') && (_4083788 = !![], _3071902 = ![]);
    _6095419 & 1950 + 1004 + -2 * 1461 && !legitaa && (_4083788 = !![], _3071902 = ![]);
    (Entity['GetName'](Entity['GetWeapon'](plocal))['includes']('grenade') || Entity['GetName'](Entity['GetWeapon'](plocal))['includes']('molotov') || Entity['GetName'](Entity['GetWeapon'](plocal))['includes']('flashbang')) && (_4083788 = !![], _3071902 = ![]);
    Entity['GetName'](Entity['GetWeapon'](plocal))['includes']('c4') && _6095419 & 127 * 24 + -9 * -102 + -3965 && (_4083788 = !![], _3071902 = ![]);
    var _2384022 = Entity['GetProp'](plocal, 'CCSPlayer', 'm_hGroundEntity') == 'm_hGroundEntity',
        _1821741 = UserCMD['GetButtons']() & 101 * 23 + -1 * -6982 + 7 * -1329 && UI['GetValue']('Misc', 'GENERAL', 'Movement', 'Auto bunnyhop');
    if (_2384022 || _1821741) _3071902 = ![];
    else UserCMD['SetMovement']([_4295709, _5422727, -1 * -3625 + 5126 * -1 + -1501 * -1]);
    if (_3071902) {
        var _4508399 = Local['GetFakeYaw'](),
            _1332846 = Local['GetRealYaw'](),
            _7399112 = _4508399 - _1332846;
        while (_7399112 < -(3721 * -1 + -3769 + 7670)) _7399112 += 1 * 789 + 1 * -340 + -1 * 89;
        while (_7399112 > -7018 + -1 * 7294 + 14492) _7399112 -= -6827 * 1 + -4157 + 1 * 11344;
        _7399112 = Math['abs'](_7399112);
        if (_7399112 > 15 * 333 + -1864 * -4 + -459 * 27) _2494718[265 * 23 + -31 * -185 + -11829] -= 9946 + -6995 + 1 * -2771;
        else _2494718[-1 * 3217 + -1 * -7607 + -4389] += _2361573 ? -1787 + 5 * 761 + -1898 : -(-7 * 96 + -8166 + 6 * 1493);
        UserCMD['SetViewAngles'](_2494718, !![]), _4083788 = ![];
    } else !_4083788 && (_2494718[7473 + 4 * -1294 + 328 * -7] += _2361573 ? -(-3839 * 2 + -3938 + 11736) : 2655 * -1 + 587 * 5 + -160, UserCMD['SetViewAngles'](_2494718, !![]));
    _4083788 ? UserCMD['Send']() : UserCMD['Choke']();
}
var disableTime, hitmarkerTime, didKill, general = UI['GetValue']('Rage', 'GENERAL', 'Minimum damage'),
    pistol = UI['GetValue']('Rage', 'PISTOL', 'Minimum damage'),
    heavy = UI['GetValue']('Rage', 'HEAVY PISTOL', 'Minimum damage'),
    scout = UI['GetValue']('Rage', 'SCOUT', 'Minimum damage'),
    awp = UI['GetValue']('Rage', 'AWP', 'Minimum damage'),
    auto = UI['GetValue']('Rage', 'AUTOSNIPER', 'Minimum damage'),
    LMAOWTF = ![],
    velocity = 4963 * 1 + 211 * -47 + 4954,
    screensize = Global['GetScreenSize'](),
    isInverted, drawLeft = 1527 * -1 + 7327 * -1 + 8854,
    drawRight = 4598 + -3 * 136 + -2095 * 2,
    drawBack = 6035 + -7354 + 120 * 11,
    typing = ![],
    force_baim = 4520 + 5579 + -10099;

function vec_add(_3753234, _4451651) {
    return [_3753234[-1348 * 2 + 320 + -3 * -792] + _4451651[-53 * -174 + -612 + -410 * 21], _3753234[-1645 * -6 + -1 * -2028 + -1 * 11897] + _4451651[991 * -2 + 3187 * 1 + -1204], _3753234[-2506 * 1 + 8033 + -5525] + _4451651[-2681 + -3047 + 5 * 1146]];
}

function RadToDeg(_3407879) {
    return _3407879 * (-12 * -411 + 612 + 596 * -9) / Math['PI'];
}

function calcang(_1427675, _3882049) {
    var _6235212 = [];
    _6235212[9839 + 3710 * 1 + -13549] = _1427675[-6381 + -8578 + -7 * -2137] - _3882049[-3773 + -3 * 1929 + 9560], _6235212[2207 * 1 + 9049 * -1 + 6843] = _1427675[-1 * 5482 + -3871 + 9354] - _3882049[2179 + 2501 + -4679], _6235212[1 * -8226 + 6488 + 1740] = _1427675[6372 + -1 * -9601 + 1 * -15971] - _3882049[326 * -26 + 4091 * -1 + 12569];
    var _4135858 = [];
    _4135858[-3813 + 5380 + 1 * -1567] = RadToDeg(Math['atan'](_6235212[-6420 + 9788 + -561 * 6] / Math['hypot'](_6235212[7111 * 1 + -4487 + -2 * 1312], _6235212[8519 + -225 + -8293]))), _4135858[5505 + -74 * 6 + -46 * 110] = RadToDeg(Math['atan'](_6235212[-4167 + 2567 + 1601 * 1] / _6235212[-4869 + -38 * -123 + 195])), _4135858[1435 * -5 + 250 + 3 * 2309] = -3262 + 2661 + -601 * -1;
    if (_6235212[4936 + 43 * 179 + -12633] >= 5650 + 59 * -155 + 3495) _4135858[5 * -1117 + 2642 + 92 * 32] += -289 * -29 + 8827 * -1 + 626;
    while (_4135858[-1247 + 2654 + 1 * -1406] > 92 * 101 + 1698 + 2162 * -5) _4135858[-6911 * 1 + -6672 + 8 * 1698] -= 5644 + -2680 + -868 * 3;
    while (_4135858[-367 * -26 + 2091 * 1 + 16 * -727] < -(4750 + 5297 + 1 * -9867)) _4135858[341 + 2823 + -1 * 3163] += -5608 + 1975 * -5 + -5281 * -3;
    return _4135858;
}
var bullet_impact_user = -(9653 + -5358 + -38 * 113),
    bullet_impact_loc = [],
    bullet_start_user = -(6481 + -588 + -5892),
    bullet_start_loc = [],
    peeking = -(43 * -54 + -2061 + -1096 * -4);

function in_air() {
    return fv = Entity['GetProp'](Entity['GetLocalPlayer'](), 'CBasePlayer', 'm_flFallVelocity'), fv < -(10 * -766 + 13 * 551 + 83 * 6) || fv > 1864 * -1 + -1129 * -4 + -2651;
}

function on_shot() {
    if (!Entity['IsEnemy'](Entity['GetEntityFromUserID'](Event['GetInt']('userid')))) return;
    bullet_start_user = Entity['GetEntityFromUserID'](Event['GetInt']('userid')), bullet_start_loc = Entity['GetHitboxPosition'](Entity['GetEntityFromUserID'](Event['GetInt']('userid')), 1 * 8579 + 8961 + -17538);
}

function on_impact() {
    if (!Entity['IsEnemy'](Entity['GetEntityFromUserID'](Event['GetInt']('userid')))) return;
    bullet_impact_user = Entity['GetEntityFromUserID'](Event['GetInt']('userid')), bullet_impact_loc = [Event['GetFloat']('x'), Event['GetFloat']('y'), Event['GetFloat']('z')];
}
Cheat['RegisterCallback']('bullet_impact', 'on_impact'), Cheat['RegisterCallback']('weapon_fire', 'on_shot'), Cheat['RegisterCallback']('CreateMove', 'cm'), Cheat['RegisterCallback']('Draw', 'a'), Cheat['RegisterCallback']('Unload', 'ifunload'), Cheat['RegisterCallback']('round_start', 'roundstart'), Cheat['RegisterCallback']('player_death', 'player_death'), Cheat['RegisterCallback']('FrameStageNotify', 'reload'), Cheat['RegisterCallback']('Draw', 'paint'), Cheat['RegisterCallback']('FRAME_NET_UPDATE_START', 'startshit'), Cheat['RegisterCallback']('player_hurt', 'pHurt');
var enemies = Entity['GetEnemies'](),
    effects = [],
    kills = 3273 + 1 * -1917 + -226 * 6,
    texts = ['FIRST BLOOD!', 'DOUBLE KILL', 'MULTI KILL', 'ULTRA KILL', 'PENTA KILL', 'GOD LIKE', 'LUDICROUS', 'UNSTOPPABLE', 'UNSTOPPABLE', 'UNSTOPPABLE', 'UNSTOPPABLE', 'UNSTOPPABLE', 'UNSTOPPABLE', 'UNSTOPPABLE', 'UNSTOPPABLE', 'UNSTOPPABLE'];
const server = World['GetServerString']();
niggas = Cheat['GetUsername']();
var cring = !![],
    yes = !![],
    exploitwarning = !![],
    matchmakingwarning = !![],
    fps = 68 * -61 + -6 * 1261 + -11714 * -1,
    last_update = 2817 * -2 + 6325 + 691 * -1,
    color = UI['GetColor']('Misc', 'JAVASCRIPT', 'Script items', 'Main color'),
    a0_3656290 = {};
a0_3656290['real'] = 0, a0_3656290['fake'] = 0, a0_3656290['lby'] = 0, a0_3656290['side'] = 0, a0_3656290['limit'] = 0;
var wish = a0_3656290,
    a0_1031099 = {};
a0_1031099['real'] = 0, a0_1031099['fake'] = 0, a0_1031099['duck_amount'] = 0, a0_1031099['shifting'] = ![];
var local = a0_1031099,
    a0_3902668 = {};
a0_3902668['flip'] = ![], a0_3902668['tickcount'] = 0;
var a0_4694723 = {};
a0_4694723['crouching'] = ![];
var a0_2945372 = {};
a0_2945372['alternate'] = a0_3902668, a0_2945372['fd'] = a0_4694723, a0_2945372['tick_count'] = 0, a0_2945372['cur_time'] = 0, a0_2945372['debug'] = !![];
var globals = a0_2945372,
    autodisable = ![],
    lasttag = '';

function render_string(_3627873, _2591823, _1739494, _4003332, _3626024, _2293343) {
    Render['String'](_3627873 - (15 * 83 + -2244 + 1000), _2591823 - (-4172 + -5464 + 9637), _1739494, _4003332, [-5796 + 111 * -84 + 15135, 8524 + 8008 + -16517 * 1, -3 * -185 + -36 * -106 + -4356, _3626024[1380 + -9428 + -8051 * -1] * (3401 + 1452 + -4852.75)], _2293343), Render['String'](_3627873 + (-3 * -1021 + -9962 + 6900), _2591823 - (-1 * 8777 + 1071 + -3 * -2569), _1739494, _4003332, [-255 * 29 + 480 * -1 + -789 * -10, 4937 + -117 * -41 + -9719 * 1, -6601 + -2121 * -1 + 4495, _3626024[9249 + -5611 + -3635] * (8538 * -1 + 8371 + 167.25)], _2293343), Render['String'](_3627873 - (-703 + -8202 + -1 * -8906), _2591823 + (-3 * 3299 + -4742 + -40 * -366), _1739494, _4003332, [-3904 + 2179 + 1740, -113 * -58 + 4386 + -10925, -5631 + 2423 + -3223 * -1, _3626024[-6914 + 263 * 35 + -176 * 13] * (2767 * 3 + -1117 * -5 + -13885.75)], _2293343), Render['String'](_3627873 + (-6210 + -1576 * 4 + 12515), _2591823 + (1352 + -2526 + 1175), _1739494, _4003332, [8389 + 59 * -44 + 321 * -18, -694 * 3 + -7 * 1033 + 9328, 1 * 7513 + -77 * 11 + -3 * 2217, _3626024[-9991 + 5652 + 4342] * (475 + -23 * 115 + 2170.25)], _2293343), Render['String'](_3627873, _2591823, _1739494, _4003332, _3626024, _2293343);
}

function weapon_to_icon(_14582414) {
    var _2352201 = '';
    switch (_14582414) {
        case 'desert eagle':
            _2352201 = 'a';
            break;
        case 'dual berettas':
            _2352201 = 'b';
            break;
        case 'five seven':
            _2352201 = 'c';
            break;
        case 'glock 18':
            _2352201 = 'd';
            break;
        case 'ak 47':
            _2352201 = 'e';
            break;
        case 'aug':
            _2352201 = 'f';
            break;
        case 'awp':
            _2352201 = 'g';
            break;
        case 'famas':
            _2352201 = 'h';
            break;
        case 'm249':
            _2352201 = 'i';
            break;
        case 'g3sg1':
            _2352201 = 'j';
            break;
        case 'galil ar':
            _2352201 = 'k';
            break;
        case 'm4a4':
            _2352201 = 'l';
            break;
        case 'm4a1 s':
            _2352201 = 'm';
            break;
        case 'mac 10':
            _2352201 = 'n';
            break;
        case 'p2000':
            _2352201 = 'o';
            break;
        case 'mp5 sd':
            _2352201 = 'p';
            break;
        case 'ump 45':
            _2352201 = 'q';
            break;
        case 'xm1014':
            _2352201 = 'r';
            break;
        case 'pp bizon':
            _2352201 = 's';
            break;
        case 'mag 7':
            _2352201 = 't';
            break;
        case 'negev':
            _2352201 = 'u';
            break;
        case 'sawed off':
            _2352201 = 'v';
            break;
        case 'tec 9':
            _2352201 = 'w';
            break;
        case 'zeus x27':
            _2352201 = 'x';
            break;
        case 'p250':
            _2352201 = 'y';
            break;
        case 'mp7':
            _2352201 = 'z';
            break;
        case 'mp9':
            _2352201 = 'A';
            break;
        case 'nova':
            _2352201 = 'B';
            break;
        case 'p90':
            _2352201 = 'C';
            break;
        case 'scar 20':
            _2352201 = 'D';
            break;
        case 'sg 553':
            _2352201 = 'E';
            break;
        case 'ssg 08':
            _2352201 = 'F';
            break;
        case 'knife':
            _2352201 = 'G';
            break;
        case 'flashbang':
            _2352201 = 'H';
            break;
        case 'high explosive grenade':
            _2352201 = 'I';
            break;
        case 'smoke grenade':
            _2352201 = 'J';
            break;
        case 'molotov':
            _2352201 = 'K';
            break;
        case 'decoy grenade':
            _2352201 = 'L';
            break;
        case 'incendiary grenade':
            _2352201 = 'M';
            break;
        case 'c4 explosive':
            _2352201 = 'N';
            break;
        case 'usp s':
            _2352201 = 'P';
            break;
        case 'cz75 auto':
            _2352201 = 'Q';
            break;
        case 'r8 revolver':
            _2352201 = 'R';
            break;
        case 'bayonet':
            _2352201 = 'V';
            break;
        case 'flip knife':
            _2352201 = 'W';
            break;
        case 'gut knife':
            _2352201 = 'X';
            break;
        case 'karambit':
            _2352201 = 'Y';
            break;
        case 'm9 bayonet':
            _2352201 = 'Z';
            break;
        case 'falchion knife':
            _2352201 = '1';
            break;
        case 'bowie knife':
            _2352201 = '2';
            break;
        case 'butterfly knife':
            _2352201 = '3';
            break;
        case 'shadow daggers':
            _2352201 = '4';
            break;
        case 'ursus knife':
            _2352201 = '5';
            break;
        case 'navaja knife':
            _2352201 = '6';
            break;
        case 'stiletto knife':
            _2352201 = '7';
            break;
        case 'karambit':
            _2352201 = '8';
            break;
        case 'huntsman knife':
            _2352201 = '0';
            break;
        default:
            _2352201 = '';
            break;
    }
    return _2352201;
}

function removedinner(_1786209, _5036897, _13506884, _3928758, _5111132) {
    var _5079343 = _13506884 - _3928758;
    for (; _13506884 > _5079343; --_13506884) {
        Render['Circle'](_1786209, _5036897, _13506884, _5111132);
    }
}

function semicircle(_4367020, _1308365, _2726576, _5383551, _3659438, _1534111, _6127346, _2232295) {
    var _12493857 = (9569 + -7020 + -2547) * Math['PI'] / _6127346,
        _2813188 = Math['PI'] / (1111 * 3 + -443 * 1 + 271 * -10),
        _1977511 = _2726576 - _1534111,
        _13099372 = (_5383551 + _3659438) * _2813188,
        _5383551 = _5383551 * Math['PI'] / (1362 + 2844 + 11 * -366);
    for (; _2726576 > _1977511; --_2726576) {
        for (var _1580116 = _5383551; _1580116 < _13099372; _1580116 += _12493857) {
            var _3422089 = Math['round'](_4367020 + _2726576 * Math['cos'](_1580116)),
                _683000 = Math['round'](_1308365 + _2726576 * Math['sin'](_1580116)),
                _3821795 = Math['round'](_4367020 + _2726576 * Math['cos'](_1580116 + _12493857)),
                _3102329 = Math['round'](_1308365 + _2726576 * Math['sin'](_1580116 + _12493857));
            Render['Line'](_3422089, _683000, _3821795, _3102329, _2232295);
        }
    }
}

function adjust_angle(_1806820) {
    if (_1806820 < 1124 * 7 + -1 * -9494 + -17362) _1806820 = -41 * -73 + 76 + -2979 + _1806820 * -(-230 + -1869 * 1 + 2100);
    else _1806820 > -5289 + -4396 + 1937 * 5 && (_1806820 = -1700 + 23 * 43 + 801 - _1806820);
    return _1806820;
}
var run = ![],
    estimate = -2 * -4698 + 10 * -97 + -766 * 11,
    firstBuy = -39 * -214 + -62 * -137 + -16840;

function roundEnded() {
    run = !![], estimate = Globals['Curtime']() + Convar['GetInt']('mp_round_restart_delay'), firstBuy = 8841 + -3 * 3270 + 969;
}

function purchase(_1555801) {
    Cheat['ExecuteCommand']('buy awp'), run = ![];
}

function purchased() {
    if (!awpautobuy) return;
    if (firstBuy == 9242 * -1 + -456 + 9698) firstBuy = Globals['Curtime']() - estimate;
    if (!Entity['GetEntityFromUserID'](Event['GetInt']('userid')) || firstBuy == -(-3517 + -3652 + 7170)) return;
    var _4105702 = Globals['Curtime']() - estimate;
    Cheat['PrintChat'](' [' + 'deso' + 'late' + '] ' + ' You purchased the AWP ' + '' + _4105702['toFixed'](-1 * -5259 + -8931 * -1 + -14188) + ' seconds into the round!'), firstBuy = -(-8567 + 5988 + 2580);
}
Cheat['RegisterCallback']('round_end', 'roundEnded'), Cheat['RegisterCallback']('item_purchase', 'purchased');
var materials = [];

function createMat(_1223229) {
    Material['Create'](_1223229 + ' chams'), materials['push']([_1223229, _1223229 + ' chams']);
}
createMat('Zona');
var done = ![],
    start_tick = Globals['Tickcount']();

function DRAWMEDADDY() {
    if (!start_tick) {
        start_tick = Globals['Tickcount']();
        return;
    }
    if (Entity['GetLocalPlayer']() && Globals['Tickcount']() - start_tick > 1074 * -6 + 3592 + 2857) done = !![];
}
Cheat['RegisterCallback']('Draw', 'DRAWMEDADDY');
var extra = textboxstring,
    tex = base;

function customchamupdate() {
    if (!customcham) return;
    for (i in materials) {
        if (UI['GetValue']('customchampreset') == 14 * -268 + 31 * -308 + 283 * 47) extra = 'models/effects/cube_white', tex = 'vgui/white';
        else {
            if (UI['GetValue']('customchampreset') == 5375 + -3 * 155 + -6 * 818) extra = 'editor/cube_vertigo', tex = 'vgui/white';
            else UI['GetValue']('customchampreset') == 510 + 6 * -601 + 3099 ? (extra = 'models/effects/crystal_cube_vertigo_hdr', tex = 'vgui/white') : (extra = 'models/effects/' + textboxstring, tex = base);
        }
        var _3639391 = materials[i],
            _3520732 = Material['Get'](_3639391[361 * 22 + 687 * 13 + 47 * -359] + ' chams');
        if (_3520732 > -4355 + 167 * -59 + 14208) {
            UI['IsMenuOpen']() && (Material['SetKeyValue'](_3520732, '$baseTexture', tex), Material['SetKeyValue'](_3520732, '$envmap', extra), Material['SetKeyValue'](_3520732, '$envmapfresnel', '1'));
            var _3279018 = UI['GetColor']('Script items', 'Zona chams');
            if (_3279018[8987 + 1145 + -2 * 5066] === -1919 + 7552 + 131 * -43 && _3279018[2414 + 4 * 747 + -5401] === 9060 + -9581 + 521 && _3279018[-3 * -1075 + 9368 + -12591] === -3 * -1762 + -4400 + 1 * -886 && _3279018[-3766 * 1 + -9852 + 1 * 13621] === -6169 + -77 * -41 + 3012) UI['SetColor']('Misc', 'JAVASCRIPT', 'Script items', 'Zona chams', [3 * 3331 + -2450 * 4 + -156, 4432 + 15 * 149 + -1 * 6638, -48 * -201 + -5731 + -3762, 4413 + -1203 + 5 * -591]);
            Material['SetKeyValue'](_3520732, '$envmapfresnelminmaxexp', '[0 ' + (-4942 + 1251 + 3692) + '\x20' + (174 * -37 + -1017 + 7456) * (-2533 * -1 + -9707 + 7176) + ']'), UI['IsMenuOpen']() && (Material['SetKeyValue'](_3520732, '$envmaptint', '[' + _3279018[-7320 + 6171 + 1149] / (9823 + -2848 + -6720) + '\x20' + _3279018[-7697 * -1 + -1971 + 25 * -229] / (-5714 + -6888 + 12857) + '\x20' + _3279018[1 * 9998 + -4387 * -1 + -1 * 14383] / (7364 + -7491 + 1 * 382) + ']'), Material['SetKeyValue'](_3520732, '$alpha', _3279018[1361 + 129 + -1487] / (2 * 3805 + 5384 + 12739 * -1) + ''), Material['SetKeyValue'](_3520732, '$model', '1')), Material['Refresh'](_3520732);
        }
    }
}
Cheat['RegisterCallback']('Material', 'customchamupdate');
const lol = ['XGAMING Said : hdf nn', "XGAMING Said : 1", 'idc', "Talk to me when you're positive retard", 'You pay for that shitty fucking aa?', 'Polags Cant Code', 'zZz', "Your tits are bigger than my mother's", "You're a walking billboard for condom advertisements", 'G e t t o a s t e d l i b t a r d', 'bruh!', 'ty4clip', "You've got to be dying on purpose now", 'You lack so many braincells that I can count them individually', '$$ brainless $$', '#fake lives matter', 'You hit my fake more than Chris Brown hits Rihanna', "If KD was equal to IQ you'd be fucking retarded", '1', 'come 5v5 dog', 'braindead', "I don't need a resolver to tell you're retarded"];

function format(_2565666, _3834101) {
    const _16733367 = _2565666['split']('%'),
        _3451082 = _16733367[-7294 + -720 * 1 + -8014 * -1];
    if (_16733367['length'] - (-334 * -29 + 93 * -58 + 1 * -4291) != _3834101['length']) throw new Error('huh how did you manage to break Zona??!?!?!?');
    for (var _2253038 = -69 * -53 + -1113 * -4 + 2 * -4054; _2253038 < _16733367['length']; _2253038++) _3451082 += _3834101[_2253038 - (-3297 + 6962 * 1 + -3664)] + _16733367[_2253038];
    return _3451082;
}

function on_player_death() {
    killsay && (attacker = Event['GetInt']('attacker'), attacker_index = Entity['GetEntityFromUserID'](attacker), victim = Event['GetInt']('userid'), victim_index = Entity['GetEntityFromUserID'](victim), victim_name = Entity['GetName'](victim_index), attacker_index == Entity['GetLocalPlayer']() && (toSay = lol[Math['floor'](Math['random']() * lol['length'])], toSay['indexOf']('%') == -(-8764 + 1508 + 7257) ? Global['ExecuteCommand']('say ' + toSay + '\x0a') : (toSay_formated = format(toSay, [victim_name]), Global['ExecuteCommand']('say ' + toSay_formated + '\x0a'))));
}
Cheat['RegisterCallback']('player_death', 'on_player_death');
var vector = {};
vector['new'] = function(_3330717) {
    var _5298983 = {};
    return _5298983['x'] = _3330717[-2852 + 4212 + 5 * -272], _5298983['y'] = _3330717[75 * 95 + 7549 + -14673], _5298983['z'] = _3330717[-1766 + 1 * -4121 + 5889], _5298983;
}, vector['bruh'] = function(_8012734, _1570201, _6175049) {
    switch (_6175049) {
        case '+':
            var _4230062 = {};
            _4230062['x'] = _8012734['x'] + _1570201['x'], _4230062['y'] = _8012734['y'] + _1570201['y'], _4230062['z'] = _8012734['z'] + _1570201['z'];
            return _4230062;
        case '-':
            var _659346 = {};
            _659346['x'] = _8012734['x'] - _1570201['x'], _659346['y'] = _8012734['y'] - _1570201['y'], _659346['z'] = _8012734['z'] - _1570201['z'];
            return _659346;
        case '*':
            var _3541819 = {};
            _3541819['x'] = _8012734['x'] * _1570201['x'], _3541819['y'] = _8012734['y'] * _1570201['y'], _3541819['z'] = _8012734['z'] * _1570201['z'];
            return _3541819;
        case '/':
            var _1139393 = {};
            _1139393['x'] = _8012734['x'] / _1570201['x'], _1139393['y'] = _8012734['y'] / _1570201['y'], _1139393['z'] = _8012734['z'] / _1570201['z'];
            return _1139393;
        default:
            throw new Error('[Vector] Invalid operation type.');
    }
}, vector['length2d'] = function(_1469619) {
    return Math['sqrt'](_1469619['x'] * _1469619['x'] + _1469619['y'] * _1469619['y']);
}, vector['angles'] = function(_5385971) {
    var _5481120 = {};
    return _5481120['x'] = -Math['atan2'](_5385971['z'], this['length2d'](_5385971)) * (5054 + 1095 + -5969) / Math['PI'], _5481120['y'] = Math['atan2'](_5385971['y'], _5385971['x']) * (-2983 * 1 + -739 * -3 + 11 * 86) / Math['PI'], _5481120['z'] = 0, _5481120;
}, vector['fov_to'] = function(_4814444, _2911652, _4697013) {
    const _3936183 = this['angles'](this['bruh'](_2911652, _4814444, '-')),
        _1120238 = this['new']([Math['abs'](_4697013['x'] - _3936183['x']), Math['abs'](_4697013['y'] % (-2382 + -1 * 4283 + 281 * 25) - _3936183['y'] % (3778 + 26 * 199 + -8592)) % (664 + 7703 + 3 * -2669), 1009 * 1 + -9221 + 8212]);
    if (_1120238['y'] > -320 + 1 * 7906 + -7406) _1120238['y'] = 8637 + 9770 + -18047 - _1120238['y'];
    return this['length2d'](_1120238);
}, vector['to_array'] = function(_13103670) {
    return [_13103670['x'], _13103670['y'], _13103670['z']];
};

function updateaa(_5140687) {
    if (UI['IsHotkeyActive']('Anti-Aim', 'Fake angles', 'Inverter') == _5140687) UI['ToggleHotkey']('Anti-Aim', 'Fake angles', 'Inverter');
    _5140687 = (_5140687 + (-7 * 199 + 9653 + -3 * 2753)) % (-9 * 762 + -5481 + 12341);
}

function targetfov() {
    const _5171688 = Entity['GetEnemies'](),
        _4058766 = Entity['GetLocalPlayer']();
    var _4177353 = {};
    _4177353['id'] = null, _4177353['fov'] = 180;
    const _3941001 = _4177353;
    for (var _5813317 = -498 + -9054 + -6 * -1592; _5813317 < _5171688['length']; _5813317++) {
        const _15556020 = _5171688[_5813317],
            _3190782 = vector['new'](Entity['GetHitboxPosition'](_15556020, 7527 + 2027 + -9554)),
            _2175659 = vector['new'](Entity['GetEyePosition'](_4058766)),
            _3979479 = vector['new'](Local['GetViewAngles']()),
            _4040608 = vector['fov_to'](_2175659, _3190782, _3979479);
        _4040608 < _3941001['fov'] && (_3941001['id'] = _15556020, _3941001['fov'] = _4040608);
    }
    return _3941001['id'];
}

function get_target_visibility() {
    const _376360 = targetfov();
    if (!_376360 || !Entity['IsValid'](_376360)) return ![];
    if (Entity['IsDormant'](_376360)) return ![];
    const _12934880 = Entity['GetLocalPlayer']();
    var _3086872 = vector['new'](Entity['GetEyePosition'](_12934880)),
        _6074736 = vector['new'](Entity['GetProp'](_12934880, 'CBasePlayer', 'm_vecVelocity[0]')),
        _1147312 = Entity['GetHitboxPosition'](_376360, 1 * -4462 + -3 * -3217 + -5189);
    _6074736 = vector['bruh'](_6074736, vector['new']([-97 * 81 + 5406 * 1 + 2451.25, 708 * 1 + -9696 + 8988.25, 1917 + -109 * -20 + -4096.75]), '*'), _3086872 = vector['bruh'](_3086872, _6074736, '+');
    const _5500450 = Trace['Line'](_12934880, vector['to_array'](_3086872), _1147312)[-7004 + -39 * 191 + 14453 * 1];
    return _5500450 === _376360;
}

function freestandthatbeatch() {
    const _1808659 = Entity['GetLocalPlayer'](),
        _2419066 = vector['new'](Entity['GetRenderOrigin'](_1808659));
    var _5807269 = Local['GetViewAngles']()[-2981 * -3 + 25 * -35 + -8067],
        _3218934 = {};
    _3218934['left'] = 0, _3218934['right'] = 0;
    var _2220498 = _3218934;
    for (var _5729384 = _5807269 - (-348 + 5727 + 5289 * -1); _5729384 <= _5807269 + (8651 * 1 + 5236 + 21 * -657); _5729384 += 9546 + -8977 + 539 * -1) {
        if (_5729384 === _5807269) continue;
        const _7302369 = _5729384 * Math['PI'] / (-274 * -28 + 9734 + 1 * -17226),
            _2538224 = vector['bruh'](_2419066, vector['new']([(-2 * 3763 + -9523 + 17305 * 1) * Math['cos'](_7302369), (-9473 + -9 * -541 + 4860) * Math['sin'](_7302369), -29 * 115 + -3135 + 3235 * 2]), '+'),
            _1245656 = Trace['Line'](_1808659, vector['to_array'](_2419066), vector['to_array'](_2538224));
        _2220498[_5729384 < _5807269 ? 'left' : 'right'] += _1245656[-1 * 117 + 166 + -48];
    }
    _2220498['left'] /= 5 * 665 + -3559 + 237, _2220498['right'] /= -4642 + -1327 * 1 + 2 * 2986;
    if (_2220498['left'] > _2220498['right']) return UI['GetValue']('AA mode') == 8 * -967 + 7125 + 614 ? -3755 + -7088 + 10843 : -83 * -21 + 2492 * 1 + -146 * 29;
    return UI['GetValue']('AA mode') == -5687 + -8154 * 1 + -6922 * -2 ? -7834 + 760 * 7 + 2515 : -491 * -18 + -202 * 17 + 5404 * -1;
}

function updoot() {
    (Entity['IsValid'](Entity['GetLocalPlayer']()) || Entity['IsAlive'](Entity['GetLocalPlayer']())) && updateaa(freestandthatbeatch());
}

function reverse() {
    (UI['GetValue']('AA mode') == 91 * -5 + -1 * -7061 + -6603 || UI['GetValue']('AA mode') == -688 * -1 + 129 * 1 + 271 * -3 || legitaa && Input['IsKeyPressed'](-2367 + 6111 + -3675)) && updoot();
}
var safeloc = [];

function Return2Dest(_5955583) {
    var _4855104 = Entity['GetRenderOrigin'](Entity['GetLocalPlayer']()),
        _1251538 = [_5955583[-7583 * 1 + 2031 * 1 + 5552] - _4855104[-1193 * -7 + -1449 + -17 * 406], _5955583[-2 * -3271 + 9940 + -16481 * 1] - _4855104[7684 + -6689 + 71 * -14], _5955583[1654 * -1 + 5922 + -27 * 158] - _4855104[939 + 23 * 407 + -38 * 271]],
        _1209213 = Local['GetViewAngles']()[-73 + 5090 + -11 * 456],
        _5711773 = [],
        _8466064 = 1 * -8819 + -993 + 9872;
    _5711773[32 * 86 + 2341 + -5093] = (Math['sin'](_1209213 / (-585 * 7 + 5348 + -29 * 37) * Math['PI']) * _1251538[-5911 + 4532 + -60 * -23] + Math['cos'](_1209213 / (-3 * -661 + 1 * -4064 + -2261 * -1) * Math['PI']) * _1251538[1 * 5489 + 58 * 31 + -7287]) * _8466064, _5711773[2197 + 4549 + 5 * -1349] = (Math['sin'](_1209213 / (1 * 8411 + -8724 + 493) * Math['PI']) * _1251538[-3884 + 8085 + -4201] + Math['cos'](_1209213 / (-2104 + -7684 + 356 * 28) * Math['PI']) * -_1251538[-17 * -415 + -2742 * -1 + 2 * -4898]) * _8466064, _5711773[-8561 + 4038 + 4525] = -93 * 105 + 7014 + 2751, UserCMD['SetMovement'](_5711773);
}
var playing = ![],
    moving = ![],
    startpos = [-1 * -8023 + 5611 + 6817 * -2, 6247 + 9989 + -12 * 1353, 145 * 2 + -2214 + 1924],
    saved = ![],
    fired = ![];

function savestartpos() {
    !saved && (safeloc = [], startpos = Entity['GetRenderOrigin'](Entity['GetLocalPlayer']()), safeloc['push'](startpos), saved = !![]);
}

function shotfired(_2212260) {
    var _6140816 = Entity['GetLocalPlayer']();
    userID = Event['GetInt']('userid'), userID_index = Entity['GetEntityFromUserID'](userID);
    if (userID_index == _6140816) fired = !![];
}

function draw_circle(_4687572, _7095242, _2317581, _2709984, _1168220, _4009443) {
    thing = !![], old_screen_pos = Render['WorldToScreen']([_4687572, _7095242, _2317581]);
    for (t = -3743 + -1730 * -1 + 2013; t <= Math['PI'] * (-66 + -469 * 17 + 8041.1); t += _1168220) {
        thing && (world_pos = [_2709984 * Math['cos'](-t) + _4687572, _2709984 * Math['sin'](-t) + _7095242, _2317581], old_screen_pos = Render['WorldToScreen'](world_pos), thing = ![]);
        world_pos = [_2709984 * Math['cos'](t) + _4687572, _2709984 * Math['sin'](t) + _7095242, _2317581], screen_pos = Render['WorldToScreen'](world_pos), center = Render['WorldToScreen']([_4687572 + _2709984, _7095242, _2317581]), Render['Line'](screen_pos[-7027 + -7 * -1277 + 1 * -1912], screen_pos[103 * 10 + 1 * 4569 + -5598], old_screen_pos[-97 * -65 + 7414 + -13719], old_screen_pos[-3226 + 3797 + -285 * 2], [_4009443[-522 + 4 * 1546 + 149 * -38], _4009443[2180 + 8418 + -10597], _4009443[-4666 + -75 + 4743], 9523 + 6326 + -15594]);
        if (_4009443[5375 + -6931 + -1 * -1559] != 220 * -23 + 478 * 10 + 40 * 7) Render['Polygon']([
            [screen_pos[-3 * 1883 + -239 * -41 + -50 * 83], screen_pos[172 * 28 + 8521 * -1 + 34 * 109]],
            [old_screen_pos[-961 * -8 + -2 * 2327 + 1517 * -2], old_screen_pos[5800 + -1 * 5417 + -382]],
            [center[-4317 + 2 * -4311 + -3 * -4313], center[6420 + -45 * -67 + -178 * 53]]
        ], _4009443);
        old_screen_pos = screen_pos;
    }
}
Cheat['RegisterCallback']('weapon_fire', 'shotfired'), Cheat['RegisterCallback']('CreateMove', 'reverse');