Cheat.ExecuteCommand( "cl_csm_shadows 0" );
Cheat.ExecuteCommand( "cl_csm_rope_shadows 0" );
Cheat.ExecuteCommand( "cl_csm_world_shadows 0" );
Cheat.ExecuteCommand( "cl_csm_world_shadows_in_viewmodelcascade 0" );
Cheat.ExecuteCommand( "cl_csm_static_prop_shadows 0" );
Cheat.ExecuteCommand( "cl_csm_sprite_shadows 0" );
Cheat.ExecuteCommand( "cl_csm_translucent_shadows 0" );
Cheat.ExecuteCommand( "cl_csm_viewmodel_shadows 0" );
Cheat.ExecuteCommand( "cl_csm_entity_shadows 0" );

Cheat.ExecuteCommand( "r_shadows 0" );
Cheat.ExecuteCommand( "r_3dsky 0" );

Cheat.ExecuteCommand( "fog_enable 0" );
Cheat.ExecuteCommand( "fog_enable_water_fog 0" );
Cheat.ExecuteCommand( "fog_enableskybox 0" );
Cheat.ExecuteCommand( "mat_disable_bloom 1" );