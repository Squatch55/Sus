UI.AddCheckbox("premium trashtalk");

const normal_killsays = [
"1",
"Бля что то у тебя АА сломались, даже 1 улетаешь",
"Фиксанешь АА?",
"Бездарь, ты хотя бы играть научись",
"Куда рашишь? Нькамер позоду...",
"Бля ты так сочно отлетаешь",
"Owned By LyaGuShKa",
"Госопди, ты 1 улетаешь от чела, у которого скыт.рф, как тебе не стыдно",
"Бля я тебя даже не успел увидеть, а ты уже мертв(",
"Ну с таким playstyle тебе путь только в одноклассники...",
"Может перестанешь юзать free софты и купишь приват?",
"Ну блиин, против тебя скучно( каждый раз 1 улетаешь"
];
    
const hs_killsays = [
"1",
"Бля что то у тебя АА сломались, даже 1 улетаешь",
"Фиксанешь АА?",
"Бездарь, ты хотя бы играть научись",
"Куда рашишь? Нькамер позоду...",
"Бля ты так сочно отлетаешь",
"Owned By LyaGuShKa",
"Госопди, ты 1 улетаешь от чела, у которого скыт.рф, как тебе не стыдно",
"Бля я тебя даже не успел увидеть, а ты уже мертв(",
"Ну с таким playstyle тебе путь только в одноклассники...",
"Может перестанешь юзать free софты и купишь приват?",
"Ну блиин, против тебя скучно( каждый раз 1 улетаешь"
];

function on_player_death()
{
    if(UI.GetValue("Misc", "premium trashtalk"))
    {
        const victim = Entity.GetEntityFromUserID(Event.GetInt("userid"));
        const attacker = Entity.GetEntityFromUserID(Event.GetInt("attacker"));
        const headshot = Event.GetInt("headshot") == 1;
        
        if(Entity.IsLocalPlayer(attacker) && attacker != victim)
        {
            const normal_say = normal_killsays[Math.floor(Math.random() * normal_killsays.length)];
            const hs_say = hs_killsays[Math.floor(Math.random() * hs_killsays.length)];
            
            if(headshot && Math.random() * 2 > 1) //gamer style randomizer
            {
                Cheat.ExecuteCommand("say " + hs_say);
                return;
            }
            Cheat.ExecuteCommand("say " + normal_say);
        }
    }
}

var killsay_amt = normal_killsays.length + hs_killsays.length;

Cheat.Print("trashtalk js loaded, killsay count: " + killsay_amt + "\n");
Cheat.RegisterCallback("player_death", "on_player_death");