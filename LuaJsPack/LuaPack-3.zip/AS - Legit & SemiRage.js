/* 
 *    Prime-Friendly features
 */
var gui = require("AntiSaint/AntiSaintUI.js");
var feature = require("AntiSaint/AntiSaintLib.js");

UI.AddLabel("----------------------------------------"); //40 dashes
UI.AddLabel("OOF's Closet Companion");
UI.AddHotkey("Toggle Esp");
UI.AddDropdown("Esp Mode", ["Minimal", "Standard", "Maximal"]);
UI.AddLabel("----------------------------------------"); //40 dashes
UI.AddHotkey("Enable Autowall");
UI.AddCheckbox("No AA Flick");
UI.AddLabel("----------------------------------------"); //40 dashes
UI.AddSliderInt("Pistol Hitchance", 0, 100);
UI.AddSliderInt("Heavy Pistol Hitchance", 0, 100);
UI.AddSliderInt("Scout Hitchance", 0, 100);
UI.AddSliderInt("Awp Hitchance", 0, 100);
UI.AddSliderInt("Auto Hitchance", 0, 100);
UI.AddSliderInt("Rifle Hitchance", 0, 100); 

var legitAA = gui.getLegitAA("Enabled"); var rageAA = gui.getRageAA("Enabled");

function toggleEsp() {
    if (UI.IsHotkeyActive("Misc", "Script items", "Toggle Esp")) {
        switch (UI.GetValue("Misc", "Script items", "Esp Mode")) {
            case 0:
                //Enables Esp Functions
                UI.SetValue("Visual", "ENEMIES", "Box", 1);
                UI.SetValue("Visual", "ENEMIES", "Name", 1);
                //Disables Esp Functions
                UI.SetValue("Visual", "ENEMIES", "Glow", 0);
                UI.SetValue("Visual", "ENEMIES", "Health", 0);
                UI.SetValue("Visual", "ENEMIES", "Dormant", 0);
                UI.SetValue("Visual", "ENEMIES", "Weapon", 0);
                UI.SetValue("Visual", "ENEMIES", "Ammo", 0);
                UI.SetValue("Visual", "ENEMIES", "Skeleton", 0);
                break;
            case 1:
                //Enables Esp Functions
                UI.SetValue("Visual", "ENEMIES", "Box", 0);
                UI.SetValue("Visual", "ENEMIES", "Name", 1);
                UI.SetValue("Visual", "ENEMIES", "Health", 1);
                UI.SetValue("Visual", "ENEMIES", "Weapon", 2);
                UI.SetValue("Visual", "ENEMIES", "Ammo", 1);
                UI.SetValue("Visual", "ENEMIES", "Glow", 1);
                //Disables Esp Functions
                UI.SetValue("Visual", "ENEMIES", "Dormant", 0);
                UI.SetValue("Visual", "ENEMIES", "Skeleton", 0);
                break;
            case 2:
                //Enables Esp Functions
                UI.SetValue("Visual", "ENEMIES", "Box", 1);
                UI.SetValue("Visual", "ENEMIES", "Name", 1);
                UI.SetValue("Visual", "ENEMIES", "Health", 1);
                UI.SetValue("Visual", "ENEMIES", "Weapon", 1);
                UI.SetValue("Visual", "ENEMIES", "Ammo", 1);
                UI.SetValue("Visual", "ENEMIES", "Glow", 1);
                UI.SetValue("Visual", "ENEMIES", "Dormant", 1);
                UI.SetValue("Visual", "ENEMIES", "Skeleton", 1);
                break;
        }
    } else { UI.SetValue("Visual", "ENEMIES", "Box", 0); UI.SetValue("Visual", "ENEMIES", "Name", 0); UI.SetValue("Visual", "ENEMIES", "Health", 0); UI.SetValue("Visual", "ENEMIES", "Weapon", 0); UI.SetValue("Visual", "ENEMIES", "Ammo", 0); UI.SetValue("Visual", "ENEMIES", "Glow", 0); UI.SetValue("Visual", "ENEMIES", "Dormant", 0); UI.SetValue("Visual", "ENEMIES", "Skeleton", 0); }
} Cheat.RegisterCallback("Draw", "toggleEsp");
function doLegitAA() {
    if (gui.getScriptVal("No AA Flick") == 1) {
        UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", 0);
        UI.SetValue("Anti-Aim", "Fake-Lag", "Jitter", 0);
        UI.SetValue("Anti-Aim", "Fake-Lag", "Triggers", 2);
        UI.SetValue("Anti-Aim", "Fake-Lag", "Trigger limit", 0);
        const ping = Math.floor(Global.Latency() * 1000 / 1.5);
        const maxping = 100;
        const fps = Math.floor(1 / Global.Frametime());
        var tickRate = Globals.Tickcount();
        if (fps <= tickRate) {
            if (legitAA) {
                UI.SetValue("Anti-Aim", "Legit Anti-Aim", "Enabled", false);
            } else if (rageAA) {
                UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Enabled", false);
            }
        } else {
            if (legitAA == 1) {
                UI.SetValue("Anti-Aim", "Legit Anti-Aim", "Enabled", true);
            } else if (rageAA) {
                UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Enabled", true);
            }
        }
        if (ping >= maxping) {
            if (legitAA) {
                UI.SetValue("Anti-Aim", "Legit Anti-Aim", "Enabled", false);
            } else if (rageAA) {
                UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Enabled", false);
            }
        } else {
            if (legitAA) {
                UI.SetValue("Anti-Aim", "Legit Anti-Aim", "Enabled", true);
            } else if (rageAA) {
                UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Enabled", true);
            }
        }
        AntiAim.SetOverride(1);
        var inverter = UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter");
        if (inverter) { AntiAim.SetRealOffset(60); } else { AntiAim.SetRealOffset(60); }
    }
} Cheat.RegisterCallback("Draw", "doLegitAA");
function handleSemiRage() {
    var pistol_hitchance = gui.getScriptVal("Pistol Hitchance");
    var heavypistol_hitchance = gui.getScriptVal("Heavy Pistol Hitchance");
    var scout_hitchance = gui.getScriptVal("Scout Hitchance");
    var awp_hitchance = gui.getScriptVal("Awp Hitchance");
    var auto_hitchance = gui.getScriptVal("Auto Hitchance");
    var rifle_hitchance = gui.getScriptVal("Rifle Hitchance");
    var weapon = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));
    var weapon_category = feature.getWeaponCategory(weapon);
    switch (weapon_category) {
        case "PISTOL": UI.SetValue("Legit", "GENERAL", "Triggerbot", "Hitchance", pistol_hitchance); break;
        case "HEAVY PISTOL": UI.SetValue("Legit", "GENERAL", "Triggerbot", "Hitchance", heavypistol_hitchance); break;
        case "SCOUT": UI.SetValue("Legit", "GENERAL", "Triggerbot", "Hitchance", scout_hitchance); break;
        case "AWP": UI.SetValue("Legit", "GENERAL", "Triggerbot", "Hitchance", awp_hitchance); break;
        case "AUTOSNIPER": UI.SetValue("Legit", "GENERAL", "Triggerbot", "Hitchance", auto_hitchance); break;
        case "GENERAL": UI.SetValue("Legit", "GENERAL", "Triggerbot", "Hitchance", rifle_hitchance); break;
    }
    if (UI.IsHotkeyActive("Misc", "Script items", "Enable Autowall") == 1) {
        UI.SetValue("Rage", "PISTOL", "Pistol config", "Disable autowall", 0);
        UI.SetValue("Rage", "HEAVY PISTOL", "Heavy pistol config", "Disable autowall", 0);
        UI.SetValue("Rage", "SCOUT", "Scout config", "Disable autowall", 0);
        UI.SetValue("Rage", "AWP", "AWP config", "Disable autowall", 0);
        UI.SetValue("Rage", "AUTOSNIPER", "Auto config", "Disable autowall", 0);
        UI.SetValue("Rage", "GENERAL", "Targeting", "Disable autowall", 0);
    } else { UI.SetValue("Rage", "PISTOL", "Pistol config", "Disable autowall", 1); UI.SetValue("Rage", "HEAVY PISTOL", "Heavy pistol config", "Disable autowall", 1); UI.SetValue("Rage", "SCOUT", "Scout config", "Disable autowall", 1); UI.SetValue("Rage", "AWP", "AWP config", "Disable autowall", 1); UI.SetValue("Rage", "AUTOSNIPER", "Auto config", "Disable autowall", 1); UI.SetValue("Rage", "GENERAL", "Targeting", "Disable autowall", 1); }
    var weapon_category = feature.getWeaponCategory(Entity.GetWeapon(Entity.GetLocalPlayer()));
} Cheat.RegisterCallback("Draw", "handleSemiRage");