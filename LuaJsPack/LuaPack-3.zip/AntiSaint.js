/*
 
    This Script is homosexual.
    Enjoy it you faggot...
 
 */
var gui = require("AntiSaint/AntiSaintUI.js");
var feature = require("AntiSaint/AntiSaintLib.js");

UI.AddLabel("----------------------------------------"); //40 dashes
UI.AddLabel("Features By OOF . RIF");
UI.AddCheckbox("Draw Overlay Information");
UI.AddCheckbox("Draw Hitlogs");
UI.AddCheckbox("Indicator");
UI.AddMultiDropdown("Draw Misc Features", feature.misc_settings);
UI.AddMultiDropdown("Draw Anti-Aim Indicators", feature.antiaim_indicators);
UI.AddMultiDropdown("Draw Ragebot Indicators", feature.ragebot_indicators);
UI.AddMultiDropdown("Draw Information", feature.visual_info);
UI.AddDropdown("Anti-Aim Presets", feature.antiaim_presets);

var count1 = 0; var count2 = 0; var count3 = 0;
var body_count = 0;

function drawVisuals() {
    //colours
    var offWhite    = [255, 255, 215, 255];
    var purple      = [255, 0, 255, 255];
    var niceBlue    = [0, 255, 255, 255];
    var deepBlue    = [0, 155, 255, 255];
    var yellowGreen = [155, 255, 0, 255];
    //local player info
    var localPlayer = Entity.GetLocalPlayer();
    var localName = Entity.GetName(localPlayer);
    var fakeYaw = Math.floor(Local.GetFakeYaw());
    var realYaw = Math.floor(Local.GetRealYaw());
    var lbyYaw = Math.floor(Entity.GetProp(localPlayer, "CCSPlayer", "m_flLowerBodyYawTarget"));
    var viewangles = Local.GetViewAngles();
    var latency = Math.floor(Local.Latency());
    var fakePing = Math.floor(Entity.GetProp(localPlayer, "CPlayerResource", "m_iPing"));
    var username = Cheat.GetUsername();
    var eyePos = Entity.GetEyePosition(localPlayer);
    var kills = Math.floor(Entity.GetProp(localPlayer, "CPlayerResource", "m_iKills"));
    var deaths = Math.floor(Entity.GetProp(localPlayer, "CPlayerResource", "m_iDeaths"));
    var assists = Math.floor(Entity.GetProp(localPlayer, "CPlayerResource", "m_iAssists"));
    var kd = Math.floor(kills / deaths);
    //server info
    var serverIP = World.GetServerString();
    var mapName = World.GetMapName();
    //entity info
    var cur_wep = Entity.GetName(Entity.GetWeapon(localPlayer));
    //render stupid shit
    if (gui.getScriptVal("Draw Overlay Information")) {
        //render local info
        Render.String(230, 40, 0,  "Hello " + username, purple, 1);
        Render.String(230, 55, 0, "Hello OOF . RIF", purple, 1);
        if (World.GetServerString() != "") {
            Render.String(230, 70, 0, "Name: " + localName, offWhite, 1);
            if (Entity.IsAlive(localPlayer)) {
                Render.String(230, 85, 0, "Latency: " + latency, offWhite, 1);
                Render.String(230, 100, 0, "Fake Ping: " + fakePing, offWhite, 1);
            }
            //render server info
            Render.String(375, 70, 0, "Server IP: " + serverIP, offWhite, 1);
            Render.String(375, 85, 0, "Map Name: " + mapName, offWhite, 1);
            if (Entity.IsAlive(localPlayer)) {
                //renders weapon info
                Render.String(375, 100, 0, "Current Weapon: " + cur_wep, yellowGreen, 1);
                //render angles
                Render.String(230, 130, 0, "All Angles" + niceBlue, 1);
                Render.String(230, 145, 0, "Yaw (R, F, L): " + realYaw + ", " + fakeYaw + ", " + lbyYaw, niceBlue, 1);
                Render.String(230, 160, 0, "ViewAngles: " + Math.floor(viewangles[0]) + ", " + Math.floor(viewangles[1]) + ", " + Math.floor(viewangles[2]), deepBlue, 1);
                Render.String(230, 175, 0, "Eye Position: " + Math.floor(eyePos[0]) + ", " + Math.floor(eyePos[1]) + ", " + Math.floor(eyePos[2]), niceBlue, 1);
                //render kills and stuff
                Render.String(13, 780, 0, "Kills: " + kills + ", Assists: " + assists, yellowGreen, 1);
                Render.String(13, 765, 0, "Deaths: " + deaths + ", K/D: " + kd, yellowGreen, 1);
            }
        }
    }
    var selected_aa_indicators = gui.getScriptVal("Draw Anti-Aim Indicators");
    if (World.GetServerString() != "") {
        if (selected_aa_indicators & (1 << 0)) {
            const local = Entity.GetLocalPlayer();
            if (Entity.IsAlive(local)) {
                const origin = Entity.GetRenderOrigin(local)
                const origin_x = origin[0];
                const origin_y = origin[1];
                const origin_z = origin[2];
                if (origin_x && origin_y && origin_z) {
                    const originScreen = Render.WorldToScreen([origin_x, origin_y, origin_z]);
                    if (originScreen) {
                        const origScreenX = originScreen[0];
                        const origScreenY = originScreen[1];
                        const real = Local.GetRealYaw();
                        const fake = Local.GetFakeYaw();
                        const lby = Entity.GetProp(local, "DT_CSPlayer", "m_flLowerBodyYawTarget");
                        drawLine("REAL", 35, origin_x, origin_y, origin_z, origScreenX, origScreenY, real, [255, 0, 0, 255]);
                        drawLine("FAKE", 35, origin_x, origin_y, origin_z, origScreenX, origScreenY, fake, [0, 255, 0, 175]);
                        drawLine("LBY", 35, origin_x, origin_y, origin_z, origScreenX, origScreenY, lby, [0, 50, 255, 255]);
                    }
                }
            }
        }
        if (selected_aa_indicators & (1 << 1)) {
            const local = Entity.GetLocalPlayer();

            if (Entity.IsAlive(local)) {
                const origin = Entity.GetRenderOrigin(local);
                const origin_x = origin[0];
                const origin_y = origin[1];
                const origin_z = origin[2];

                const originScreen = Render.WorldToScreen([origin_x, origin_y, origin_z]);
                const origScreen_X = originScreen[0];
                const origScreen_Y = originScreen[1];

                const realYaw = Math.floor(Local.GetRealYaw());

                Render.String(origScreen_X, origScreen_Y - 300, 0, "Real Yaw: " + realYaw, [255, 130, 0, 255], 1);
            }
        }
        if (selected_aa_indicators & (1 << 2)) {
            const local = Entity.GetLocalPlayer();

            if (Entity.IsAlive(local)) {
                const origin = Entity.GetRenderOrigin(local);
                const origin_x = origin[0];
                const origin_y = origin[1];
                const origin_z = origin[2];

                const originScreen = Render.WorldToScreen([origin_x, origin_y, origin_z]);
                const origScreen_X = originScreen[0];
                const origScreen_Y = originScreen[1];

                const fakeYaw = Math.floor(Local.GetFakeYaw());

                Render.String(origScreen_X, origScreen_Y - 285, 0, "Fake Yaw: " + fakeYaw, [130, 255, 255, 255], 1);
            }
        }
        if (selected_aa_indicators & (1 << 3)) {
            const local = Entity.GetLocalPlayer();

            if (Entity.IsAlive(local)) {
                const origin = Entity.GetRenderOrigin(local);
                const origin_x = origin[0];
                const origin_y = origin[1];
                const origin_z = origin[2];

                const originScreen = Render.WorldToScreen([origin_x, origin_y, origin_z]);
                const origScreen_X = originScreen[0];
                const origScreen_Y = originScreen[1];

                const lbyYaw = Math.floor(Entity.GetProp(local, "DT_CSPlayer", "m_flLowerBodyYawTarget"));

                Render.String(origScreen_X, origScreen_Y - 270, 0, "LBY Yaw: " + lbyYaw, [255, 130, 130, 255], 1);
            }
        }
        if (selected_aa_indicators & (1 << 4)) {
            const local = Entity.GetLocalPlayer();
            if (Entity.IsAlive(local)) {
                const origin = Entity.GetRenderOrigin(local);
                const origin_x = origin[0];
                const origin_y = origin[1];
                const origin_z = origin[2];
                const originScreen = Render.WorldToScreen([origin_x, origin_y, origin_z]);
                const origScreen_X = originScreen[0];
                const origScreen_Y = originScreen[1];
                const realYaw = Local.GetRealYaw();
                const lbyYaw = Entity.GetProp(local, "DT_CSPlayer", "m_flLowerBodyYawTarget");
                const delta = Math.floor(realYaw - lbyYaw);
                Render.String(origScreen_X - 20, origScreen_Y, 0, "Delta: " + delta, [255, 200, 255, 255], 1);
            }
        }
    }
    var selected_rage_indicators = gui.getScriptVal("Draw Ragebot Indicators");
    if (World.GetServerString() != "") {
        var weapon = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()));
        var weaponcategory = feature.getWeaponCategory(weapon);
        var bScale = gui.getRageBodyPointScale(weaponcategory);
        var hScale = gui.getRageHeadPointScale(weaponcategory);
        var mindmg = gui.getRageMinDmg(weaponcategory);
        var hitchance = gui.getRageHitChance(weaponcategory);
        var fov = gui.getRageFOV(weaponcategory);
        if (Entity.IsAlive(localPlayer)) {
            if (selected_rage_indicators & (1 << 0)) { if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Resolver override")) { Render.String(960, 515, 1, "Resolver Override", [55, 255, 100, 155], 1); } if (!UI.IsHotkeyActive("Rage", "GENERAL", "General", "Resolver override")) { Render.String(960, 515, 1, "Resolver Override", [200, 255, 200, 155], 1); } }
            if (selected_rage_indicators & (1 << 1)) { if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force safe point")) { Render.String(960, 500, 1, "Safe", [55, 255, 100, 155], 1); } if (!UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force safe point")) { Render.String(960, 500, 1, "Safe", [200, 255, 200, 155], 1); } }
            if (selected_rage_indicators & (1 << 2)) { if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force body aim")) { Render.String(960, 485, 1, "Baim", [55, 255, 100, 155], 1); } if (!UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force body aim")) {  Render.String(960, 485, 1, "Baim", [200, 255, 200, 155], 1); } }
            if (selected_rage_indicators & (1 << 3)) { Render.String(960, 550, 1, "Min Dmg: " + mindmg, [205, 205, 255, 155], 1); }
            if (selected_rage_indicators & (1 << 4)) { Render.String(960, 565, 1, "Hitchance: " + hitchance, [205, 205, 255, 155], 1); }
            if (selected_rage_indicators & (1 << 5)) { Render.String(960, 580, 1, "FOV: " + fov, [205, 205, 255, 155], 1); }
            if (selected_rage_indicators & (1 << 6)) { Render.String(960, 595, 1, "HeadScale: " + hScale, [205, 205, 255, 155], 1); }
            if (selected_rage_indicators & (1 << 7)) { Render.String(960, 610, 1, "BodyScale: " + bScale, [205, 205, 255, 155], 1); }
        }
    }
    if (gui.getScriptVal("Indicator") == 1) {
        const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "indicator_x"), y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "indicator_y");
        Render.FilledRect(x, y, 360, 25, [0, 0, 0, 130]);
        Render.String(x + 150, y + 5, 0, "Indicators", [255, 255, 255, 255]);
        Render.FilledRect(x, y, 360, 3, [0, 200, 0, 255]);
        Render.FilledRect(x, y + 24, 360, 80, [0, 0, 10, 80]);
        Render.String(x + 6, y + 25, 0, "Anti-Aim Settings                                 Ragebot Settings", niceBlue);
        Render.String(x + 6, y + 45, 0, "Real: " + realYaw + ", Lby: " + lbyYaw, [255, 255, 255, 255]);
        Render.String(x + 6, y + 60, 0, "Choke Amount: " + gui.getAATab("Fake-Lag", "Limit"), [255, 255, 255, 255]);

        if (Global.IsKeyPressed(1)) { const mouse_pos = Global.GetCursorPosition(); if (in_bounds(mouse_pos, x, y, x + 185, y + 38)) { UI.SetValue("Misc", "JAVASCRIPT", "Script items", "indicator_x", mouse_pos[0] - 100); UI.SetValue("Misc", "JAVASCRIPT", "Script items", "indicator_y", mouse_pos[1] - 20); } }
    }
    if (UI.IsMenuOpen()) {
        Render.String(1550, 70, 0, "Current Script Version: " + feature.changelog.version, [255, 50, 50, 255]);
        Render.String(1550, 90, 0, "Script is Currently in: " + feature.changelog.build_type, [255, 50, 50, 255]);
        Render.String(1550, 110, 0, "Script Status: " + feature.changelog.status, [255, 50, 50, 255]);
        Render.String(1550, 130, 0, "Changes: " + feature.changelog.changes, [255, 50, 50, 255]);
    }
} Cheat.RegisterCallback("Draw", "drawVisuals");
function doCreateMove() {
    var selected_feature = gui.getScriptVal("Draw Misc Features");
    if (feature.ragebot_info.ragebot_fired > 0 && selected_feature & (1 << 2)) {
        AntiAim.SetOverride(1);
        feature.ragebot_info.ragebot_fired--;
        AntiAim.SetFakeOffset(Math.ceil((Math.random() - 0.5) * 90));
        AntiAim.SetRealOffset(Math.ceil((Math.random() - 0.5) * 180));
        AntiAim.SetLBYOffset(Math.ceil((Math.random() - 0.5) * 180));
        gui.setAATab("Fake-Lag", "Limit", 0);
        gui.setAATab("Fake-Lag", "Jitter", 0);
        gui.setAATab("Fake-Lag", "Trigger limit", 0);
    }
    else { AntiAim.SetOverride(0); }
    if (selected_feature & (1 << 0)) {
        count1++
        if (count1 > feature.misc_clantag.length) {
            count1 = 0
            Local.SetClanTag(feature.misc_clantag[Math.round(new Date().getTime() / 500) % feature.misc_clantag.length]);
        }
    }
    var selected_aaPreset = gui.getScriptVal("Anti-Aim Presets") + 1;
    var inverter = UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter");
    switch (selected_aaPreset) {
        case 1:
            AntiAim.SetOverride(0);
            break;
        case 2:
            count2++
            AntiAim.SetOverride(1);
            AntiAim.SetRealOffset(0);
            AntiAim.SetFakeOffset(0);
            if (count2 > 30) {
                count2 == 0;
                AntiAim.SetLBYOffset(-Math.round(new Date().getTime() / 30) % 60);
            }
            break;
        case 3:
            count2++
            AntiAim.SetOverride(1);
            AntiAim.SetFakeOffset(0);
            if (count2 > 20) {
                count2 == 0;
                AntiAim.SetLBYOffset(-Math.floor(new Date().getTime() / 7) % -58);
                AntiAim.SetRealOffset(35);
            }
            break;
        case 4:
            AntiAim.SetOverride(1);
            AntiAim.SetLBYOffset(0);
            AntiAim.SetFakeOffset(0);
            if (inverter) { AntiAim.SetRealOffset(55); } else { AntiAim.SetRealOffset(-55); }
            break;
        case 5:
            AntiAim.SetOverride(1);
            AntiAim.SetRealOffset(0);
            AntiAim.SetFakeOffset(0);
            if (inverter) { AntiAim.SetLBYOffset(-Math.floor(new Date().getTime() / 55) % 55); } else { AntiAim.SetLBYOffset(Math.floor(new Date().getTime() / 61) % 59); }
            break;
        case 6:
            AntiAim.SetOverride(1);
            AntiAim.SetLBYOffset(0);
            count2++
            AntiAim.SetRealOffset(count2 * 10);
            if (count2 > 6) { count2 == -60; }
            break;
        case 7:
            AntiAim.SetOverride(1);
            count2++
            AntiAim.SetRealOffset(58 * count2);
            AntiAim.SetLBYOffset(-58 * count2);
            if (count2 > 0) { count2 == -1; }
            break;
        case 8:
            AntiAim.SetOverride(1);
            if (inverter) {
                AntiAim.SetFakeOffset(-Math.floor(new Date().getTime() / 50) % 35);
                AntiAim.SetLBYOffset(-Math.floor(new Date().getTime()) % 58);
            } else {
                AntiAim.SetFakeOffset(Math.floor(new Date().getTime() / 50) % 35);
                AntiAim.SetLBYOffset(Math.floor(new Date().getTime()) % 58);
            }
            break;
        case 9:
            AntiAim.SetOverride(1);
            if (inverter) {
                AntiAim.SetFakeOffset(-Math.floor(new Date().getTime() / 450) % 45);
                AntiAim.SetRealOffset(Math.floor(new Date().getTime() / 75) % 60)
                AntiAim.SetLBYOffset(-Math.floor(new Date().getTime() / 75 ) % 60);
            } else {
                AntiAim.SetFakeOffset(Math.floor(new Date().getTime() / 450) % 45);
                AntiAim.SetRealOffset(-Math.floor(new Date().getTime() / 75) % 60)
                AntiAim.SetLBYOffset(Math.floor(new Date().getTime() / 75) % 60);
            }
            break;
        case 10:
            AntiAim.SetOverride(1);
            if (inverter) {
                AntiAim.SetFakeOffset(-Math.floor(new Date().getTime() / 45) % 15);
                AntiAim.SetRealOffset(Math.floor(new Date().getTime() / 30) % 60);
                AntiAim.SetLBYOffset(-new Date().getTime() % 60);
            } else {
                AntiAim.SetFakeOffset(Math.floor(new Date().getTime() / 45) % 15);
                AntiAim.SetRealOffset(-Math.floor(new Date().getTime() / 30) % 60);
                AntiAim.SetLBYOffset(new Date().getTime() % 60);
            }
            break;
        case 11:
            var fl_limit = 14;
            var fl_jitter = 75;
            var fl_trigger = 28;
            AntiAim.SetOverride(1);
            count2++
            count3++
            if (inverter) {
                if (count2 >= 14) {
                    gui.setRageAA("Yaw offset", -Math.floor(new Date().getTime() / 5) % 15);
                    gui.setAATab("Fake-Lag", "Limit", Math.floor(new Date().getTime() / fl_jitter) % 6);
                    gui.setAATab("Fake-Lag", "Jitter", Math.floor(new Date().getTime() / fl_jitter) % 100);
                    gui.setAATab("Fake-Lag", "Trigger limit", Math.floor(new Date().getTime() / fl_jitter) % 14);
                    AntiAim.SetLBYOffset(Math.floor(new Date().getTime() / 2) % 60);
                    AntiAim.SetRealOffset((-Math.floor(new Date().getTime() / 4) % 60) - 21);
                    AntiAim.SetFakeOffset(0);
                    count2 == 0;
                }
            } else {
                if (count2 >= 14) {
                    gui.setRageAA("Yaw offset", Math.floor(new Date().getTime() / 5) % 15);
                    gui.setAATab("Fake-Lag", "Limit", Math.floor(new Date().getTime() / 1) % 6);
                    gui.setAATab("Fake-Lag", "Jitter", Math.floor(new Date().getTime() / fl_jitter) % 100);
                    gui.setAATab("Fake-Lag", "Trigger limit", Math.floor(new Date().getTime() / 1) % 14);
                    AntiAim.SetLBYOffset(-Math.floor(new Date().getTime() / 2) % 60);
                    AntiAim.SetRealOffset((Math.floor(new Date().getTime() / 4) % 60) + 21);
                    AntiAim.SetFakeOffset(0);
                    count2 == 0;
                }
            }
            break;
        case 12:
            AntiAim.SetOverride(1);
            if (inverter) {
                AntiAim.SetLBYOffset(Math.floor(new Date().getTime() / 100) % 90);
                AntiAim.SetRealOffset(-30);
            } else {
                AntiAim.SetLBYOffset(-Math.floor(new Date().getTime() / 100) % 90);
                AntiAim.SetRealOffset(30);
            }
            break;
    }
} Cheat.RegisterCallback("CreateMove", "doCreateMove");
function doMisc() { 
    var selected_information = gui.getScriptVal("Draw Information");
    if (selected_information & (1 << 0)) {
        const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "keybind_x"), y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "keybind_y");
        var h = [];
        if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck")) { h.push("Fake Duck"); }
        if (UI.IsHotkeyActive("Misc", "GENERAL", "Movement", "Auto peek")) { h.push("Auto Peek"); }
        if (UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")) { h.push("Inverter"); }
        if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force safe point")) { h.push("Safe Point"); }
        if (UI.IsHotkeyActive("Rage", "Exploits", "Doubletap")) { h.push("Double Tap"); }
        if (UI.IsHotkeyActive("Rage", "Exploits", "Hide shots")) { h.push("Hide Shots"); }
        if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force body aim")) { h.push("Body Aim"); }
        if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Resolver override")) { h.push("Resolver Override"); }
        if (UI.IsHotkeyActive("Rage", "GENERAL", "General", "Enabled")) { h.push("Ragebot"); }
        if (UI.IsHotkeyActive("Legit", "GENERAL", "General", "Enabled")) { h.push("Legitbot"); }
        if (UI.IsHotkeyActive("Legit", "GENERAL", "Triggerbot", "Enabled")) { h.push("Triggerbot"); }
        if (UI.IsHotkeyActive("Anti-Aim", "Legit Anti-Aim", "Direction key")) { h.push("Inverter"); }
        if (UI.IsHotkeyActive("Anti-Aim", "Rage Anti-Aim", "Jitter offset")) { h.push("Jitter"); }
        if (UI.IsHotkeyActive("Anti-Aim", "Rage Anti-Aim", "Mouse dir")) { h.push("Mouse Direction"); }
        if (UI.IsHotkeyActive("Anti-Aim", "Rage Anti-Aim", "Left dir")) { h.push("Left"); }
        if (UI.IsHotkeyActive("Anti-Aim", "Rage Anti-Aim", "Right dir")) { h.push("Right"); }
        if (UI.IsHotkeyActive("Anti-Aim", "Rage Anti-Aim", "Back dir")) { h.push("Back"); }
        if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Slow walk")) { h.push("Slowwalk"); }
        Render.FilledRect(x, y, 190, 25, [0, 0, 0, 150]);
        Render.FilledRect(x, y, 190, 2, [0, 200, 0, 255]);
        Render.FilledRect(x, y + 24, 190, 21 + 18 * (h.length - 1), [0, 0, 10, 28]);
        Render.String(x + 90, y + 7, 3, "Hotkeys", [255, 255, 255, 255], 10);
        for (i = 0; i < h.length; i++) {
            Render.String(x + 8, y + 31 + 15 * i, 0, h[i], [255, 255, 255, 255], 10);
            Render.String(x + 145, y + 31 + 15 * i, 3, "[active]", [255, 255, 255, 255], 10);
        }
        if (Global.IsKeyPressed(1)) { const mouse_pos = Global.GetCursorPosition(); if (in_bounds(mouse_pos, x, y, x + 200, y + 30)) { UI.SetValue("Misc", "JAVASCRIPT", "Script items", "keybind_x", mouse_pos[0] - 100); UI.SetValue("Misc", "JAVASCRIPT", "Script items", "keybind_y", mouse_pos[1] - 20); } }
    }
    if (selected_information & (1 << 1)) {
        const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "spectators_x"), y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "spectators_y");
        var specs = [];
        const players = Entity.GetPlayers();
        for (var i = 0; i < players.length; i++) {
            const cur = players[i];
            if (Entity.GetProp(cur, "CBasePlayer", "m_hObserverTarget") != "m_hObserverTarget") { const obs = Entity.GetProp(cur, "CBasePlayer", "m_hObserverTarget"); if (obs === Entity.GetLocalPlayer()) { const name = Entity.GetName(cur); specs.push(name); } }
        }
        Render.FilledRect(x, y, 190, 25, [0, 0, 0, 150]);
        Render.FilledRect(x, y, 190, 2, [0, 200, 0, 255]);
        Render.FilledRect(x, y + 24, 190, 20 + 18 * (specs.length - 1), [0, 0, 10, 28]);
        Render.String(x + 95, y + 7, 3, "Spectators", [255, 255, 255, 255], 10);
        for (i = 0; i < specs.length; i++) {
            Render.String(x + 8, y + 31 + 15 * i, 0, specs[i], [255, 255, 255, 255], 10);
        }
        if (Global.IsKeyPressed(1)) { const mouse_pos = Global.GetCursorPosition(); if (in_bounds(mouse_pos, x, y, x + 200, y + 30)) { UI.SetValue("Misc", "JAVASCRIPT", "Script items", "spectators_x", mouse_pos[0] - 100); UI.SetValue("Misc", "JAVASCRIPT", "Script items", "spectators_y", mouse_pos[1] - 20); } }
    }
    if (selected_information & (1 << 2)) {
        var screen_size = Render.GetScreenSize();
        x1 = screen_size[0] - screen_size[0];
        y1 = screen_size[1] - screen_size[1];

        Render.FilledRect(x1 + 1605, y1 + 20, 310, 20, [0, 0, 0, 150]);
        Render.FilledRect(x1 + 1605, y1 + 20, 310, 2, [0, 255, 0, 255]);
        const ping = Math.floor(Global.Latency() * 1000 / 1.5);
        var rate = 1 / Globals.Tickrate();
        var tickrate = Math.floor(rate);
        var framerate = 1 / Globals.Frametime();
        var fps = Math.floor(framerate);
        Render.String(x1 + 1615, y1 + 26, 0, "onetap.com |  tickrate: " + tickrate + "  |  delay: " + ping + " | fps: " + fps, [255, 255, 255, 255], 8);
    }
    function HSVtoRGB(h, s, v) {
        var r, g, b, i, f, p, q, t

        i = Math.floor(h * 6)
        f = h * 6 - i
        p = v * (1 - s)
        q = v * (1 - f * s)
        t = v * (1 - (1 - f) * s)

        switch (i % 6) {
            case 0: r = v, g = t, b = p; break;
            case 1: r = q, g = v, b = p; break;
            case 2: r = p, g = v, b = t; break;
            case 3: r = p, g = q, b = v; break;
            case 4: r = t, g = p, b = v; break;
            case 5: r = v, g = p, b = q; break;
        }

        return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) }
    }
    var colors = HSVtoRGB(Global.Realtime() * 0.07, 1, 1)
    Render.GradientRect(0, 0, 1920, 3, 1, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
    var selected_feature = gui.getScriptVal("Draw Misc Features");
    if (selected_feature & (1 << 1)) {
        if (UI.IsMenuOpen()) {
            neko = Render.AddTexture("ot/scripts/not nekos/neko.png");
            Render.TexturedRect(1860, 10, 60, 60, neko);
        }
    }
} Cheat.RegisterCallback("Draw", "doMisc");

function player_hurt() {
    userid = Entity.GetEntityFromUserID(Event.GetInt("userid"));
    attacker = Entity.GetEntityFromUserID(Event.GetInt("attacker"));
    health = Event.GetInt("health");
    armor = Event.GetInt("armor");
    weapon = Event.GetString("weapon");
    dmg_health = Event.GetInt("dmg_health");

    var username = Entity.GetName(userid);

    if (attacker == Entity.GetLocalPlayer() && gui.getScriptVal("Draw Hitlogs") == 1) {
        Cheat.PrintColor([255, 25, 25, 255], " [ AntiSaint ] Harmed " + username + " for " + dmg_health + " HP \n");
        Cheat.PrintColor([255, 25, 25, 255], " [ AntiSaint ] " + username + " Was harmed by a " + weapon + "\n");
        Cheat.PrintColor([255, 25, 25, 255], " [ AntiSaint ] " + username + " Has " + health + "HP remaining and " + armor + "AR remaining \n");
    }
} Cheat.RegisterCallback("player_hurt", "player_hurt");
function player_death() {
    dead_player = Entity.GetEntityFromUserID(Event.GetInt("userid"));
    var attacker = Entity.GetEntityFromUserID(Event.GetInt("attacker"));
    walls_penetrated = Event.GetInt("penetrated");
    if (Entity.IsAlive(Entity.GetLocalPlayer()) && attacker == Entity.GetLocalPlayer()) {
		var selected_feature = gui.getScriptVal("Draw Misc Features");
		if (selected_feature & (1 << 3)) {
            Cheat.ExecuteCommand("say " + feature.misc_kill_prefix[Math.floor(Math.random() * feature.misc_kill_prefix.length)] + feature.misc_kill_suffix[Math.floor(Math.random() * feature.misc_kill_suffix.length)]);
        }
        if (selected_feature & (1 << 4)) {
            Cheat.ExecuteCommand("say " + feature.misc_cancer_killsay[Math.floor(Math.random() * feature.misc_cancer_killsay.length)]);
        }
	}
} Cheat.RegisterCallback("player_death", "player_death");
function ragebot_fire() {
    feature.ragebot_info.ragebot_fired = 80;
    target_name = Entity.GetName(Event.GetInt("target_index"));
    hitbox = feature.getHitboxName(Event.GetInt("hitbox"));
    hitchance = Event.GetInt("hitchance");
    safepoint = Event.GetInt("safepoint");
    exploit = Event.GetInt("exploit");

    if (gui.getScriptVal("Draw Hitlogs") == 1) {
        Cheat.PrintColor([255, 25, 25, 255], " [ AntiSaint ] Attempted to shoot at " + target_name + "\n");
        Cheat.PrintColor([255, 25, 25, 255], " [ AntiSaint ] Targeted " + hitbox + ", SafePoint Mode: " + safepoint + ", Hitchance used: " + hitchance + "\n");
    }
} Cheat.RegisterCallback("ragebot_fire", "ragebot_fire");
function unload() {
    Antiaim.SetOverride(0);
    Local.SetClanTag("");
} Cheat.RegisterCallback("unload", "unload");

function getRadians(angle) { return angle * Math.PI / 180; }
function getDistance(val) { return Math.sqrt(val[0] ^ 2 + val[1] ^ 2 + val[2] ^ 2); }
function drawLine(label, distance, loc_x, loc_y, loc_z, origin_x, origin_y, val, colour) {
    const xAngle = loc_x + Math.cos(getRadians(val)) * distance; const yAngle = loc_y + Math.sin(getRadians(val)) * distance; const screenPos = Render.WorldToScreen([xAngle, yAngle, loc_z]);
    if (screenPos) {
        const screenX = screenPos[0];
        const screenY = screenPos[1];
        Render.Line(origin_x, origin_y, screenX, screenY, colour);
        Render.String(screenX, screenY, 1, label, [255, 255, 255, 255], 1);
    }
}
const keybind_x = UI.AddSliderInt("keybind_x", 0, Global.GetScreenSize()[0]);
const keybind_y = UI.AddSliderInt("keybind_y", 0, Global.GetScreenSize()[1]);
const spectators_x = UI.AddSliderInt("spectators_x", 0, Global.GetScreenSize()[0]);
const spectators_y = UI.AddSliderInt("spectators_y", 0, Global.GetScreenSize()[0]);
const watermark_x = UI.AddSliderInt("watermark_x", 0, Global.GetScreenSize()[0]);
const watermark_y = UI.AddSliderInt("watermark_y", 0, Global.GetScreenSize()[0]);
const indicator_x = UI.AddSliderInt("indicator_x", 0, Global.GetScreenSize()[0]);
const indicator_y = UI.AddSliderInt("indicator_y", 0, Global.GetScreenSize()[0]);
function xy() {
    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "keybind_x", false);
    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "keybind_y", false);
    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "spectators_x", false);
    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "spectators_y", false);
    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "watermark_x", false);
    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "watermark_y", false);
    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "indicator_x", false);
    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "indicator_y", false);
} xy();
function in_bounds(vec, x, y, x2, y2) { return (vec[0] > x) && (vec[1] > y) && (vec[0] < x2) && (vec[1] < y2); }