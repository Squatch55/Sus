var gui = require("AntiSaint/AntiSaintUI.js");
var feature = require("AntiSaint/AntiSaintLib.js");

UI.AddLabel("----------------------------------------"); //40 dashes
UI.AddLabel("CC = Crystal Chams");
UI.AddSliderFloat("CC Scale", 0, 3);
UI.AddSliderFloat("CC Bloom", 0, 1);
UI.AddSliderFloat("CC Pearlescence", 0, 10);
UI.AddLabel("----------------------------------------"); //40 dashes

Material.Create("Crystal");
Material.Create("Platinum");
Material.Create("Palm");
function setup_materials() {
    //Crystal Chams Start
    c_scale = gui.getScriptVal("CC Scale");
    c_bloom = gui.getScriptVal("CC Bloom");
    c_pearlescence = gui.getScriptVal("CC Pearlescence");
    crystal = Material.Get("Crystal");
    Material.SetKeyValue(crystal, "$basetexture", "vgui/white");
    Material.SetKeyValue(crystal, "$envmap", "models/effects/crystal_cube_vertigo_hdr");
    Material.SetKeyValue(crystal, "$envmaptint", "[" + " " + c_bloom + " " + c_bloom + " " + c_bloom + "]");
    Material.SetKeyValue(crystal, "$envmapfresnel", "1");
    Material.SetKeyValue(crystal, "$envmapfresnelminmaxexp", "[0 1 2]");
    Material.SetKeyValue(crystal, "$phong", "1");
    Material.SetKeyValue(crystal, "$pearlescent", c_pearlescence.toString());
    Material.SetKeyValue(crystal, "$reflectivity", "[2 2 2]");
    Material.SetKeyValue(crystal, "$bumpmap", "models/weapons/customization/materials/origamil_camo");
    Material.SetKeyValue(crystal, "$bumptransform", "center .5 .5 scale" + " " + c_scale + " " + c_scale + "rotate 0 translate 0 0");
    Material.Refresh(crystal);
    //Crystal Chams End

    //Platinum Chams Start
    platinum = Material.Get("Platinum");
    Material.SetKeyValue(platinum, "$basetexture", "vgui/white");
    Material.SetKeyValue(platinum, "$envmap", "models/player/ct_fbi/ct_fbi_glass");
    Material.SetKeyValue(platinum, "$bumpmap", "models/player/ct_fbi/ct_fbi_glass");
    Material.Refresh(platinum);
    //Platinum Chams End

    //Glass Chams Start
    palm = Material.Get("Palm");
    Material.SetKeyValue(palm, "$basetexture", "models/props/de_dust/hr_dust/foliage/palm_bark_01");
    Material.Refresh(palm);
    //Glass Chams End

} Cheat.RegisterCallback("Material", "setup_materials");

function unload() {
    Material.Destroy("Crystal");
    Material.Destroy("Platinum");
    Material.Destroy("Palm");
} Cheat.RegisterCallback("Unload", "unload");